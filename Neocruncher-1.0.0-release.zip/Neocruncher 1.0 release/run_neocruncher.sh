#!/bin/sh
# SPDX-License-Identifier: GPL-3.0-only
set -eu
cd "$(dirname "$0")"
. ./runtime.sh
exec .venv-system/bin/python -m neocruncher_app "$@"
