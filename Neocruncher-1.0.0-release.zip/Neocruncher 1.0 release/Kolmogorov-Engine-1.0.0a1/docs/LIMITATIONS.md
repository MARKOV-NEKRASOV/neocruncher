# Candidate limitations

Large-precision CPU/hybrid/GPU targets require hardware qualification. No
out-of-core arithmetic, unconditional performance gain or safety guarantee is
claimed. Use the root bundle documentation. Reference algorithms and prefix
verification have explicitly narrower accuracy scopes than full independent checks.
