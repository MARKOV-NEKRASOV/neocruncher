# Kolmogorov Engine — Neocruncher 1.0 release (beta)

Published by Markov–Nekrasov Research Team. GNU GPL version 3 only (GPL-3.0-only).
Use the root bundle installer and launchers. Component version: 1.0.0a1.
The numerical formulas and execution policies are unchanged; this review adds
defensive input checks and updates privacy and release documentation.
See the bundle README, COPYING and NOTICE. Legacy permission texts are
retained in LICENSES; dependencies have their own licenses.
Developed in explicit collaboration with GPT / ChatGPT / Codex.
