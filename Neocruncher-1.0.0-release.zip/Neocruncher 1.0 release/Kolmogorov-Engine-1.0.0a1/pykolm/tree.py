# SPDX-License-Identifier: GPL-3.0-only
from __future__ import annotations
from dataclasses import dataclass, asdict
import json, math, subprocess, sys, time
from concurrent.futures import ThreadPoolExecutor
try:
    from gmpy2 import mpz as Integer, gcd
    INTEGER_BACKEND = 'GMP via gmpy2'
except ImportError:
    Integer = int
    gcd = math.gcd
    INTEGER_BACKEND = 'Python int'

@dataclass(frozen=True)
class Plan:
    family: str
    start: int
    stop: int
    arg: int = 0
    leaf_terms: int = 32
    reduce: bool = True

    def __post_init__(self):
        if self.family not in ('chud', 'exp'):
            raise ValueError('PyKolm supports chud/exp only')
        if any((type(v) is not int for v in (self.start, self.stop, self.arg, self.leaf_terms))):
            raise ValueError('Integer plan fields required')
        if not 0 <= self.start < self.stop or not 1 <= self.leaf_terms <= 4096:
            raise ValueError('Invalid interval or leaf size')
        if self.family == 'exp' and (self.start < 1 or self.arg not in (0, 1)):
            raise ValueError('exp requires start>=1 and alternating flag 0/1')
        if type(self.reduce) is not bool:
            raise ValueError('reduce must be boolean')

def payload_bytes(node):
    return sum(((abs(v).bit_length() + 7) // 8 for v in node))

def multiply(a, b):
    import operator
    if isinstance(a, bool) or isinstance(b, bool):
        raise TypeError('Exact integer operands required')
    return Integer(operator.index(a)) * Integer(operator.index(b))

def encode(node):
    return [format(x, 'x') for x in node]

def decode(values):
    if not isinstance(values, list) or len(values) not in (2, 3):
        raise ValueError('Invalid node')
    import re
    if any((not isinstance(v, str) or not re.fullmatch('-?[0-9a-f]+', v) for v in values)):
        raise ValueError('Invalid hexadecimal integer')
    return tuple((Integer(v, 16) for v in values))

class Session:

    def __init__(self, progress=None, reduce=True):
        self.progress = progress
        self.reduce = reduce
        self.metrics = dict(integer_backend=INTEGER_BACKEND, nodes=0, reductions=0, cancelled_common_factor_bits=0, gcd_seconds=0.0, max_node_payload_bytes=0, peak_frontier_payload_bytes=0, max_pending_tasks=0, child_tasks=0, local_split_seconds=0.0, merge_seconds=0.0)

    def normalize(self, node):
        self.metrics['nodes'] += 1
        if len(node) == 3 and self.reduce and (max((abs(v).bit_length() for v in node)) <= 8192):
            start = time.perf_counter()
            p, q, t = node
            g = gcd(gcd(p, q), t)
            if g > 1:
                node = (p // g, q // g, t // g)
                self.metrics['reductions'] += 1
                self.metrics['cancelled_common_factor_bits'] += int(g.bit_length())
            self.metrics['gcd_seconds'] += time.perf_counter() - start
        self.metrics['max_node_payload_bytes'] = max(self.metrics['max_node_payload_bytes'], payload_bytes(node))
        return node

    def merge(self, family, left, right):
        begin = time.perf_counter()
        if family == 'exp':
            p, t = left
            q, u = right
            node = (p * q, t * q + u)
        else:
            p, q, t = left
            r, s, u = right
            node = (p * r, q * s, t * s + p * u)
        node = self.normalize(node)
        self.metrics['merge_seconds'] += time.perf_counter() - begin
        return node

    def leaf(self, plan, a, b):
        if plan.family == 'exp':
            p, t = (1, 0)
            for k in range(a, b):
                p *= k
                t = t * k + (-1 if plan.arg and k & 1 else 1)
            return self.normalize((Integer(p), Integer(t)))
        p, q, t = (1, 1, 0)
        for k in range(a, b):
            if k == 0:
                pk, qk, tk = (1, 1, 13591409)
            else:
                pk = (6 * k - 5) * (2 * k - 1) * (6 * k - 1)
                qk = k * k * k * 10939058860032000
                tk = (-1 if k & 1 else 1) * pk * (13591409 + 545140134 * k)
            t = t * qk + p * tk
            p *= pk
            q *= qk
        return self.normalize((Integer(p), Integer(q), Integer(t)))

    def recursive(self, plan, a, b):
        if b - a <= plan.leaf_terms:
            return self.leaf(plan, a, b)
        m = (a + b) // 2
        left = self.recursive(plan, a, m)
        right = self.recursive(plan, m, b)
        return self.merge(plan.family, left, right)

    def notify(self, done, total, stage='PyKolm CPU subtrees'):
        if self.progress:
            self.progress(dict(stage=stage, percent=None, phase_percent=100 * done / total, work_done=done, work_total=total, progress_scope='completed subtrees, not elapsed time'))

    def push(self, frontier, index, node, family):
        height = 0
        while frontier and frontier[-1][0] == height:
            node = self.merge(family, frontier.pop()[1], node)
            height += 1
        frontier.append((height, node))
        size = sum((payload_bytes(n) for _, n in frontier))
        self.metrics['peak_frontier_payload_bytes'] = max(self.metrics['peak_frontier_payload_bytes'], size)

    def finish(self, frontier, family):
        node = frontier.pop()[1]
        while frontier:
            node = self.merge(family, frontier.pop()[1], node)
        return node

    def execute(self, plan, workers=1, timeout=120):
        if type(workers) is not int or workers < 1:
            raise ValueError('workers >=1 required')
        self.reduce = plan.reduce
        n = plan.stop - plan.start
        if workers == 1 or n < 4096:
            self.notify(0, 1)
            start = time.perf_counter()
            node = self.recursive(plan, plan.start, plan.stop)
            self.metrics['local_split_seconds'] += time.perf_counter() - start
            self.notify(1, 1)
            return node
        count = 1 << max(0, min(workers * 2, max(1, n // 1024)).bit_length() - 1)
        jobs = [Plan(plan.family, plan.start + n * i // count, plan.start + n * (i + 1) // count, plan.arg, plan.leaf_terms, plan.reduce) for i in range(count)]
        frontier = []
        self.notify(0, count)
        with ThreadPoolExecutor(max_workers=min(workers, count)) as pool:
            for offset in range(0, count, workers):
                pending = [pool.submit(child, j, timeout) for j in jobs[offset:offset + workers]]
                self.metrics['max_pending_tasks'] = max(self.metrics['max_pending_tasks'], len(pending))
                for index, f in enumerate(pending, offset):
                    node, metrics = f.result()
                    self.absorb(metrics)
                    self.metrics['child_tasks'] += 1
                    self.push(frontier, index, node, plan.family)
                    self.notify(index + 1, count)
        return self.finish(frontier, plan.family)

    def absorb(self, other):
        for k in ('nodes', 'reductions', 'cancelled_common_factor_bits', 'gcd_seconds', 'local_split_seconds'):
            self.metrics[k] += other[k]
        self.metrics['max_node_payload_bytes'] = max(self.metrics['max_node_payload_bytes'], other['max_node_payload_bytes'])

def child(plan, timeout):
    command = [sys.executable, '-m', 'pykolm.worker']
    process = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    try:
        stdout, stderr = process.communicate(json.dumps(asdict(plan)), timeout=timeout)
    except BaseException:
        process.kill()
        process.communicate()
        raise
    if process.returncode:
        raise RuntimeError('PyKolm child failed: ' + stderr[-300:])
    result = json.loads(stdout)
    return (decode(result['node']), result['metrics'])

def split(family, start, stop, arg=0, *, reduce=True, workers=1, progress=None):
    s = Session(progress, reduce)
    return (s.execute(Plan(family, start, stop, arg, reduce=reduce), workers), s.metrics)
