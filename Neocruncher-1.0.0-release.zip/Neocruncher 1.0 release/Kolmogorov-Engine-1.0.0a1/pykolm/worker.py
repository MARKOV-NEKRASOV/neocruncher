# SPDX-License-Identifier: GPL-3.0-only
"""One fixed exact subtree on stdin, one hexadecimal result on stdout."""
import json, sys
from .tree import Plan,Session,encode

def main():
    plan=Plan(**json.load(sys.stdin));session=Session(reduce=plan.reduce)
    node=session.execute(plan)
    print(json.dumps(dict(node=encode(node),metrics=session.metrics)))
if __name__=='__main__':main()
