# SPDX-License-Identifier: GPL-3.0-only
"""PyKolm 0.1: experimental exact CPU execution plans, not a new bignum engine.

Integers remain GMP mpz when available. No OpenCL context or device is created.
Reduction preserves P/Q and T/Q; reduced tuples need not equal unreduced tuples.
"""
from .tree import Plan, Session, split, multiply
__version__='0.1.0'
__all__=['Plan','Session','split','multiply']
