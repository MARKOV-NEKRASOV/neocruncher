# SPDX-License-Identifier: GPL-3.0-only
"""Kolmogorov Engine 1.2: exact arithmetic and GPU-resident execution."""
__version__ = '1.0.0a1'
__all__ = ['Engine','DeviceArithmetic']
def __getattr__(name):
    if name=='Engine':
        from .compute import Engine
        return Engine
    if name=='DeviceArithmetic':
        from .compute.resident import DeviceArithmetic
        return DeviceArithmetic
    raise AttributeError(name)
