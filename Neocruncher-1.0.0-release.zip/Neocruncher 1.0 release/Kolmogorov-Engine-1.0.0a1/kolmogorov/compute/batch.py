# SPDX-License-Identifier: GPL-3.0-only
"""Dependency-aware batch planner for exact products.

Topological scheduling of independent operations via thread pool. This is NOT
GPU kernel vectorization: the executor still runs individual multiply calls.
"""
from __future__ import annotations
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass,asdict
import heapq
from time import perf_counter
import re
from .core import Engine, ComputeError, normalize_integer

_NAME=re.compile(r'[A-Za-z][A-Za-z0-9_]{0,63}\Z')

@dataclass(frozen=True)
class Operation:
    id: str
    a: str
    b: str
    op: str='multiply'

@dataclass(frozen=True)
class BatchResult:
    values: dict[str,str]
    backends: dict[str,str]
    layer_count: int
    task_count: int
    elapsed_seconds: float

    def to_dict(self):return asdict(self)

class BatchPlanner:
    def __init__(self,engine: Engine|None=None,workers:int=4):
        if type(workers) is not int or not 1<=workers<=64:
            raise ComputeError('workers debe estar en 1..64')
        self.engine=engine or Engine()
        self.workers=workers

    @staticmethod
    def _ref(value):
        if type(value) is not str:
            raise ComputeError('Operandos batch deben ser cadenas.')
        if value.startswith('@'):
            name=value[1:]
            if not _NAME.fullmatch(name):
                raise ComputeError(f'Referencia inválida: {value!r}')
            return name
        normalize_integer(value)
        return None

    def _layers(self,operations):
        if not operations or len(operations)>10000:
            raise ComputeError('Batch debe contener entre 1 y 10000 tareas.')
        indexed={}
        for op in operations:
            if not isinstance(op,Operation) or not _NAME.fullmatch(op.id):
                raise ComputeError('ID de operación inválido.')
            if op.id in indexed:raise ComputeError(f'ID duplicado: {op.id}')
            if op.op!='multiply':raise ComputeError(f'Operación no implementada: {op.op}')
            indexed[op.id]=op
        deps={id:set(filter(None,(self._ref(op.a),self._ref(op.b)))) for id,op in indexed.items()}
        for id,ds in deps.items():
            if not ds.issubset(indexed):raise ComputeError(f'{id}: referencia desconocida: {ds-set(indexed)}')
        # Kahn's algorithm: O((V+E) log V) rather than rescanning V on each
        # dependency layer (which was quadratic for long chains).
        dependents={name:[] for name in indexed}
        indegree={name:len(ds) for name,ds in deps.items()}
        for name,ds in deps.items():
            for dependency in ds:
                dependents[dependency].append(name)
        ready=[name for name,count in indegree.items() if count==0]
        heapq.heapify(ready)
        layers=[]; processed=0
        while ready:
            # All currently ready tasks are one independent scheduling layer.
            layer_ids=[heapq.heappop(ready) for _ in range(len(ready))]
            layers.append([indexed[name] for name in layer_ids])
            processed+=len(layer_ids)
            future=[]
            for name in layer_ids:
                for child in dependents[name]:
                    indegree[child]-=1
                    if indegree[child]==0:
                        future.append(child)
            for name in future:
                heapq.heappush(ready,name)
        if processed!=len(indexed):
            raise ComputeError('Ciclo en grafo de dependencias.')
        return layers

    def execute(self,operations:list[Operation],verify=True):
        layers=self._layers(operations)
        started=perf_counter()
        values={};backends={}
        def run(op):
            a=values[op.a[1:]] if op.a.startswith('@') else op.a
            b=values[op.b[1:]] if op.b.startswith('@') else op.b
            return op.id,self.engine.multiply(a,b,verify=verify)
        with ThreadPoolExecutor(max_workers=self.workers) as pool:
            for layer in layers:
                pairs=[(values[op.a[1:]] if op.a.startswith('@') else op.a,
                        values[op.b[1:]] if op.b.startswith('@') else op.b)
                       for op in layer]
                # One API batch enables NeoCruncher's actual GPU batching.
                # Other executors do per-product multiplication and may use threads.
                choices=[self.engine._choose(normalize_integer(a),normalize_integer(b)) for a,b in pairs]
                if len(layer)>1 and all(b is choices[0] for b in choices) and hasattr(choices[0],'multiply_many'):
                    answers=self.engine.multiply_many(pairs,verify=verify)
                    for op,out in zip(layer,answers):
                        values[op.id]=out.value;backends[op.id]=out.backend
                else:
                    for id,out in pool.map(run,layer):
                        values[id]=out.value;backends[id]=out.backend
        return BatchResult(values,backends,len(layers),len(operations),perf_counter()-started)
