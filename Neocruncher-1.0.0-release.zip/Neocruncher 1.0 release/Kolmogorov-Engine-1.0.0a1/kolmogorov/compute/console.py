# SPDX-License-Identifier: GPL-3.0-only
"""Responsive CLI activity on stderr; JSON on stdout stays machine-readable."""
import os,signal,subprocess,sys,time

def supervise(argv, module='kolmogorov.compute', label=None):
    env=os.environ.copy();env['KOLMOGOROV_CONSOLE_WORKER']='1'
    proc=subprocess.Popen([sys.executable,'-m',module,*argv],env=env,start_new_session=os.name=='posix')
    start=time.monotonic();frame=0;last=-10
    try:
        while proc.poll() is None:
            elapsed=time.monotonic()-start
            if sys.stderr.isatty() or elapsed-last>=5:
                pos=frame%18;line='  ['+' '*pos+'>>'+' '*(18-pos)+f'] {label or argv[0]} | {elapsed:.1f}s | ETA unknown'
                print(('\r' if sys.stderr.isatty() else '')+line,file=sys.stderr,end='' if sys.stderr.isatty() else '\n',flush=True)
                last=elapsed;frame+=1
            try:proc.wait(timeout=.15)
            except subprocess.TimeoutExpired:pass
    except BaseException:
        if proc.poll() is None:
            if os.name=='posix':os.killpg(proc.pid,signal.SIGKILL)
            else:proc.kill()
            proc.wait()
        print('\n  Cancelled',file=sys.stderr);raise
    print(('\r' if sys.stderr.isatty() else '')+'  ['+('='*20 if proc.returncode==0 else '-'*20)+'] '+('Completed' if proc.returncode==0 else 'Failed')+' '*30,file=sys.stderr)
    return proc.returncode
