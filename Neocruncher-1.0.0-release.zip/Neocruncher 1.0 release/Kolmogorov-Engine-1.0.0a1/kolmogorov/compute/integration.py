# SPDX-License-Identifier: GPL-3.0-only
"""Kolmogorov 1.1 exact-integer engine: stable NeoCruncher adapter contract.

No imports of NeoCruncher. No automatic CPU fallback. OpenCL work is sequential
across calls and kernels are cached by the OpenCL backend.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
import threading
import os
import time
from .core import (ComputeError, normalize_integer, _decimal_to_int,
                   _int_to_decimal, verify_modular, required_ntt_length)

API_VERSION = "1.2.0"

@dataclass(frozen=True)
class PreparedMultiplication:
    length_a: int
    length_b: int
    ntt_length: int
    estimated_peak_device_bytes: int
    arithmetic: str = 'exact NTT / two-prime CRT (OpenCL)'
    # This estimate omits driver allocations and host memory.

class ExactIntegerEngine:
    """Exact Python-int arithmetic via a *specified* portable backend.

    Host-assisted integration: OpenCL only. CUDA/ROCm/Vulkan are not certified
    and cannot be selected through this integration API.

    `factory` is a test-only injection point. Objects returned by it implement
    available(), multiply(str,str)->str, devices(), optional _memory_guard(n).
    """
    name = 'kolmogorov'
    def __init__(self, *, backend='opencl', device=0, verify='modular', factory=None):
        if backend != 'opencl':
            raise ComputeError('Kolmogorov 1.1 Neo adapter supports only opencl; CUDA/ROCm/Vulkan are unvalidated.')
        if type(device) is not int or device < 0:
            raise ComputeError('OpenCL device index must be a nonnegative integer.')
        if verify not in ('modular', 'exact'):
            raise ComputeError('Verification must be modular or exact.')
        if factory is None:
            from .gpu.opencl import OpenCLBackend
            factory = OpenCLBackend
        self.backend = backend
        self.device = device
        self.verify = verify
        self._impl = factory(device_index=device)
        if not self._impl.available():
            messages = [x.detail for x in self._impl.devices()]
            raise ComputeError('Kolmogorov OpenCL unavailable: ' + '; '.join(messages))
        requested=os.environ.get('KOLMOGOROV_INT_TRANSPORT','binary')
        if requested not in ('binary','decimal'):raise ComputeError('KOLMOGOROV_INT_TRANSPORT must be binary or decimal')
        self.transport='binary-u16le-v1' if requested=='binary' and hasattr(self._impl,'multiply_int') else 'decimal-legacy'
        self.planning_seconds=0.0
        self._lock = threading.RLock()
        self.multiply_count = 0
        self.batch_groups = 0
        self.batched_products = 0
        self.gpu_wall_seconds = 0.0
        self.verification_seconds = 0.0
        self.max_transform_n = 1 << 20  # actual Kolmogorov OpenCL guard
        self.last_ntt_length = 0
        self.max_observed_ntt_length=0
        self.batch_is_fused = False  # Host-assisted API provides sequential GPU work, not a fused GPU batch.

    def prepare(self, a: int, b: int) -> PreparedMultiplication:
        if type(a) is not int or type(b) is not int:
            raise ComputeError('Kolmogorov requires Python int operands; bool is not supported.')
        if not a or not b:
            return PreparedMultiplication(1, 1, 0, 0)
        if self.transport=='binary-u16le-v1':
            limbs_a,limbs_b=(a.bit_length()+15)//16,(b.bit_length()+15)//16
        else:
            d_a,d_b=len(_int_to_decimal(abs(a))),len(_int_to_decimal(abs(b)))
            limbs_a,limbs_b=(d_a+3)//4,(d_b+3)//4
        n = required_ntt_length(limbs_a, limbs_b)
        if hasattr(self._impl, '_memory_guard'):
            self._impl._memory_guard(n)
        if n > self.max_transform_n:
            raise ComputeError('Kolmogorov OpenCL NTT over 2^20 is not supported in this host-returning API.')
        # Size estimate is conservative for cached roots and three working arrays.
        return PreparedMultiplication(limbs_a, limbs_b, n, 24*n)

    def multiply(self, a: int, b: int) -> int:
        with self._lock:
            begin_plan=time.perf_counter()
            plan = self.prepare(a,b)
            self.planning_seconds+=time.perf_counter()-begin_plan
            if plan.ntt_length == 0:
                # Intentionally never run a false GPU operation for zero.
                # Count as a special exact identity, recorded separately.
                self.multiply_count += 1
                return 0
            begin=time.perf_counter()
            if self.transport=='binary-u16le-v1':
                product=self._impl.multiply_int(a,b)
                if type(product) is not int:raise ComputeError('Binary GPU transport returned a non-int')
            else:
                lhs,rhs=_int_to_decimal(a),_int_to_decimal(b)
                out=self._impl.multiply(lhs,rhs)
                if not isinstance(out,str) or normalize_integer(out)!=out:
                    raise ComputeError('GPU produced a non-canonical integer string')
                product=_decimal_to_int(out)
            elapsed=time.perf_counter()-begin
            begin_verify=time.perf_counter()
            for prime in ((1<<61)-1,(1<<31)-1):
                if product%prime!=(a%prime)*(b%prime)%prime:
                    raise ComputeError('Kolmogorov modular verification failed. Result rejected.')
            if self.verify == 'exact' and product != a*b:
                raise ComputeError('Kolmogorov 1.1 exact verification failed. Result rejected.')
            self.verification_seconds += time.perf_counter()-begin_verify
            self.gpu_wall_seconds += elapsed
            self.last_ntt_length = plan.ntt_length
            self.max_observed_ntt_length=max(self.max_observed_ntt_length,plan.ntt_length)
            self.multiply_count += 1
            return product

    def multiply_many(self, pairs):
        """Ordered products, NO kernel fusion in hybrid integration."""
        values=list(pairs)
        with self._lock:
            result=[self.multiply(a,b) for a,b in values]
            if values:
                self.batch_groups += 1
                self.batched_products += len(values)
            return result

    def capabilities(self):
        return {'integer_transport':self.transport,'api_version':API_VERSION, 'engine':'kolmogorov',
                'supported_backends':['opencl'], 'gpu_offload':True,
                'exact_products':True, 'verification':self.verify,
                'gpu_batch_fusion':False,'maximum_ntt_length':self.max_transform_n,
                'device':self.device,'out_of_core':False}

    def metrics(self):
        return {'engine':'Kolmogorov Engine 1.1','integer_transport':self.transport,
                'planning_seconds':self.planning_seconds,
                'binary_transport_metrics':getattr(self._impl,'transport_stats',None),
                'multiplications':self.multiply_count,
                'batch_groups':self.batch_groups,
                'batch_products':self.batched_products,
                'gpu_batch_fused':self.batch_is_fused,
                'gpu_multiply_wall_seconds':round(self.gpu_wall_seconds,6),
                'verification_wall_seconds':round(self.verification_seconds,6),
                'last_ntt_length':self.last_ntt_length,'max_observed_ntt_length':self.max_observed_ntt_length,
                'device':self.device, 'backend':self.backend,
                'gpu_kernel_elapsed_seconds':None,
                'gpu_bytes_uploaded':None, 'gpu_bytes_downloaded':None}
