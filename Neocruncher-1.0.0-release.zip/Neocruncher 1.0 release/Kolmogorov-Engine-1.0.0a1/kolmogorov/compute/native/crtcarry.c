/* SPDX-License-Identifier: GPL-3.0-only
 * Bounded base-2^16 CRT/carry. No Python ABI; no OpenCL or GPU product here.
 */
#include <stdint.h>
#include <stddef.h>
int kolm_crtcarry(const uint32_t *a, const uint32_t *b, size_t n,
                 uint16_t *out, size_t capacity, uint32_t inv) {
    const uint64_t p=2013265921ULL, q=1811939329ULL;
    uint64_t carry=0;
    if (!a || !b || !out || capacity<n || capacity-n<4) return 1;
    for (size_t i=0;i<n;i++) {
        if (a[i]>=p || b[i]>=q) return 3;
        uint64_t d=((uint64_t)b[i]+q-((uint64_t)a[i]%q))%q;
        uint64_t coeff=(uint64_t)a[i]+p*((d*(uint64_t)inv)%q);
        /* p*q < 2^62; the carry is <2^47, so addition fits uint64_t. */
        uint64_t v=coeff+carry;
        out[i]=(uint16_t)(v&65535ULL); carry=v>>16;
    }
    for (size_t i=n;i<capacity;i++) {out[i]=(uint16_t)(carry&65535ULL);carry>>=16;}
    return carry ? 2 : 0;
}
