# SPDX-License-Identifier: GPL-3.0-only
"""Optional *real* OpenCL backend, with cached contexts, NTT twiddles and scratch.

Reference-grade iterative radix-2 NTT (not yet Neocruncher's batched kernels).
No OpenCL dependency is imported until discovery/use. Only OpenCL GPU devices
are considered, unless explicitly enabled for software testing.
"""
from __future__ import annotations

import os
import threading
import time
from .shared import to_result
from ..core import (ComputeError, Device, P1, P2, R1, R2, INV_P1_P2,
                    to_limbs, required_ntt_length, coefficient_bound)

# uint2 NTT modulus multiplication uses 64-bit intermediates, mandatory CL 1.2.
SOURCE = r"""
__kernel void rev(__global const uint *input, __global uint *output, uint n, uint bits) {
    uint i=get_global_id(0);
    if (i>=n) return;
    uint v=i, j=0u;
    for(uint k=0u;k<bits;k++){j=(j<<1)|(v&1u); v>>=1;}
    output[j]=input[i];
}
uint power(uint x, uint k, uint p) {
    ulong a=x, r=1ul;
    while(k){if(k&1u)r=(r*a)%(ulong)p; a=(a*a)%(ulong)p;k>>=1;}
    return (uint)r;
}
__kernel void twiddles(__global uint *out, uint half_count, uint root, uint p) {
    uint i=get_global_id(0);
    if(i<half_count) out[i]=power(root,i,p);
}
__kernel void stage(__global uint *data, __global const uint *roots,
                    uint n, uint size, uint p) {
    uint t=get_global_id(0); if(t>=n/2u) return;
    uint span=size/2u, j=t%span, i=(t/span)*size+j;
    uint u=data[i];
    uint v=(uint)(((ulong)data[i+span]*(ulong)roots[j*(n/size)])%(ulong)p);
    ulong sum=(ulong)u+(ulong)v;
    data[i]=(uint)(sum>=(ulong)p?sum-(ulong)p:sum);
    data[i+span]=u>=v?u-v:u+p-v;
}
__kernel void pointwise(__global uint *x, __global const uint *y, uint n, uint p) {
    uint i=get_global_id(0);
    if(i<n) x[i]=(uint)(((ulong)x[i]*(ulong)y[i])%(ulong)p);
}
__kernel void scale(__global uint *data, uint n, uint inv, uint p) {
    uint i=get_global_id(0);
    if(i<n) data[i]=(uint)(((ulong)data[i]*(ulong)inv)%(ulong)p);
}
"""

class OpenCLBackend:
    name = 'opencl'

    def __init__(self, device_index: int | None = None):
        self._selected_device_index = 0
        self._lock = threading.RLock()
        self._session = None
        self._kernels = None
        self._error = 'PyOpenCL y un dispositivo OpenCL GPU son opcionales.'
        self._devices = []
        self._last_ntt_length = None
        self.transport_stats=dict(packing_seconds=0.0,ntt_pipeline_seconds=0.0,crt_carry_seconds=0.0,bytes_uploaded=0,bytes_downloaded=0,workspace_allocations=0,workspace_reuses=0)
        self._host_arrays={}
        try:
            from ...environment import ensure_opencl_environment
            ensure_opencl_environment()
            import pyopencl as cl
            kind = cl.device_type.ALL if os.environ.get('KOLMOGOROV_OPENCL_ALLOW_CPU') == '1' else cl.device_type.GPU
            for platform in cl.get_platforms():
                for dev in platform.get_devices(device_type=kind):
                    self._devices.append(dev)
            selector = str(device_index) if device_index is not None else os.environ.get('KOLMOGOROV_OPENCL_DEVICE')
            if selector is not None and self._devices:
                try:
                    selected = int(selector)
                except ValueError as exc:
                    raise ComputeError('KOLMOGOROV_OPENCL_DEVICE debe ser un índice entero.') from exc
                if not 0 <= selected < len(self._devices):
                    raise ComputeError(f'Índice OpenCL {selected} fuera de rango (0..{len(self._devices)-1}).')
                self._selected_device_index = selected
                self._devices = [self._devices[selected]]
            if not self._devices:
                self._error = 'No se detectó dispositivo OpenCL GPU compatible.'
            else:
                self._error = ''
        except Exception as exc:
            self._error = f'OpenCL no disponible: {type(exc).__name__}: {exc}'

    def available(self) -> bool:
        return bool(self._devices)

    def devices(self) -> list[Device]:
        if not self._devices:
            return [Device(self.name, 'OpenCL', False, self._error)]
        return [Device(self.name, str(dev.name), True,
                       f'VRAM global={int(dev.global_mem_size)} bytes; max_alloc={int(dev.max_mem_alloc_size)}')
                for dev in self._devices]

    def _init(self):
        if self._session is not None:
            return self._session
        if not self._devices:
            raise ComputeError(self._error)
        from ...doctor import probe
        probe(self._selected_device_index)
        import pyopencl as cl
        try:
            ctx = cl.Context([self._devices[0]])
            queue = cl.CommandQueue(ctx)
            program = cl.Program(ctx, SOURCE).build()
        except Exception as exc:
            raise ComputeError(f'No se pudo inicializar OpenCL: {exc}') from exc
        # Cache kernel instances instead of repeated program attribute retrieval.
        try:
            self._kernels = {
                name: cl.Kernel(program, name)
                for name in ('rev', 'twiddles', 'stage', 'pointwise', 'scale')
            }
        except Exception as exc:
            raise ComputeError(f'No se pudieron crear los kernels OpenCL: {exc}') from exc
        self._session = (cl, ctx, queue, program, {}, {})
        return self._session

    def _memory_guard(self, n: int):
        dev = self._devices[0]
        # 3 NTT arrays + scratch, 2 root tables/prime. Conservative guard,
        # currently the 2 prime caches may both be resident.
        per_buffer = 4*n
        max_one = int(dev.max_mem_alloc_size)
        total = int(dev.global_mem_size)
        if per_buffer > max_one or 24*n > total//2:
            raise ComputeError('OpenCL: NTT excede presupuesto defensivo de VRAM.')
        if n > (1<<20):
            raise ComputeError('OpenCL: NTT > 2^20 requiere planificación de memoria por bloques.')

    def _prepare_size(self, n: int):
        """Limit cache to one NTT length to prevent unbounded VRAM retention."""
        if self._last_ntt_length == n:
            return
        if self._session is not None:
            _,_,queue,_,tables,workspaces = self._session
            queue.finish()  # Do not free in-flight device buffers.
            tables.clear()
            workspaces.clear()
            if hasattr(self,'_host_arrays'):self._host_arrays.clear()
        self._last_ntt_length = n

    def _tables(self, p: int, generator: int, n: int):
        import numpy as np
        cl,ctx,queue,prg,table_cache,workspace_cache=self._session
        key=(p,n)
        if key not in table_cache:
            root=pow(generator,(p-1)//n,p)
            reverse=pow(root,-1,p)
            length=max(1,n//2)
            forward=cl.Buffer(ctx,cl.mem_flags.READ_WRITE, size=length*4)
            inverse=cl.Buffer(ctx,cl.mem_flags.READ_WRITE, size=length*4)
            if n>1:
                self._kernels['twiddles'](queue,(n//2,),None,forward,np.uint32(n//2),np.uint32(root),np.uint32(p))
                self._kernels['twiddles'](queue,(n//2,),None,inverse,np.uint32(n//2),np.uint32(reverse),np.uint32(p))
            table_cache[key]=(forward,inverse)
        return table_cache[key]

    def _workspace(self,n):
        cl,ctx,queue,prg,tables,cache=self._session
        if n not in cache:
            self.transport_stats['workspace_allocations']+=3
            cache[n]=tuple(cl.Buffer(ctx,cl.mem_flags.READ_WRITE,size=n*4) for _ in range(3))
        else:
            self.transport_stats['workspace_reuses']+=1
        return cache[n]

    def _transform(self, data, scratch, roots, p, n, inverse):
        import numpy as np
        cl,ctx,q,prg,_,_=self._session
        if n>1:
            bits=n.bit_length()-1
            self._kernels['rev'](q,(n,),None,data,scratch,np.uint32(n),np.uint32(bits))
            cl.enqueue_copy(q,data,scratch)
            for s in range(1,bits+1):
                self._kernels['stage'](q,(n//2,),None,data,roots,np.uint32(n),np.uint32(1<<s),np.uint32(p))
        if inverse:
            self._kernels['scale'](q,(n,),None,data,np.uint32(n),np.uint32(pow(n,-1,p)),np.uint32(p))

    def _convolve_prime(self,a,b,p,root,n):
        import numpy as np
        cl,ctx,q,prg,_,_=self._session
        forward,backward=self._tables(p,root,n)
        x,y,scratch=self._workspace(n)
        if n not in self._host_arrays:
            self._host_arrays[n]=(np.empty(n,dtype=np.uint32),np.empty(n,dtype=np.uint32))
        lhs,rhs=self._host_arrays[n]
        lhs.fill(0);rhs.fill(0)
        lhs[:len(a)]=a;rhs[:len(b)]=b
        cl.enqueue_copy(q,x,lhs)
        cl.enqueue_copy(q,y,rhs)
        self.transport_stats['bytes_uploaded']+=lhs.nbytes+rhs.nbytes
        self._transform(x,scratch,forward,p,n,False)
        self._transform(y,scratch,forward,p,n,False)
        self._kernels['pointwise'](q,(n,),None,x,y,np.uint32(n),np.uint32(p))
        self._transform(x,scratch,backward,p,n,True)
        out=np.empty(len(a)+len(b)-1,dtype=np.uint32)
        # Device -> host: the NumPy array size determines how much to copy.
        # Passing byte_count here is incompatible with PyOpenCL read-buffer API.
        cl.enqueue_copy(q, out, x, is_blocking=True)
        self.transport_stats['bytes_downloaded']+=out.nbytes
        return out

    def multiply(self, lhs: str, rhs: str) -> str:
        if not self.available():
            raise ComputeError(self._error)
        if lhs == '0' or rhs == '0':
            return '0'
        # Session/workspace are shared; serialize access to avoid races.
        with self._lock:
            a=to_limbs(lhs); b=to_limbs(rhs)
            n=required_ntt_length(len(a),len(b))
            self._memory_guard(n)
            try:
                self._init()
                self._prepare_size(n)
                c1=self._convolve_prime(a,b,P1,R1,n)
                c2=self._convolve_prime(a,b,P2,R2,n)
                coeff=[int(x)+P1*((((int(y)-int(x))%P2)*INV_P1_P2)%P2)
                       for x,y in zip(c1,c2)]
                return to_result(coeff, lhs, rhs)
            except ComputeError:
                raise
            except Exception as exc:
                raise ComputeError(f'Error OpenCL: {type(exc).__name__}: {exc}') from exc

    def multiply_int(self,lhs:int,rhs:int)->int:
        """Exact binary transport; independent Kolmogorov NTT kernels retained."""
        if type(lhs) is not int or type(rhs) is not int:
            raise ComputeError('Binary transport requires Python int operands')
        if not self.available():raise ComputeError(self._error)
        if not lhs or not rhs:return 0
        from ..binary import limbs,reconstruct
        with self._lock:
            begin=time.perf_counter()
            a,b=limbs(lhs),limbs(rhs)
            n=required_ntt_length(len(a),len(b))
            if min(len(a),len(b))*65535**2>=P1*P2:
                raise ComputeError('Binary CRT coefficient bound exceeded')
            self.transport_stats['packing_seconds']+=time.perf_counter()-begin
            self._memory_guard(n)
            self._init();self._prepare_size(n)
            begin=time.perf_counter()
            c1=self._convolve_prime(a,b,P1,R1,n)
            c2=self._convolve_prime(a,b,P2,R2,n)
            self.transport_stats['ntt_pipeline_seconds']+=time.perf_counter()-begin
            begin=time.perf_counter()
            value=reconstruct(c1,c2)
            self.transport_stats['crt_carry_seconds']+=time.perf_counter()-begin
            return -value if (lhs<0)^(rhs<0) else value
