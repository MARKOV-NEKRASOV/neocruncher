# SPDX-License-Identifier: GPL-3.0-only
"""Internal GPU adapter helpers. No vendor-specific imports."""
from ..core import from_coefficients

class BackendUnavailable(Exception):
    pass

def to_result(coefficients, lhs, rhs):
    return from_coefficients(coefficients, lhs.startswith('-') != rhs.startswith('-'))
