# SPDX-License-Identifier: GPL-3.0-only
"""Constants whose complete numeric path uses DeviceInteger operations.

Python calculates only term counts, indices, precision and control flow.
Interval arithmetic, reciprocal, sqrt and decimal conversion stay on GPU.
"""
import math
import time

SUPPORTED = ('pi_chudnovsky','e_taylor','sqrt2_integer','phi_integer')

def exp_terms(places):
    target=(places+21)*math.log(10)
    lo,hi=1,16
    while math.lgamma(hi+2)<=target:hi*=2
    while lo+1<hi:
        mid=(lo+hi)//2
        if math.lgamma(mid+2)>target:hi=mid
        else:lo=mid
    return hi

def calculate(rt, algorithm, places, progress=None):
    if algorithm not in SUPPORTED:
        raise NotImplementedError('No complete GPU-pure path for this algorithm; choose hybrid or CPU')
    if type(places) is not int or not 1<=places<2**32-1:
        raise ValueError('Precision must fit the resident output index space')
    timings={};last_phase=None;last_time=time.perf_counter()
    def phase(label):
        nonlocal last_phase,last_time
        rt.queue.finish()
        now=time.perf_counter()
        if last_phase is not None:timings[last_phase]=timings.get(last_phase,0.0)+now-last_time
        last_phase=label;last_time=now
        if progress:progress(dict(stage=label,percent=None,work_done=0,work_total=0,certified_decimal_digits=0,completed_phase_wall_seconds=dict(timings),metrics=dict(rt.metrics)))
    phase('GPU precision scale')
    scale=rt.power(10,places)
    if algorithm in ('sqrt2_integer','phi_integer'):
        phase('GPU integer square root')
        value=rt.isqrt((2 if algorithm=='sqrt2_integer' else 5)*scale*scale)
        if algorithm=='phi_integer':value=(scale+value)//2
        terms=0
    elif algorithm=='e_taylor':
        terms=exp_terms(places)
        for _ in range(8):
            phase('GPU series construction')
            fact,extra=rt.chunks('exp',1,terms+1,progress)
            phase('GPU division and enclosing interval')
            quotient,remainder=rt.divmod(extra*scale,fact)
            low=scale+quotient
            if remainder*(terms+1)+2*scale < fact*(terms+1):value=low;break
            terms+=2
        else:raise ArithmeticError('GPU e interval failed to certify prefix')
    else:
        terms=max(2,places//14+4)
        root_scale=scale*rt.power(10,24)
        phase('GPU integer square root')
        root=rt.isqrt(10005*root_scale*root_scale)
        for _ in range(6):
            phase('GPU series construction')
            p,q,t=rt.chunks('chud',0,terms,progress)
            pn,qn,tn=rt.chunks('chud',terms,terms+1)
            q2=q*qn;t2=t*qn+p*tn
            if t<=0 or t2<=0:raise ArithmeticError('GPU Chudnovsky denominator invalid')
            phase('GPU division and enclosing interval')
            lq,lt,hq,ht=(q2,t2,q,t) if terms%2==0 else (q,t,q2,t2)
            guard=rt.power(10,24)
            low=(426880*root*lq)//(guard*lt)
            high=(426880*(root+1)*hq)//(guard*ht)
            if low==high:value=low;break
            terms+=2
        else:raise ArithmeticError('GPU pi interval failed to certify prefix')
    phase('GPU decimal conversion')
    digits=rt.decimal(value,places+1)
    text=digits[:-places]+'.'+digits[-places:]
    rt.queue.finish()
    rt.profile.drain()
    timings[last_phase]=timings.get(last_phase,0.0)+time.perf_counter()-last_time
    return text,dict(phase_wall_seconds=timings,algorithm=algorithm,terms=terms,
        certification='GPU integer enclosing interval: identical decimal prefixes',
        arithmetic_location='GPU only',coordinator='CPU control and metadata only',
        storage='VRAM with explicit RAM storage spill; no host arithmetic',
        gpu_pure=True,driver=rt.driver.name,metrics=dict(rt.metrics),
        profiling_scope='Sum of kernel device event durations; excludes host, transfers and compilation; not end-to-end time',
        hardware_qualification='Requires device-specific validation; not inferred from source or software checks')
