# SPDX-License-Identifier: GPL-3.0-only
"""GPU-resident integer arithmetic, with explicit storage-only host spilling."""
from .runtime import DeviceArithmetic, DeviceInteger

__all__ = ['DeviceArithmetic', 'DeviceInteger']
