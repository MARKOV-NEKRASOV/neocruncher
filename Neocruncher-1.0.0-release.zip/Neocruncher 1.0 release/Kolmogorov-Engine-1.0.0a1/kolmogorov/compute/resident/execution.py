# SPDX-License-Identifier: GPL-3.0-only
"""Bounded same-queue scratch reuse and device event accounting.

Scratch leases must be returned only after the final command using them has
been enqueued. Reuse is safe on the single IN-ORDER queue, even when commands
remain in flight. Never share this pool between queues or retain leased buffers.
"""
from contextlib import contextmanager

class ScratchPool:
    def __init__(self, allocate, limit, metrics):
        self.allocate=allocate;self.limit=limit;self.metrics=metrics;self.free={};self.bytes=0
    def trim(self):self.free.clear();self.bytes=0
    @contextmanager
    def lease(self,*sizes):
        buffers=[]
        try:
            for size in sizes:
                size=max(2,int(size));bucket=self.free.get(size,[])
                if bucket:
                    buf=bucket.pop();self.bytes-=size;self.metrics['scratch_reuses']+=1
                else:buf=self.allocate(size)
                buffers.append(buf)
            yield buffers
        finally:
            for buf in buffers:
                if buf.size>self.limit:continue
                if self.bytes+buf.size>self.limit:self.trim()
                self.free.setdefault(buf.size,[]).append(buf);self.bytes+=buf.size
            self.metrics['scratch_cached_bytes']=self.bytes

class EventProfile:
    def __init__(self,metrics):self.events=[];self.metrics=metrics
    def add(self,event):
        self.events.append(event)
        if len(self.events)>=256:self.drain()
        return event
    def drain(self):
        for event in self.events:
            event.wait()
            try:
                seconds=(event.profile.end-event.profile.start)*1e-9
                self.metrics['kernel_device_seconds']+=seconds
                self.metrics['profiled_kernel_events']+=1
            except Exception:  # Missing profiling must not invalidate completed arithmetic.
                self.metrics['unprofiled_kernel_events']+=1
        self.events.clear()
