# SPDX-License-Identifier: GPL-3.0-only
"""Kolmogorov transform schedule, consuming and producing device buffers."""
import numpy as np

class KolmogorovDriver:
    name='kolmogorov-resident'
    max_points=1<<18

    def __init__(self, device=0):
        from ..gpu.opencl import OpenCLBackend
        import os
        if os.environ.get('KOLMOGOROV_OPENCL_ALLOW_CPU')=='1':
            raise RuntimeError('GPU pure requires a GPU; software OpenCL devices are not accepted')
        self.backend=OpenCLBackend(device)
        self.cl,self.ctx,self.queue,self.program,_,_=self.backend._init()
        self.device=self.backend._devices[0]
        self.queue=self.cl.CommandQueue(self.ctx,properties=self.cl.command_queue_properties.PROFILING_ENABLE)

    def convolve(self, rt, a, b, n):
        if not hasattr(self,'_roots'):self._roots={}
        results=[]
        for p,generator in ((2013265921,31),(1811939329,13)):
            tables=[]
            for inverse in (False,True):
                key=(n,p,inverse)
                if key not in self._roots:
                    roots=rt._raw((n//2)*4);params=rt._raw(8)
                    rt.run('r_ntt_setup',1,params,rt._u(p),rt._u(generator),rt._u(n),rt._u(inverse))
                    rt.run('r_ntt_roots',n//2,roots,params,rt._u(p))
                    self._roots[key]=roots,params
                tables.append(self._roots[key])
            x,tmp=(rt._raw(n*4) for _ in range(2))
            y=x if a is b else rt._raw(n*4)
            rt.run('r_pack_ntt',n,rt.buffer(a),rt._u(a.n),rt._u(0),x,rt._u(n))
            if a is not b:rt.run('r_pack_ntt',n,rt.buffer(b),rt._u(b.n),rt._u(0),y,rt._u(n))
            def transform(buf,inverse=False):
                k=self.backend._kernels
                rt.launch(k['rev'],n,buf,tmp,np.uint32(n),np.uint32(n.bit_length()-1))
                self.cl.enqueue_copy(self.queue,buf,tmp,byte_count=n*4)
                size=2
                while size<=n:
                    rt.launch(k['stage'],n//2,buf,tables[bool(inverse)][0],np.uint32(n),np.uint32(size),np.uint32(p))
                    size*=2
                if inverse:rt.run('r_ntt_normalize',n,buf,tables[1][1],rt._u(p))
            transform(x)
            if a is not b:transform(y)
            rt.launch(self.backend._kernels['pointwise'],n,x,y,np.uint32(n),np.uint32(p))
            transform(x,True);results.append(x)
        return results

    @property
    def cached_bytes(self):
        return sum(buf.size for pair in getattr(self,'_roots',{}).values() for buf in pair)
