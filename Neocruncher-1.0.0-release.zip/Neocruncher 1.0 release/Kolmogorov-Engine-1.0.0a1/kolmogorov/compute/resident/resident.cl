/* SPDX-License-Identifier: GPL-3.0-only
 * Device integer operations. Numeric limbs never cross to the host except
 * explicit storage spill; host reads only lengths, comparisons and errors.
 */
__kernel void r_constant(__global ushort *o, ulong x, uint n) {
    for(uint i=0;i<n;i++){o[i]=(ushort)(x&65535ul);x>>=16;}
}
__kernel void r_meta(__global const ushort *a,uint n,__global uint *m){
    while(n && !a[n-1])n--;m[0]=n;
    m[1]=n?32u-clz((uint)a[n-1]):0u;
}
/* Each work item examines at most 1024 limbs, then a short reduction. */
__kernel void r_meta_parts(__global const ushort *a,uint n,__global uint *parts){
    uint block=get_global_id(0),start=block*1024u,end=min(n,start+1024u);
    while(end>start&&!a[end-1])end--;
    parts[block]=end>start?end:0u;
}
__kernel void r_meta_finish(__global const ushort *a,__global const uint *parts,uint blocks,__global uint *m){
    uint n=0;for(uint i=0;i<blocks;i++)n=max(n,parts[i]);
    m[0]=n;m[1]=n?32u-clz((uint)a[n-1]):0u;
}
__kernel void r_compare(__global const ushort *a,uint na,__global const ushort *b,uint nb,__global int *o){
    if(na!=nb){o[0]=na>nb?1:-1;return;}
    for(uint i=na;i>0;i--)if(a[i-1]!=b[i-1]){o[0]=a[i-1]>b[i-1]?1:-1;return;}
    o[0]=0;
}
__kernel void r_add_coeff(__global const ushort *a,uint na,__global const ushort *b,uint nb,__global ulong *c){
    uint i=get_global_id(0);c[i]=(i<na?(ulong)a[i]:0ul)+(i<nb?(ulong)b[i]:0ul);
}
/* Subtraction borrow: independent blocks evaluate incoming 0 and 1. */
__kernel void r_sub_bounds(__global const ushort *a,uint na,__global const ushort *b,uint nb,
                           __global ulong *lo,__global ulong *hi){
    uint block=get_global_id(0),start=block*1024u,end=min(na,start+1024u);
    uint x=0,y=1;
    for(uint i=start;i<end;i++){uint av=a[i],bv=i<nb?b[i]:0;x=av<bv+x;y=av<bv+y;}
    lo[block]=x;hi[block]=y;
}
__kernel void r_sub_scan(__global const ulong *lo,__global const ulong *hi,__global ulong *incoming,uint blocks){
    uint borrow=0;
    for(uint i=0;i<blocks;i++){incoming[i]=borrow;borrow=borrow?hi[i]:lo[i];}
}
__kernel void r_sub_digits(__global const ushort *a,uint na,__global const ushort *b,uint nb,
                           __global const ulong *incoming,__global ushort *o){
    uint block=get_global_id(0),start=block*1024u,end=min(na,start+1024u),borrow=incoming[block];
    for(uint i=start;i<end;i++){uint av=a[i],bv=(i<nb?b[i]:0)+borrow;o[i]=(ushort)((av-bv)&65535u);borrow=av<bv;}
}
__kernel void r_shift(__global const ushort *a,uint na,__global ushort *o,uint no,uint words,uint bits,uint right){
    uint i=get_global_id(0);uint v=0;
    if(right){uint j=i+words;if(j<na)v=(uint)a[j]>>bits;if(bits && j+1<na)v|=(uint)a[j+1]<<(16-bits);}
    else if(i>=words){uint j=i-words;if(j<na)v=(uint)a[j]<<bits;if(bits && j && j-1<na)v|=(uint)a[j-1]>>(16-bits);}
    o[i]=(ushort)(v&65535u);
}
__kernel void r_pack_ntt(__global const ushort *a,uint na,uint offset,__global uint *o,uint n){
    uint i=get_global_id(0);o[i]=i+offset<na?a[i+offset]:0u;
}
/* Exact short division, used for tiny Newton base cases, not large operands. */
__kernel void r_div_short(__global const ushort *a,uint na,__global const ushort *b,uint nb,
                          __global ushort *q,__global ushort *r,uint cap){
    for(uint i=0;i<cap;i++){q[i]=0;r[i]=0;}
    uint nr=0;
    for(uint t=na*16u;t>0;t--){
        uint carry=(a[(t-1)/16]>>((t-1)%16))&1u;
        for(uint j=0;j<nr;j++){uint v=((uint)r[j]<<1)|carry;r[j]=v&65535u;carry=v>>16;}
        if(carry)r[nr++]=carry;
        if(!nr && ((a[(t-1)/16]>>((t-1)%16))&1u)){r[0]=1;nr=1;}
        int cmp=nr>nb?1:nr<nb?-1:0;
        if(!cmp)for(uint j=nr;j>0;j--)if(r[j-1]!=b[j-1]){cmp=r[j-1]>b[j-1]?1:-1;break;}
        if(cmp>=0){uint borrow=0;for(uint j=0;j<nr;j++){uint bv=(j<nb?b[j]:0)+borrow,av=r[j];r[j]=(av-bv)&65535u;borrow=av<bv;}while(nr&&!r[nr-1])nr--;q[(t-1)/16]|=1u<<((t-1)%16);}
    }
}
/* Conversion is bounded per leaf. Only final ASCII bytes leave the device. */
__kernel void r_decimal_leaf(__global const ushort *a,uint na,__global ushort *scratch,
                             __global char *out,uint offset,uint count,__global uint *error){
    for(uint i=0;i<na;i++)scratch[i]=a[i];
    uint n=na;
    for(uint j=count;j>0;j--){uint rem=0;for(uint k=n;k>0;k--){uint v=(rem<<16)|scratch[k-1];scratch[k-1]=v/10u;rem=v%10u;}
        out[offset+j-1]=(char)('0'+rem);while(n&&!scratch[n-1])n--;}
    error[0]=n?1u:0u;
}
__kernel void r_decimal_batch(__global const ushort *a,__global const uint *meta,__global ushort *scratch,
                              __global char *out,__global uint *errors){
    uint item=get_global_id(0),base=item*4u,ao=meta[base],na=meta[base+1],offset=meta[base+2],count=meta[base+3];
    for(uint i=0;i<na;i++)scratch[ao+i]=a[ao+i];
    uint n=na;
    for(uint j=count;j>0;j--){
        uint rem=0;
        for(uint k=n;k>0;k--){uint v=(rem<<16)|scratch[ao+k-1];scratch[ao+k-1]=v/10u;rem=v%10u;}
        out[offset+j-1]=(char)('0'+rem);
        while(n&&!scratch[ao+n-1])n--;
    }
    errors[item]=n?1u:0u;
}
inline ulong r_residue(__global const ushort *a,uint n,uint p){
    ulong r=0;for(uint i=n;i>0;i--)r=((r<<16)+(ulong)a[i-1])%(ulong)p;return r;
}
__kernel void r_product_check(__global const ushort *a,uint na,__global const ushort *b,uint nb,
                              __global const ushort *c,uint nc,__global uint *error){
    uint primes[2]={2147483647u,2147483629u};uint failed=0;
    for(uint j=0;j<2;j++){uint p=primes[j];ulong x=r_residue(a,na,p),y=r_residue(b,nb,p),z=r_residue(c,nc,p);
        if(x*y%(ulong)p!=z)failed=1;}
    error[0]=failed;
}
/* Weighted residue blocks; all numerical reduction remains on the GPU.
 * r_j = (sum a[1024*j+i]*B^i)*B^(1024*j) mod p, B=65536.
 * p < 2^31, so products fit ulong. Reduction sums are reduced at each step.
 */
__kernel void r_residue_parts(__global const ushort *a,uint n,__global uint *parts){
    uint block=get_global_id(0),start=block*1024u,end=min(n,start+1024u);
    uint primes[2]={2147483647u,2147483629u};
    for(uint j=0;j<2;j++){
        uint p=primes[j];ulong r=0;
        for(uint i=end;i>start;i--)r=((r<<16)+(ulong)a[i-1])%(ulong)p;
        parts[block*2+j]=(uint)(r*modpow(65536u,start,p)%(ulong)p);
    }
}
inline ulong r_parts_sum(__global const uint *a,uint n,uint j,uint p){
    ulong r=0;for(uint i=0;i<n;i++)r=(r+a[i*2+j])%(ulong)p;return r;
}
__kernel void r_product_check_parts(__global const uint *a,uint na,__global const uint *b,uint nb,
                                    __global const uint *c,uint nc,__global uint *error){
    uint primes[2]={2147483647u,2147483629u},failed=0;
    for(uint j=0;j<2;j++){
        uint p=primes[j];ulong x=r_parts_sum(a,na,j,p),y=r_parts_sum(b,nb,j,p),z=r_parts_sum(c,nc,j,p);
        if(x*y%(ulong)p!=z)failed=1;
    }
    error[0]=failed;
}
/* Transform scalar arithmetic is also performed on the device. */
__kernel void r_ntt_setup(__global uint *params,uint p,uint generator,uint n,uint inverse){
    uint root=modpow(generator,(p-1u)/n,p);
    params[0]=inverse?modpow(root,p-2u,p):root;
    params[1]=modpow(n,p-2u,p);
}
__kernel void r_ntt_roots(__global uint *roots,__global const uint *params,uint p){
    roots[get_global_id(0)]=modpow(params[0],get_global_id(0),p);
}
__kernel void r_ntt_normalize(__global uint *data,__global const uint *params,uint p){
    uint i=get_global_id(0);data[i]=(uint)((ulong)data[i]*params[1]%(ulong)p);
}
/* One GPU item constructs one bounded exp(+1) interval. No CPU terms. */
#define R_SMALL 2048
inline void r_small_mul(__private ushort *a,__private uint *n,ulong f,__private uint *error){
    /* Multiplier is <=32 bits in exp chunks. */
    ulong carry=0;for(uint i=0;i<*n;i++){ulong v=(ulong)a[i]*f+carry;a[i]=v&65535ul;carry=v>>16;}
    while(carry){if(*n>=R_SMALL){*error=1;return;}a[(*n)++]=carry&65535ul;carry>>=16;}
}
__kernel void r_exp_chunks(__global ushort *p,__global ushort *t,__global uint *meta,
                           uint start,uint stop,uint chunk){
    uint id=get_global_id(0),a=start+id*chunk,b=a+min(chunk,stop-a),np=1,nt=0,error=0;
    ushort pp[R_SMALL],tt[R_SMALL];pp[0]=1;
    for(uint k=a;k<b;k++){
        r_small_mul(pp,&np,k,&error);r_small_mul(tt,&nt,k,&error);
        uint i=0,carry=1;while(carry){if(i>=R_SMALL){error=1;break;}uint v=(i<nt?tt[i]:0)+carry;tt[i]=v&65535u;carry=v>>16;if(i>=nt)nt=i+1;i++;}
    }
    for(uint i=0;i<R_SMALL;i++){p[id*R_SMALL+i]=i<np?pp[i]:0;t[id*R_SMALL+i]=i<nt?tt[i]:0;}
    meta[id*3]=np;meta[id*3+1]=nt;meta[id*3+2]=error;
}
inline void r_small_product(__private const ushort *a,uint na,__private const ushort *b,uint nb,
                             __private ushort *o,__private uint *no,__private uint *error){
    if(na+nb>R_SMALL){*error=1;*no=0;return;}
    uint n=na+nb;for(uint i=0;i<n;i++)o[i]=0;
    for(uint i=0;i<na;i++){ulong carry=0;for(uint j=0;j<nb;j++){
        ulong v=(ulong)a[i]*b[j]+o[i+j]+carry;o[i+j]=v&65535ul;carry=v>>16;}
        o[i+nb]=(ushort)carry;}
    while(n&&!o[n-1])n--;*no=n;
}
inline void r_small_u64(__private ushort *a,__private uint *n,ulong f,__private uint *error){
    ushort b[4],o[R_SMALL];uint nb=0,no=0;
    while(f){b[nb++]=f&65535ul;f>>=16;}
    r_small_product(a,*n,b,nb,o,&no,error);for(uint i=0;i<no;i++)a[i]=o[i];*n=no;
}
__kernel void r_chud_chunks(__global ushort *p,__global ushort *q,__global ushort *t,__global uint *meta,
                            uint start,uint stop,uint chunk){
    uint id=get_global_id(0),a=start+id*chunk,b=a+min(chunk,stop-a),np=1,nq=1,nt=0,error=0;
    int ts=0;
    ushort pp[R_SMALL],qq[R_SMALL],tt[R_SMALL],u[R_SMALL],v[R_SMALL],temp[R_SMALL];pp[0]=1;qq[0]=1;
    for(uint k=a;k<b;k++){
        ushort lp[16],lq[16],lt[16];uint nlp=1,nlq=1,nlt=0;
        /* Leaf values use at most 16 limbs. Build in large scratch to reuse
         * checked helpers without any private-array capacity mismatch. */
        uint ns=1;temp[0]=1;
        if(k){r_small_u64(temp,&ns,(ulong)6*k-5,&error);r_small_u64(temp,&ns,(ulong)2*k-1,&error);r_small_u64(temp,&ns,(ulong)6*k-1,&error);}
        nlp=ns;for(uint i=0;i<nlp;i++)lp[i]=temp[i];
        if(k){r_small_u64(temp,&ns,13591409ul+545140134ul*k,&error);}else{temp[0]=1;ns=1;r_small_u64(temp,&ns,13591409ul,&error);}
        nlt=ns;for(uint i=0;i<nlt;i++)lt[i]=temp[i];
        temp[0]=1;ns=1;
        if(k){r_small_u64(temp,&ns,k,&error);r_small_u64(temp,&ns,k,&error);r_small_u64(temp,&ns,k,&error);r_small_u64(temp,&ns,10939058860032000ul,&error);}
        nlq=ns;for(uint i=0;i<nlq;i++)lq[i]=temp[i];
        uint nu=0,nv=0;
        r_small_product(tt,nt,lq,nlq,u,&nu,&error);
        r_small_product(pp,np,lt,nlt,v,&nv,&error);
        int vs=(k&1u)?-1:1;
        if(!nt)ts=vs;
        if(ts==vs){uint carry=0,n=max(nu,nv);for(uint i=0;i<n;i++){
            uint val=(i<nu?u[i]:0)+(i<nv?v[i]:0)+carry;tt[i]=val&65535u;carry=val>>16;}
            nt=n;if(carry){if(nt>=R_SMALL)error=1;else tt[nt++]=carry;}
        }else{
            int cmp=nu>nv?1:nu<nv?-1:0;if(!cmp)for(uint i=nu;i>0;i--)if(u[i-1]!=v[i-1]){cmp=u[i-1]>v[i-1]?1:-1;break;}
            uint n=max(nu,nv),borrow=0;for(uint i=0;i<n;i++){
                uint av=cmp>=0?(i<nu?u[i]:0):(i<nv?v[i]:0);
                uint bv=(cmp>=0?(i<nv?v[i]:0):(i<nu?u[i]:0))+borrow;
                tt[i]=(av-bv)&65535u;borrow=av<bv;}
            nt=n;while(nt&&!tt[nt-1])nt--;if(cmp<0)ts=vs;
        }
        r_small_product(pp,np,lp,nlp,temp,&ns,&error);np=ns;for(uint i=0;i<np;i++)pp[i]=temp[i];
        r_small_product(qq,nq,lq,nlq,temp,&ns,&error);nq=ns;for(uint i=0;i<nq;i++)qq[i]=temp[i];
        if(error)break;
    }
    for(uint i=0;i<R_SMALL;i++){p[id*R_SMALL+i]=i<np?pp[i]:0;q[id*R_SMALL+i]=i<nq?qq[i]:0;t[id*R_SMALL+i]=i<nt?tt[i]:0;}
    meta[id*5]=np;meta[id*5+1]=nq;meta[id*5+2]=nt;meta[id*5+3]=ts<0?1:0;meta[id*5+4]=error;
}

/* Parallel compare: highest differing index wins; numerical decision stays GPU. */
__kernel void r_compare_parts(__global const ushort *a,__global const ushort *b,uint n,__global uint *parts){
    uint block=get_global_id(0),start=block*1024u,end=min(n,start+1024u),found=0;
    while(end>start){end--;if(a[end]!=b[end]){found=end+1u;break;}}
    parts[block]=found;
}
__kernel void r_reduce_max(__global const uint *a,uint n,__global uint *out){
    uint i=get_global_id(0)*2u;out[i/2u]=i+1u<n?max(a[i],a[i+1u]):a[i];
}
__kernel void r_compare_finish(__global const ushort *a,__global const ushort *b,__global const uint *index,__global int *out){
    uint n=index[0];out[0]=n?(a[n-1u]>b[n-1u]?1:-1):0;
}
