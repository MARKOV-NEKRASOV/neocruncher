/* SPDX-License-Identifier: GPL-3.0-only */
/* Portable radix-2 number theoretic transform. All arithmetic exact.
 * A kernel dispatch is a global stage barrier. No floating-point FFT.
 */
inline uint modpow(uint base,uint power,uint modulus) {
    uint value=1;
    while(power){
        if(power & 1u)value=(uint)(((ulong)value*(ulong)base)%modulus);
        base=(uint)(((ulong)base*(ulong)base)%modulus);
        power>>=1u;
    }
    return value;
}
__kernel void bit_reverse(__global const uint *src,__global uint *dst,uint bits){
    uint i=get_global_id(0), r=0u, v=i;
    for(uint k=0;k<bits;++k){r=(r<<1)|(v&1u);v>>=1u;}
    dst[r]=src[i];
}
/* 0.3.6: exact in-place bit reversal. Only the thread with i < reversed(i)
 * exchanges the pair; no other work item writes to either element.
 * Avoids one full-sized temporary OpenCL allocation for each transform.
 */
__kernel void bit_reverse_inplace(__global uint *data,uint bits){
    uint i=get_global_id(0),r=0u,v=i;
    for(uint k=0u;k<bits;++k){r=(r<<1u)|(v&1u);v>>=1u;}
    if(i<r){
        uint tmp=data[i];
        data[i]=data[r];
        data[r]=tmp;
    }
}
__kernel void make_roots(__global uint *roots,uint omega,uint p){
    uint j=get_global_id(0);
    roots[j]=modpow(omega,j,p);
}
__kernel void butterfly(__global uint *data,__global const uint *roots,uint span,uint p){
    uint id=get_global_id(0);
    uint j=id%span;
    uint k=(id/span)*(span*2u)+j;
    uint a=data[k];
    uint b=(uint)(((ulong)data[k+span]*(ulong)roots[j])%p);
    uint sum=a+b;
    if(sum>=p)sum-=p;
    uint diff=(a>=b)? a-b : a+p-b;
    data[k]=sum;
    data[k+span]=diff;
}
__kernel void pointwise(__global uint *a,__global const uint *b,uint p){
    uint i=get_global_id(0);
    a[i]=(uint)(((ulong)a[i]*(ulong)b[i])%p);
}
__kernel void normalize(__global uint *data,uint inv_n,uint p){
    uint i=get_global_id(0);
    data[i]=(uint)(((ulong)data[i]*(ulong)inv_n)%p);
}

/* GPU CRT: p*q < 2**62, each reconstructed coefficient fits in ulong.
 * Input vectors contain exact (nonnegative) NTT coefficients mod p and q.
 */
__kernel void crt_coefficients(__global const uint *left,
                               __global const uint *right,
                               __global ulong *combined,
                               const uint p,const uint q,const uint inverse){
    uint i=get_global_id(0);
    ulong residue_left=(ulong)left[i]%(ulong)q;
    ulong difference=((ulong)right[i]+(ulong)q-residue_left)%(ulong)q;
    ulong factor=(difference*(ulong)inverse)%(ulong)q;
    combined[i]=(ulong)left[i]+(ulong)p*factor;
}
/* Exact reference carry propagation inside GPU memory.
 * Intentionally one work-item: safe but slow. Future work is parallel scan.
 * Four extra 16-bit limbs accommodate carry from supported convolution size.
 */
__kernel void crt_carry_serial(__global const ulong *combined,
                               __global ushort *digits,
                               const uint n,
                               __global uint *overflow){
    ulong carry=0ul;
    for(uint i=0u;i<n;++i){
        ulong v=combined[i]+carry;
        digits[i]=(ushort)(v & 65535ul);
        carry=v>>16;
    }
    for(uint j=0u;j<4u;++j){
        digits[n+j]=(ushort)(carry & 65535ul);
        carry>>=16;
    }
    overflow[0]=(carry!=0ul)?1u:0u;
}

/* GPU-side direct convolution for small operands: one dispatch rather than
 * six NTTs and many radix-2 stages. Each coefficient is independently exact.
 * The following carry pass still runs on the GPU, but is serial (v0.3.4).
 * The 128-limb limit guarantees coefficient sums fit in an unsigned 64-bit word.
 */
__kernel void schoolbook_coefficients(__global const ushort *a,
                                     const uint na,
                                     __global const ushort *b,
                                     const uint nb,
                                     __global ulong *coefficients){
    uint k=get_global_id(0);
    uint first=(k>=nb-1u)?(k-nb+1u):0u;
    uint last=min(k,na-1u);
    ulong total=0ul;
    for(uint j=first;j<=last;++j){
        total+=(ulong)a[j]*(ulong)b[k-j];
    }
    coefficients[k]=total;
}


/* v0.3.5 experimental GPU batching. Metadata per item:
 * a_offset, b_offset, a_length, b_length, coefficient_offset, output_offset.
 * Coefficients are independent across items and within each product.
 */
__kernel void batch_schoolbook_coefficients(__global const ushort *a,
                                             __global const ushort *b,
                                             __global const uint *meta,
                                             __global ulong *coefficients) {
    const uint k=get_global_id(0);
    const uint item=get_global_id(1);
    const uint base=6u*item;
    const uint ao=meta[base],bo=meta[base+1u];
    const uint na=meta[base+2u],nb=meta[base+3u];
    const uint co=meta[base+4u];
    const uint n=na+nb-1u;
    if(k>=n) return;
    const uint first=(k>=nb-1u)?(k-nb+1u):0u;
    const uint last=min(k,na-1u);
    ulong total=0ul;
    for(uint j=first;j<=last;++j){
        total+=(ulong)a[ao+j]*(ulong)b[bo+k-j];
    }
    coefficients[co+k]=total;
}

/* One GPU work item per independent product. The carry is serial *within*
 * each product, but many products execute concurrently. No CPU carries.
 */
__kernel void batch_schoolbook_carries(__global const ulong *coefficients,
                                       __global const uint *meta,
                                       __global ushort *digits,
                                       __global uint *errors) {
    const uint item=get_global_id(0);
    const uint base=6u*item;
    const uint n=meta[base+2u]+meta[base+3u]-1u;
    const uint co=meta[base+4u],oo=meta[base+5u];
    ulong carry=0ul;
    for(uint i=0u;i<n;++i){
        const ulong value=coefficients[co+i]+carry;
        digits[oo+i]=(ushort)(value&65535ul);
        carry=value>>16;
    }
    for(uint j=0u;j<4u;++j){
        digits[oo+n+j]=(ushort)(carry&65535ul);
        carry>>=16;
    }
    errors[item]=(carry!=0ul)?1u:0u;
}

/* NeoCruncher 0.3.7: exact, bounded, block-parallel carry normalization.
 * A chunk's output carry is monotone in its input carry. Computing the
 * transfer with incoming 0 and CARRY_MAX proves independence when equal.
 * Exceptional sensitive chunks are recomputed at the boundary scan.
 * This is an exact algorithm; there is no floating point or guessed carry.
 */
#define NC037_BLOCK 1024u
/* Upper bound valid for every CRT coefficient < p*q and direct convolution
 * admitted by current multiplication code. Ceiling(max_coeff/(BASE-1))+2.
 */
#define NC037_MAX_CARRY ((ulong)60000000000000ul)
__kernel void nc037_carry_bounds(__global const ulong *coeff,
                                 __global ulong *carry_zero,
                                 __global ulong *carry_max,
                                 uint n) {
    uint block = get_global_id(0);
    uint start = block * NC037_BLOCK;
    if (start >= n) return;
    uint end = min(n, start + NC037_BLOCK);
    ulong lo = 0ul, hi = NC037_MAX_CARRY;
    for (uint i=start;i<end;++i) {
        ulong value=coeff[i];
        lo=(value+lo)>>16;
        hi=(value+hi)>>16;
    }
    carry_zero[block]=lo;
    carry_max[block]=hi;
}
/* One work item handles *only the chunk boundaries* (normally <= n/1024).
 * Never a scan of all n coefficients except the pathological sensitive-case,
 * where exactness takes precedence over performance.
 */
__kernel void nc037_carry_boundaries(__global const ulong *coeff,
                                     __global const ulong *carry_zero,
                                     __global const ulong *carry_max,
                                     __global ulong *incoming,
                                     __global ushort *digits,
                                     __global uint *overflow,
                                     uint n, uint blocks) {
    ulong carry=0ul;
    for (uint block=0u;block<blocks;++block) {
        incoming[block]=carry;
        if (carry_zero[block]==carry_max[block]) {
            carry=carry_zero[block];
        } else {
            uint start=block*NC037_BLOCK;
            uint end=min(n,start+NC037_BLOCK);
            for (uint i=start;i<end;++i)
                carry=(coeff[i]+carry)>>16;
        }
    }
    for(uint j=0u;j<4u;++j) {
        digits[n+j]=(ushort)(carry&65535ul);
        carry>>=16;
    }
    overflow[0]=carry!=0ul ? 1u : 0u;
}
__kernel void nc037_carry_digits(__global const ulong *coeff,
                                 __global const ulong *incoming,
                                 __global ushort *digits, uint n) {
    uint block=get_global_id(0);
    uint start=block*NC037_BLOCK;
    if (start>=n) return;
    uint end=min(n,start+NC037_BLOCK);
    ulong carry=incoming[block];
    for (uint i=start;i<end;++i) {
        ulong value=coeff[i]+carry;
        digits[i]=(ushort)(value&65535ul);
        carry=value>>16;
    }
}
