# SPDX-License-Identifier: GPL-3.0-only
"""Exact GPU integers. Host handles scheduling/metadata/storage, never limb math.

This is a new execution path, not a wrapper around Python int multiplication.
Large division uses an integer Newton reciprocal with exact GPU correction.
GPU hardware qualification is separate from software arithmetic validation.
"""
from __future__ import annotations
from contextlib import contextmanager
from importlib.resources import files
import math
import time
import os
import weakref
import numpy as np


class DeviceInteger:
    def __init__(self, runtime, buffer, n, bits, sign=1):
        self.runtime, self.data, self.n, self.bits = runtime, buffer, n, bits
        self.sign = sign if n else 0
        self.host = None
        self.locked = 0
        runtime.values[id(self)] = self

    def __bool__(self): return bool(self.n)
    def __int__(self): raise TypeError('GPU integers cannot be converted to host integers')
    def __add__(self, other): return self.runtime.add(self, other)
    __radd__ = __add__
    def __sub__(self, other): return self.runtime.add(self, -self.runtime.coerce(other))
    def __rsub__(self, other): return self.runtime.coerce(other)-self
    def __neg__(self):
        # Share immutable storage by keeping the original owner alive.
        value = DeviceInteger(self.runtime, None, self.n, self.bits, -self.sign)
        value.owner = self
        return value
    def __mul__(self, other): return self.runtime.multiply(self, other)
    __rmul__ = __mul__
    def __floordiv__(self, other): return self.runtime.divmod(self, other)[0]
    def __mod__(self, other): return self.runtime.divmod(self, other)[1]
    def __lshift__(self, bits): return self.runtime.shift(self, bits)
    def __rshift__(self, bits): return self.runtime.shift(self, -bits)
    def __pow__(self, exponent): return self.runtime.power(self, exponent)
    def __eq__(self, other): return self.runtime.compare(self, other) == 0
    def __lt__(self, other): return self.runtime.compare(self, other) < 0
    def __le__(self, other): return self.runtime.compare(self, other) <= 0
    def __gt__(self, other): return self.runtime.compare(self, other) > 0
    def __ge__(self, other): return self.runtime.compare(self, other) >= 0


class DeviceArithmetic:
    """Storage may spill; every numeric operation is an OpenCL kernel.

    The injected driver supplies NTT scheduling, so Neo native and Kolmogorov
    retain distinct transform implementations with one resident integer API.
    """
    def __init__(self, device=0, *, vram_mib=0, ram_mib=0, driver=None):
        from ...doctor import probe
        probe(device)
        if driver is None:
            from .drivers import KolmogorovDriver
            driver = KolmogorovDriver(device)
        self.driver = driver
        self.cl, self.ctx, self.queue = driver.cl, driver.ctx, driver.queue
        self.device = driver.device
        self.limit = int(vram_mib*2**20) if vram_mib else int(self.device.global_mem_size*.65)
        if self.limit < 2**20 or self.limit > int(self.device.global_mem_size):
            raise MemoryError('Invalid available device memory limit')
        # Tile workspace is bounded independently of the requested decimal size.
        # Both primes support these powers of two (ceiling 2**22 in this patch).
        ceiling=min(1<<22,int(self.device.max_mem_alloc_size)//8,self.limit//128)
        automatic=1<<max(0,ceiling.bit_length()-1)
        selected=int(os.environ.get('KOLMOGOROV_NTT_POINTS',automatic))
        if selected<1024 or selected>automatic or selected&(selected-1):
            raise ValueError(f'KOLMOGOROV_NTT_POINTS must be a power of two in 1024..{automatic}')
        self.driver.max_points=selected
        self.sqrt_policy=os.environ.get('KOLMOGOROV_SQRT_POLICY','progressive')
        if self.sqrt_policy not in ('classic','progressive'):raise ValueError('KOLMOGOROV_SQRT_POLICY must be classic or progressive')
        self.host_limit = int(ram_mib*2**20) if ram_mib else 256*2**20
        self.values = weakref.WeakValueDictionary()
        self.reserved = 0
        self.metrics = dict(numeric_host_operations=0, gpu_kernel_launches=0,
                            metadata_bytes_downloaded=0, storage_bytes_uploaded=0,
                            storage_bytes_downloaded=0, output_bytes_downloaded=0,
                            spill_count=0, peak_resident_value_bytes=0,
                            newton_divisions=0, reciprocal_levels=0, gpu_multiplications=0,
                            chunk_launches=0, chunk_intervals=0, ntt_tile_points=selected,
                            decimal_batch_launches=0,sqrt_policy=self.sqrt_policy)
        self.metrics.update(buffer_allocations=0,scratch_reuses=0,scratch_cached_bytes=0,
                            kernel_device_seconds=0.0,profiled_kernel_events=0,unprofiled_kernel_events=0,
                            sqrt_precision_levels=0)
        from .execution import ScratchPool,EventProfile
        self.scratch=ScratchPool(self._raw,min(self.limit//16,64*2**20),self.metrics)
        self.profile=EventProfile(self.metrics)
        base = files(__package__).joinpath('base.cl').read_text()
        extra = files(__package__).joinpath('resident.cl').read_text()
        build_started=time.perf_counter()
        try:self.program = self.cl.Program(self.ctx, base+'\n'+extra).build()
        except Exception as exc:raise RuntimeError(f'Resident OpenCL kernel build failed: {exc}') from exc
        self.metrics['resident_build_seconds']=time.perf_counter()-build_started
        names = ['r_compare_parts','r_reduce_max','r_compare_finish','r_meta_parts','r_meta_finish','r_residue_parts','r_product_check_parts',
                 'r_constant','r_meta','r_compare','r_add_coeff','r_sub_bounds',
                 'r_sub_scan','r_sub_digits','r_shift','r_pack_ntt','r_div_short',
                 'r_decimal_leaf','r_decimal_batch','r_exp_chunks','r_chud_chunks','r_product_check',
                 'r_ntt_setup','r_ntt_roots','r_ntt_normalize',
                 'schoolbook_coefficients','crt_coefficients',
                 'nc037_carry_bounds','nc037_carry_boundaries','nc037_carry_digits']
        self.kernels = {name:self.cl.Kernel(self.program, name) for name in names}
        self.constants = {}

    def _raw(self, size):
        size = max(2, int(size))
        if size > int(self.device.max_mem_alloc_size):
            raise MemoryError('Device allocation exceeds the OpenCL allocation limit')
        self.metrics['buffer_allocations']+=1
        return self.cl.Buffer(self.ctx, self.cl.mem_flags.READ_WRITE, size)

    def _root(self, value):
        while hasattr(value, 'owner'): value = value.owner
        return value

    def _ensure(self, extra):
        # Idle scratch is expendable before spilling any live numerical value.
        live = list(self.values.values())
        used = sum(v.data.size for v in live if v.data is not None)+getattr(self.driver,'cached_bytes',0)
        if used+self.reserved+extra+self.scratch.bytes>self.limit:self.scratch.trim()
        for value in live:
            if used+self.reserved+extra <= self.limit: break
            if value.data is None or value.locked: continue
            host_used = sum(v.host.nbytes for v in live if v.host is not None)
            if host_used+value.data.size > self.host_limit:
                raise MemoryError('GPU storage spilling would exceed the selected RAM limit')
            host = np.empty(value.data.size//2, dtype=np.uint16)
            self.cl.enqueue_copy(self.queue, host, value.data).wait()
            used -= value.data.size
            self.metrics['storage_bytes_downloaded'] += host.nbytes
            self.metrics['spill_count'] += 1
            value.host, value.data = host, None
        if used+self.reserved+extra > self.limit:
            raise MemoryError('Working operands and GPU workspace exceed available device memory')
        self.metrics['peak_resident_value_bytes'] = max(self.metrics['peak_resident_value_bytes'], used+extra)

    def buffer(self, value):
        value = self._root(value)
        if value.data is None:
            self._ensure(value.host.nbytes)
            value.data = self._raw(value.host.nbytes)
            self.cl.enqueue_copy(self.queue, value.data, value.host).wait()
            self.metrics['storage_bytes_uploaded'] += value.host.nbytes
            value.host = None
        return value.data

    @contextmanager
    def operation(self, values, workspace):
        roots = {id(self._root(v)):self._root(v) for v in values}
        for value in roots.values(): value.locked += 1
        try:
            self.reserved += workspace
            self._ensure(0)
            for value in roots.values(): self.buffer(value)
            yield
        finally:
            self.reserved -= workspace
            for value in roots.values(): value.locked -= 1

    def run(self, name, count, *args):
        return self.launch(self.kernels[name],count,*args)

    def launch(self,kernel,count,*args):
        self.metrics['gpu_kernel_launches'] += 1
        return self.profile.add(kernel(self.queue,(int(count),),None,*args))

    def _u(self, n): return np.uint32(n)

    def _metadata(self, data, capacity):
        blocks=(capacity+1023)//1024
        with self.scratch.lease(8,blocks*4,blocks*4) as (out,parts,tmp):
            if capacity<=4096:self.run('r_meta',1,data,self._u(capacity),out)
            else:
                self.run('r_meta_parts',blocks,data,self._u(capacity),parts)
                remaining=blocks
                while remaining>1:
                    self.run('r_reduce_max',(remaining+1)//2,parts,self._u(remaining),tmp)
                    parts,tmp=tmp,parts;remaining=(remaining+1)//2
                self.run('r_meta_finish',1,data,parts,self._u(1),out)
            host=np.empty(2,dtype=np.uint32)
            self.cl.enqueue_copy(self.queue,host,out).wait()
            self.metrics['metadata_bytes_downloaded']+=8
            n=int(host[0])
            return n,(n-1)*16+int(host[1]) if n else 0

    def value(self, data, capacity, sign=1):
        n, bits = self._metadata(data, capacity)
        return DeviceInteger(self, data, n, bits, sign)

    def coerce(self, value):
        if isinstance(value, DeviceInteger):
            if value.runtime is not self: raise ValueError('Integers belong to different OpenCL contexts')
            return value
        if type(value) is not int or abs(value) >= 2**64:
            raise TypeError('Only unsigned-64-bit scalar parameters can enter a GPU calculation')
        if value not in self.constants:
            self._ensure(8)
            out = self._raw(8)
            self.run('r_constant', 1, out, np.uint64(abs(value)), self._u(4))
            self.constants[value] = self.value(out, 4, -1 if value < 0 else 1)
        return self.constants[value]

    def compare(self, a, b):
        a,b = self.coerce(a),self.coerce(b)
        if a.sign != b.sign: return (a.sign>b.sign)-(a.sign<b.sign)
        if not a: return 0
        if a.n!=b.n:return ((a.n>b.n)-(a.n<b.n))*a.sign
        blocks=(a.n+1023)//1024
        with self.operation((a,b),blocks*8+16):
            with self.scratch.lease(4,blocks*4,blocks*4) as (out,parts,tmp):
                if a.n<=4096:self.run('r_compare',1,self.buffer(a),self._u(a.n),self.buffer(b),self._u(b.n),out)
                else:
                    self.run('r_compare_parts',blocks,self.buffer(a),self.buffer(b),self._u(a.n),parts)
                    remaining=blocks
                    while remaining>1:
                        self.run('r_reduce_max',(remaining+1)//2,parts,self._u(remaining),tmp)
                        parts,tmp=tmp,parts;remaining=(remaining+1)//2
                    self.run('r_compare_finish',1,self.buffer(a),self.buffer(b),parts,out)
                host=np.empty(1,dtype=np.int32)
                self.cl.enqueue_copy(self.queue,host,out).wait()
                self.metrics['metadata_bytes_downloaded']+=4
                return int(host[0])*a.sign

    def _carry(self, coeff, n, sign=1):
        blocks=(n+1023)//1024
        out=self._raw((n+4)*2)
        lo,hi,inc=(self._raw(blocks*8) for _ in range(3))
        error=self._raw(4)
        self.run('nc037_carry_bounds',blocks,coeff,lo,hi,self._u(n))
        self.run('nc037_carry_boundaries',1,coeff,lo,hi,inc,out,error,self._u(n),self._u(blocks))
        self.run('nc037_carry_digits',blocks,coeff,inc,out,self._u(n))
        status=np.empty(1,dtype=np.uint32)
        self.cl.enqueue_copy(self.queue,status,error).wait()
        self.metrics['metadata_bytes_downloaded'] += 4
        if status[0]: raise ArithmeticError('GPU carry overflow')
        return self.value(out,n+4,sign)

    def add(self, a, b):
        a,b=self.coerce(a),self.coerce(b)
        if not a:return b
        if not b:return a
        if a.sign==b.sign:
            n=max(a.n,b.n)
            with self.operation((a,b),n*16+4096):
                c=self._raw(n*8)
                self.run('r_add_coeff',n,self.buffer(a),self._u(a.n),self.buffer(b),self._u(b.n),c)
                return self._carry(c,n,a.sign)
        if self.compare(a if a.sign>0 else -a,b if b.sign>0 else -b)<0:a,b=b,a
        with self.operation((a,b),a.n*8+4096):
            blocks=(a.n+1023)//1024
            lo,hi,inc=(self._raw(blocks*8) for _ in range(3))
            out=self._raw(a.n*2)
            self.run('r_sub_bounds',blocks,self.buffer(a),self._u(a.n),self.buffer(b),self._u(b.n),lo,hi)
            self.run('r_sub_scan',1,lo,hi,inc,self._u(blocks))
            self.run('r_sub_digits',blocks,self.buffer(a),self._u(a.n),self.buffer(b),self._u(b.n),inc,out)
            return self.value(out,a.n,a.sign)

    def shift(self, a, amount):
        a=self.coerce(a)
        if type(amount) is not int:raise TypeError('Shift count must be an integer')
        if not a or not amount:return a
        if amount<0 and -amount>=a.bits:return self.coerce(0)
        words,bits=divmod(abs(amount),16)
        n=a.n+words+1 if amount>0 else a.n-words
        with self.operation((a,),n*2+16):
            out=self._raw(n*2)
            self.run('r_shift',n,self.buffer(a),self._u(a.n),out,self._u(n),self._u(words),self._u(bits),self._u(amount<0))
            return self.value(out,n,a.sign)

    def slice(self, a, start, stop):
        a=self.coerce(a)
        n=max(0,min(stop,a.n)-start)
        if not n:return self.coerce(0)
        with self.operation((a,),n*2+16):
            out=self._raw(n*2)
            self.cl.enqueue_copy(self.queue,out,self.buffer(a),src_offset=start*2,byte_count=n*2)
            return self.value(out,n)

    def multiply(self, a, b):
        a,b=self.coerce(a),self.coerce(b)
        if not a or not b:return self.coerce(0)
        sign=a.sign*b.sign
        if a.sign<0:a=-a
        if b.sign<0:b=-b
        n=1<<max(0,(a.n+b.n-2).bit_length())
        if n>self.driver.max_points:
            # Balanced Karatsuba with GPU adds/shifts; unbalanced tiled product.
            split=max(a.n,b.n)//2
            if min(a.n,b.n)*2>=max(a.n,b.n):
                a0,a1=self.slice(a,0,split),self.slice(a,split,a.n)
                b0,b1=self.slice(b,0,split),self.slice(b,split,b.n)
                z0,z2=a0*b0,a1*b1
                cross=(a0+a1)*(b0+b1)-z0-z2
                out=z0+(cross<<(16*split))+(z2<<(32*split))
            else:
                if a.n<b.n:a,b=b,a
                width=max(1,self.driver.max_points//2-1)
                out=self.coerce(0)
                for start in range(0,a.n,width):
                    out=out+((self.slice(a,start,start+width)*b)<<(16*start))
            return -out if sign<0 else out
        with self.operation((a,b),n*64+16384):
            if min(a.n,b.n)*(65535**2)>=2013265921*1811939329:
                raise ArithmeticError('CRT coefficient bound exceeded')
            self.metrics['gpu_multiplications'] += 1
            if max(a.n,b.n)<=128 or min(a.n,b.n)<=4:
                length=a.n+b.n-1
                coeff=self._raw(length*8)
                self.run('schoolbook_coefficients',length,self.buffer(a),self._u(a.n),self.buffer(b),self._u(b.n),coeff)
            else:
                parts=self.driver.convolve(self,a,b,n)
                length=n
                coeff=self._raw(n*8)
                p,q=2013265921,1811939329
                self.run('crt_coefficients',n,parts[0],parts[1],coeff,self._u(p),self._u(q),self._u(1811939320))
            result=self._carry(coeff,length,sign)
            result.locked+=1
            try:
                error=self._raw(4)
                if max(a.n,b.n,result.n) <= 4096:
                    self.run('r_product_check',1,self.buffer(a),self._u(a.n),self.buffer(b),self._u(b.n),
                             self.buffer(result),self._u(result.n),error)
                else:
                    residues=[];counts=[]
                    for operand in (a,b,result):
                        blocks=(operand.n+1023)//1024
                        part=self._raw(blocks*8)
                        self.run('r_residue_parts',blocks,self.buffer(operand),self._u(operand.n),part)
                        residues.append(part);counts.append(blocks)
                    self.run('r_product_check_parts',1,residues[0],self._u(counts[0]),
                             residues[1],self._u(counts[1]),residues[2],self._u(counts[2]),error)
                status=np.empty(1,dtype=np.uint32)
                self.cl.enqueue_copy(self.queue,status,error).wait()
                self.metrics['metadata_bytes_downloaded']+=4
                if status[0]:raise ArithmeticError('GPU product failed two device-side modular checks')
            finally:result.locked-=1
            return result

    def power(self, base, exponent):
        if type(exponent) is not int or exponent<0:raise ValueError('Nonnegative integer exponent required')
        result=self.coerce(1);base=self.coerce(base)
        while exponent:
            if exponent&1:result=result*base
            exponent>>=1
            if exponent:base=base*base
        return result

    def divmod(self, a, b):
        a,b=self.coerce(a),self.coerce(b)
        if b.sign<=0 or a.sign<0:raise ValueError('Resident division requires nonnegative numerator and positive divisor')
        if self.compare(a,b)<0:return self.coerce(0),a
        if a.bits<=256:
            cap=a.n+1
            with self.operation((a,b),cap*4+16):
                q,r=self._raw(cap*2),self._raw(cap*2)
                self.run('r_div_short',1,self.buffer(a),self._u(a.n),self.buffer(b),self._u(b.n),q,r,self._u(cap))
                return self.value(q,cap),self.value(r,cap)
        self.metrics['newton_divisions'] += 1
        # Underestimated reciprocal, integer Newton. Guard scale bounds the
        # subsequent quotient error to < 1/4 after exact reciprocal correction.
        k=a.bits+2
        x=self._reciprocal(b,k)
        return self._divide_with_reciprocal(a,b,k,x)

    def _divide_with_reciprocal(self,a,b,k,x):
        if a.bits+2>k:raise ArithmeticError('Cached reciprocal scale is too small')
        q=(a*x)>>k
        r=a-b*q
        for _ in range(4):
            if r>=b:q=q+1;r=r-b
            else:break
        else:raise ArithmeticError('GPU quotient did not converge within correction bound')
        if r.sign<0 or r>=b:raise ArithmeticError('Invalid GPU quotient remainder')
        return q,r

    def _reciprocal(self, b, k):
        """floor(2**k/b), growing precision using an upward-rounded high divisor.

        Every level checks b*x <= 2**k < b*(x+1). No floating point estimate.
        """
        self.metrics['reciprocal_levels'] += 1
        m=b.bits
        if k<m: return self.coerce(0)
        scale=self.coerce(1)<<k
        qbits=k-m+1
        if qbits<=32:
            x=self.coerce(1)<<(k-m)
            steps=qbits.bit_length()+2
        else:
            r=qbits//2
            s=max(0,m-(qbits-r+8))
            high=(b>>s)+1 if s else b
            x=self._reciprocal(high,k-s-r)<<r
            steps=2
        for _ in range(steps):
            nxt=(x*((scale<<1)-b*x))>>k
            if nxt==x: break
            x=nxt
        for _ in range(4):
            if b*(x+1)<=scale: x=x+1
            else: break
        else: raise ArithmeticError('GPU reciprocal correction bound exceeded')
        if b*x>scale or b*(x+1)<=scale:
            raise ArithmeticError('Invalid GPU reciprocal interval')
        return x

    def isqrt(self, a):
        a=self.coerce(a)
        if a.sign<0:raise ValueError('Square root of negative integer')
        if not a:return a
        self.metrics['sqrt_precision_levels']+=1
        if a.bits>256 and self.sqrt_policy=='progressive':
            shift=2*(a.bits//4)
            x=(self.isqrt(a>>shift)+1)<<(shift//2)
        else:x=self.coerce(1)<<((a.bits+1)//2)
        for _ in range(a.bits.bit_length()+8):
            y=(x+a//x)>>1
            if y>=x:
                if x*x>a or (x+1)*(x+1)<=a:raise ArithmeticError('GPU square-root interval check failed')
                return x
            x=y
        raise ArithmeticError('GPU square root did not converge')

    def chunks(self, family, start, stop, progress=None):
        if family not in ('exp','chud'):raise ValueError('Unsupported resident series')
        if not 0<=start<stop<2**32:raise ValueError('GPU term indices exceed uint32 capacity')
        chunk=512 if family=='exp' else 128
        frontier=[]
        total=(stop-start+chunk-1)//chunk
        # Bound initial scratch to eight intervals; binary frontier is logarithmic.
        batch=max(8,min(128,int(self.device.max_compute_units)*2))
        for first in range(0,total,batch):
            count=min(batch,total-first)
            arrays=2 if family=='exp' else 3
            stride=3 if family=='exp' else 5
            with self.operation((),count*8192*arrays+count*stride*4+16384):
                buffers=[self._raw(count*4096) for _ in range(arrays)]
                meta=self._raw(count*stride*4)
                lo=start+first*chunk;hi=min(stop,lo+count*chunk)
                self.run('r_exp_chunks' if family=='exp' else 'r_chud_chunks',count,
                         *buffers,meta,self._u(lo),self._u(hi),self._u(chunk))
                host=np.empty(count*stride,dtype=np.uint32)
                self.cl.enqueue_copy(self.queue,host,meta).wait()
                self.metrics['metadata_bytes_downloaded'] += host.nbytes
                if any(host[i*stride+stride-1] for i in range(count)):
                    raise ArithmeticError('GPU series chunk exceeded checked limb capacity')
                self.metrics['chunk_launches']+=1
                self.metrics['chunk_intervals']+=count
                values=[]
                for i in range(count):
                    node=[]
                    for j,buf in enumerate(buffers):
                        n=int(host[i*stride+j]);out=self._raw(max(1,n)*2)
                        if n:self.cl.enqueue_copy(self.queue,out,buf,src_offset=i*4096,byte_count=n*2)
                        else:self.run('r_constant',1,out,np.uint64(0),self._u(1))
                        sign=-1 if family=='chud' and j==2 and host[i*stride+3] else 1
                        node.append(self.value(out,max(1,n),sign))
                    values.append(tuple(node))
            for node in values:
                height=0
                while frontier and frontier[-1][0]==height:
                    node=self.merge(family,frontier.pop()[1],node);height+=1
                frontier.append((height,node))
            if progress:progress(dict(stage='GPU-resident binary splitting',percent=None,
                    phase_percent=100*min(total,first+count)/total,work_unit='intervals',
                    work_done=min(total,first+count),work_total=total,certified_decimal_digits=0))
        node=frontier.pop()[1]
        while frontier:node=self.merge(family,frontier.pop()[1],node)
        return node

    def merge(self, family, left, right):
        if family=='exp':
            p,t=left;q,u=right
            return p*q,t*q+u
        p,q,t=left;r,s,u=right
        return p*r,q*s,t*s+p*u

    def decimal(self, value, count):
        value=self.coerce(value)
        if value.sign<0:raise ValueError('Decimal output requires nonnegative integer')
        if not 0<count<2**32:raise ValueError('Output exceeds GPU uint32 indexing')
        powers={};reciprocals={}
        self.metrics.setdefault('decimal_cached_reciprocal_hits',0)
        self.metrics.setdefault('decimal_cached_reciprocal_misses',0)
        self.metrics.setdefault('decimal_exact_splits',0)
        completed=0
        begin=__import__('time').perf_counter()
        # Output stays on device until every leaf has completed.
        with self.operation((value,),count+8192):
            output=self._raw(count)
            pending=[]
            def flush():
                nonlocal completed
                if not pending:return
                limbs=sum(max(1,v.n) for v,_,_ in pending)
                with self.operation(tuple(v for v,_,_ in pending),limbs*4+len(pending)*20+16):
                    inputs=self._raw(limbs*2);scratch=self._raw(limbs*2)
                    meta=np.empty((len(pending),4),dtype=np.uint32)
                    pos=0
                    for i,(v,offset,length) in enumerate(pending):
                        meta[i]=(pos,v.n,offset,length)
                        if v.n:self.cl.enqueue_copy(self.queue,inputs,self.buffer(v),dst_offset=pos*2,byte_count=v.n*2)
                        pos+=max(1,v.n)
                    descriptors=self._raw(meta.nbytes);error=self._raw(len(pending)*4)
                    self.cl.enqueue_copy(self.queue,descriptors,meta)
                    self.run('r_decimal_batch',len(pending),inputs,descriptors,scratch,output,error)
                    flags=np.empty(len(pending),dtype=np.uint32)
                    self.cl.enqueue_copy(self.queue,flags,error).wait()
                    self.metrics['metadata_bytes_downloaded']+=flags.nbytes
                    self.metrics['decimal_batch_launches']+=1
                    if flags.any():raise ArithmeticError('Decimal width overflow')
                completed+=sum(length for _,_,length in pending)
                if getattr(self,'progress',None):self.progress(dict(stage='GPU decimal conversion',percent=None,
                    phase_percent=100*completed/count,work_done=completed,work_total=count,
                    work_unit='ASCII digits produced',phase_elapsed_seconds=__import__('time').perf_counter()-begin,
                    metrics=dict(self.metrics),certified_decimal_digits=0))
                pending.clear()
            def emit(v,offset,length):
                if length<=512:
                    pending.append((v,offset,length))
                    if len(pending)>=512:flush()
                    return
                low=length//2
                if low not in powers:powers[low]=self.power(10,low)
                divisor=powers[low]
                # All same-width nodes share one exact reciprocal. 332193/100000
                # strictly exceeds log2(10); k covers every value fitting length.
                key=(length,low)
                if v.bits<=256:q,r=self.divmod(v,divisor)
                else:
                    k=(length*332193+99999)//100000+4
                    if key not in reciprocals:
                        reciprocals[key]=self._reciprocal(divisor,k)
                        self.metrics['decimal_cached_reciprocal_misses']+=1
                    else:self.metrics['decimal_cached_reciprocal_hits']+=1
                    q,r=self._divide_with_reciprocal(v,divisor,k,reciprocals[key])
                self.metrics['decimal_exact_splits']+=1
                emit(q,offset,length-low);emit(r,offset+length-low,low)
            emit(value,0,count)
            flush()
            host=np.empty(count,dtype=np.uint8)
            self.cl.enqueue_copy(self.queue,host,output).wait()
            self.metrics['output_bytes_downloaded']+=count
            return host.tobytes().decode('ascii')
