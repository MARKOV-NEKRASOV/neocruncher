# SPDX-License-Identifier: GPL-3.0-only
"""Kolmogorov exact computing CLI; run python -m kolmogorov.compute --help."""
import argparse
import json
import random
import time
from dataclasses import asdict
from . import Engine, ComputeError, BatchPlanner, Operation, estimate_ntt_memory


def _main():
    parser = argparse.ArgumentParser(description="Kolmogorov portable exact arithmetic")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("devices", help="List available backends and devices")
    const=sub.add_parser('constant',help='Compute a constant with GPU-pure resident arithmetic')
    const.add_argument('--algorithm',choices=('pi_chudnovsky','e_taylor','sqrt2_integer','phi_integer'),default='pi_chudnovsky')
    const.add_argument('--digits',type=int,default=100)
    const.add_argument('--device',type=int,default=0)
    const.add_argument('--vram-mib',type=float,default=0)
    const.add_argument('--ram-mib',type=float,default=0)
    const.add_argument('--output',help='Optional exclusive ASCII TXT output')
    mul = sub.add_parser("multiply", help="Multiply two exact decimal integers")
    mul.add_argument("a")
    mul.add_argument("b")
    mul.add_argument("--backend", choices=("auto", "cpu", "pykolm", "opencl", "ntt-ref"), default="auto")
    mul.add_argument("--no-verify", action="store_true")
    mul.add_argument("--strict", action="store_true", help="Full CPU product cross-check")
    bench = sub.add_parser("bench", help="Compare exact-arithmetic backends")
    bench.add_argument("--digits", type=int, default=4096)
    bench.add_argument("--backend", choices=("auto", "cpu", "pykolm", "opencl", "ntt-ref"), default="auto")
    batch = sub.add_parser('batch',help='Execute dependent exact multiplications from a JSON DAG')
    batch.add_argument('file',help='JSON file with operations array')
    batch.add_argument('--backend',default='auto')
    budget = sub.add_parser('memory',help='Estimate minimum NTT GPU resources')
    budget.add_argument('--digits-a',type=int,required=True)
    budget.add_argument('--digits-b',type=int,required=True)
    args = parser.parse_args()
    try:
        if args.command=='constant':
            from .resident import DeviceArithmetic
            from .resident.constants import calculate
            import shutil
            from pathlib import Path
            if args.output:
                path=Path(args.output)
                if path.exists():raise ValueError('Output already exists')
                if args.digits+65539>shutil.disk_usage(path.absolute().parent).free:
                    raise OSError('Insufficient disk space')
            start=time.perf_counter()
            rt=DeviceArithmetic(args.device,vram_mib=args.vram_mib,ram_mib=args.ram_mib)
            text,detail=calculate(rt,args.algorithm,args.digits)
            if args.output:
                if len(text)+1>shutil.disk_usage(path.absolute().parent).free:raise OSError('Insufficient disk space')
                with path.open('x',encoding='ascii') as stream:stream.write(text+'\n')
            print(json.dumps(dict(version='1.0.0a1',algorithm=args.algorithm,digits=args.digits,
                prefix=text[:82],seconds=time.perf_counter()-start,details=detail),indent=2))
        elif args.command == "devices":
            for device in Engine().devices():
                print(f"{device.backend:9s} {'AVAILABLE' if device.available else 'UNAVAILABLE':11s} {device.name} {device.detail}")
        elif args.command == 'memory':
            print(json.dumps(estimate_ntt_memory(args.digits_a,args.digits_b),indent=2))
        elif args.command == 'batch':
            with open(args.file,encoding='utf8') as f:
                source=json.load(f)
            ops=[Operation(**op) for op in source['operations']]
            result=BatchPlanner(Engine(args.backend)).execute(ops)
            print(json.dumps(result.to_dict(),indent=2))
        elif args.command == "multiply":
            if args.no_verify and args.strict:
                raise ComputeError("--strict es incompatible con --no-verify")
            result = Engine(args.backend).multiply(args.a, args.b, verify=not args.no_verify, strict=args.strict)
            print(json.dumps(asdict(result), indent=2))
        elif args.command == "bench":
            if not 1 <= args.digits <= 10_000_000:
                raise ComputeError("--digits debe estar entre 1 y 10 millones.")
            rng = random.Random(20261016)
            a = "".join(str(rng.randrange(1, 10) if i == 0 else rng.randrange(10)) for i in range(args.digits))
            b = "".join(str(rng.randrange(1, 10) if i == 0 else rng.randrange(10)) for i in range(args.digits))
            # Timings include conversion and GPU transfers, not data generation.
            result = Engine(args.backend).multiply(a, b)
            print(json.dumps({"input_digits_each": args.digits, "output_digits": result.digits,
                              "backend": result.backend, "seconds": round(result.elapsed_seconds, 6),
                              "verified": result.verified}, indent=2))
    except (ComputeError,OSError,RuntimeError,ValueError,ArithmeticError,ImportError) as exc:
        parser.exit(2, f"Error: {exc}\n")


def main():
    import os,sys
    argv=sys.argv[1:]
    if not os.environ.get('KOLMOGOROV_CONSOLE_WORKER') and argv and argv[0] in ('constant','multiply','bench','batch') and not any(x in argv for x in ('--help','-h')):
        from .console import supervise
        return supervise(argv)
    return _main()

if __name__ == "__main__":
    raise SystemExit(main())
