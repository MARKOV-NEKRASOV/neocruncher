# SPDX-License-Identifier: GPL-3.0-only
"""Versioned, vendor-neutral arithmetic contract: only *exact* operations.

This does not claim million/billion-digit feasibility: estimates are minimums,
not allocations, and do not include OS/driver/cache fragmentation overhead.
"""
from dataclasses import dataclass
from .core import Engine, ComputeError, required_ntt_length, BASE

API_VERSION = '1.0.0a1'

@dataclass(frozen=True)
class Capabilities:
    api: str
    operations: tuple[str, ...]
    backends: tuple[str, ...]
    exact: bool

class ArithmeticAPI:
    def __init__(self, backend='auto'):
        self.engine=Engine(backend=backend)

    def capabilities(self):
        return Capabilities(API_VERSION,('multiply',),tuple(self.engine.backends),True)

    def multiply_decimal(self, a, b, *, verify=True, strict=False):
        return self.engine.multiply(a,b,verify=verify,strict=strict)

    def list_devices(self):
        return self.engine.devices()

def estimate_ntt_memory(digits_a: int, digits_b: int):
    if type(digits_a) is not int or type(digits_b) is not int or digits_a<1 or digits_b<1:
        raise ComputeError('Cantidad de dígitos inválida.')
    na=(digits_a+3)//4; nb=(digits_b+3)//4
    n=required_ntt_length(na,nb)
    # Lower-bound for two input spectra plus scratch and twiddle tables.
    minimum=4*n*4
    # Conservative prototype reservation: peak cache+staging, not a guarantee.
    anticipated=24*n
    return {'digits_a':digits_a,'digits_b':digits_b, 'base':BASE,
            'ntt_length':n,'min_device_bytes':minimum,
            'prototype_budget_bytes':anticipated,
            'min_device_mib':round(minimum/(1024**2),3),
            'prototype_limit_mib':round(anticipated/(1024**2),3),
            'min_device_gib':round(minimum/(1024**3),3),
            'prototype_budget_gib':round(anticipated/(1024**3),3),
            'note':'Estimación de buffers NTT solamente; no incluye bigints, CRT, RAM, checkpoints ni drivers.'}
