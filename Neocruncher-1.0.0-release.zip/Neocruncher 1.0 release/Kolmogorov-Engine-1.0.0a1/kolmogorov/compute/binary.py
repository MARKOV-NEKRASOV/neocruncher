# SPDX-License-Identifier: GPL-3.0-only
"""Binary transport v1: signed Python int <-> little-endian uint16 limbs.

CRT/carry is host work. A separately built C helper is optional; it does not
multiply operands. No decimal serialization occurs on this transport.
"""
from __future__ import annotations
import ctypes
from pathlib import Path
import sys
import numpy as np
from .core import ComputeError,P1,P2,INV_P1_P2

def limbs(value):
    value=abs(value)
    count=max(1,(value.bit_length()+15)//16)
    return np.frombuffer(value.to_bytes(count*2,'little'),dtype='<u2')

_LIBRARY=None
_TRIED=False

def native_helper():
    global _LIBRARY,_TRIED
    if not _TRIED:
        _TRIED=True
        filename='crtcarry.dll' if sys.platform=='win32' else 'crtcarry.dylib' if sys.platform=='darwin' else 'crtcarry.so'
        path=Path(__file__).parent/'native'/filename
        if path.is_file():
            try:
                lib=ctypes.CDLL(str(path))
                fn=lib.kolm_crtcarry
                fn.argtypes=[ctypes.POINTER(ctypes.c_uint32),ctypes.POINTER(ctypes.c_uint32),ctypes.c_size_t,
                             ctypes.POINTER(ctypes.c_uint16),ctypes.c_size_t,ctypes.c_uint32]
                fn.restype=ctypes.c_int
                _LIBRARY=lib
            except (OSError,AttributeError) as exc:
                raise ComputeError('Invalid optional CRT/carry helper; rebuild it for this platform') from exc
    return _LIBRARY

def reconstruct(c1,c2):
    left=np.asarray(c1,dtype=np.uint32)
    right=np.asarray(c2,dtype=np.uint32)
    if left.ndim != 1 or right.ndim != 1:
        raise ComputeError('Residues must be one-dimensional vectors')
    left=np.ascontiguousarray(left)
    right=np.ascontiguousarray(right)
    if len(left)!=len(right) or not len(left):raise ComputeError('Invalid residue vector lengths')
    n=len(left)
    out=np.zeros(n+4,dtype=np.uint16)
    helper=native_helper()
    if helper is not None:
        rc=helper.kolm_crtcarry(left.ctypes.data_as(ctypes.POINTER(ctypes.c_uint32)),
                               right.ctypes.data_as(ctypes.POINTER(ctypes.c_uint32)),n,
                               out.ctypes.data_as(ctypes.POINTER(ctypes.c_uint16)),len(out),INV_P1_P2)
        if rc:raise ComputeError(f'CRT/carry helper rejected residues (code {rc})')
    else:
        carry=0
        for i,(a,b) in enumerate(zip(left,right)):
            a,b=int(a),int(b)
            if not 0<=a<P1 or not 0<=b<P2:raise ComputeError('Residue outside prime range')
            total=a+P1*(((b-a)*INV_P1_P2)%P2)+carry
            out[i]=total&65535;carry=total>>16
        for i in range(n,n+4):out[i]=carry&65535;carry>>=16
        if carry:raise ComputeError('CRT/carry overflow')
    # np.uint16 is native-endian. Serialize explicitly little-endian.
    return int.from_bytes(out.astype('<u2',copy=False).tobytes(),'little')
