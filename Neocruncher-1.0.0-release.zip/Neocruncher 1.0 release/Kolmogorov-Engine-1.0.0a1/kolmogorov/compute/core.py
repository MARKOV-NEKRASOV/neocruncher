# SPDX-License-Identifier: GPL-3.0-only
"""Portable exact-integer computational core.

No dependency on CUDA, HIP, OpenCL, or external numerical libraries.
The optional native plugins implement the same convolution ABI.
"""
from __future__ import annotations

import ctypes
import os
import re
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Protocol, Callable

BASE = 10_000
DIGITS_PER_LIMB = 4
MAX_NTT_LENGTH = 1 << 26  # number-theoretical limit; hardware memory lower
MAX_REFERENCE_NTT_LENGTH = 1 << 16
P1 = 2_013_265_921
P2 = 1_811_939_329
R1 = 31
R2 = 13
INV_P1_P2 = pow(P1, -1, P2)
DIGITS_RE = re.compile(r"[+-]?[0-9]+\Z", re.ASCII)


class ComputeError(ValueError):
    """Incorrect data, unsupported operations, or device execution error."""


@dataclass(frozen=True)
class Device:
    backend: str
    name: str
    available: bool
    detail: str = ""


@dataclass(frozen=True)
class Multiplication:
    value: str
    backend: str
    elapsed_seconds: float
    verified: bool
    verification: str
    digits: int


class Backend(Protocol):
    name: str

    def available(self) -> bool: ...
    def multiply(self, lhs: str, rhs: str) -> str: ...
    def devices(self) -> list[Device]: ...


def _decimal_to_int(magnitude: str) -> int:
    """Parse long *signed* decimal strings without changing global Python limits.

    Split the sign before divide-and-conquer. Otherwise the low half of a
    negative numeral would be added instead of subtracted when the input
    exceeds 2048 characters (the NeoCruncher OpenCL adapter uses this path).
    """
    if magnitude.startswith('-'):
        return -_decimal_to_int(magnitude[1:])
    if magnitude.startswith('+'):
        return _decimal_to_int(magnitude[1:])
    if len(magnitude) <= 2048:
        return int(magnitude)
    m = len(magnitude) // 2
    return _decimal_to_int(magnitude[:m]) * 10 ** (len(magnitude)-m) + _decimal_to_int(magnitude[m:])


def _int_to_decimal(value: int) -> str:
    """Serialize unbounded integers without sys.set_int_max_str_digits."""
    if value < 0:
        return '-' + _int_to_decimal(-value)
    if value.bit_length() <= 6000:
        return str(value)
    length_upper_bound = (value.bit_length() * 30103) // 100000 + 2
    half = length_upper_bound // 2
    high, low = divmod(value, 10**half)
    if not high:
        return _int_to_decimal(low)
    return _int_to_decimal(high) + _int_to_decimal(low).zfill(half)


def normalize_integer(value: str | int) -> str:
    if type(value) is int:
        text = _int_to_decimal(value)
    elif isinstance(value, str):
        text = value.strip()
    else:
        raise ComputeError('Se espera un entero decimal en texto o un int de Python.')
    if not DIGITS_RE.fullmatch(text):
        raise ComputeError('Se espera un entero decimal (sin separadores ni notación científica).')
    neg = text[0] == '-'
    digits = text.lstrip('+-').lstrip('0') or '0'
    return ('-' if neg and digits != '0' else '') + digits

def to_limbs(text: str) -> list[int]:
    magnitude = text.lstrip("-")
    return [int(magnitude[max(0, i-DIGITS_PER_LIMB):i]) for i in range(len(magnitude), 0, -DIGITS_PER_LIMB)]


def from_coefficients(coefficients: list[int], negative: bool) -> str:
    if not coefficients:
        raise ComputeError("Convolución vacía.")
    carry = 0
    limbs = []
    for value in coefficients:
        if value < 0:
            raise ComputeError("Coeficiente negativo inesperado.")
        carry, limb = divmod(int(value) + carry, BASE)
        limbs.append(limb)
    while carry:
        carry, limb = divmod(carry, BASE)
        limbs.append(limb)
    while len(limbs) > 1 and limbs[-1] == 0:
        limbs.pop()
    value = str(limbs[-1]) + "".join(f"{x:04d}" for x in reversed(limbs[:-1]))
    return ("-" if negative and value != "0" else "") + value


def coefficient_bound(a_len: int, b_len: int) -> int:
    return min(a_len, b_len) * (BASE-1)**2


def required_ntt_length(a_len: int, b_len: int) -> int:
    if type(a_len) is not int or type(b_len) is not int or a_len < 1 or b_len < 1:
        raise ComputeError("La NTT requiere vectores de longitud positiva.")
    n = 1 << (a_len + b_len - 2).bit_length()
    if n > MAX_NTT_LENGTH or coefficient_bound(a_len, b_len) >= P1 * P2:
        raise ComputeError("Los operandos superan los límites actuales del algoritmo NTT/CRT.")
    return n


def _mod_decimal(value: str, prime: int) -> int:
    """Modulo of huge decimal string, without allocating a huge Python integer.

    Parse short chunks with C-level int() rather than one Python loop per digit.
    Chunk size 18 stays far below Python's input-conversion digit guard and
    supports millions of digits with constant additional memory.
    """
    result = 0
    magnitude = value.lstrip("-")
    chunk_size = 18
    power = 10 ** chunk_size
    first = len(magnitude) % chunk_size or chunk_size
    result = int(magnitude[:first])
    for offset in range(first, len(magnitude), chunk_size):
        result = (result * power + int(magnitude[offset:offset + chunk_size])) % prime
    if value.startswith("-"):
        result = -result
    return result % prime


def verify_modular(lhs: str, rhs: str, result: str) -> bool:
    """Two independent modular checks: useful fault detection, not a formal proof."""
    for p in (2_305_843_009_213_693_951, 1_000_000_007):
        if (_mod_decimal(lhs, p) * _mod_decimal(rhs, p) - _mod_decimal(result, p)) % p:
            return False
    return True


class CpuBackend:
    name = "cpu"

    def available(self) -> bool:
        return True

    def devices(self) -> list[Device]:
        return [Device("cpu", "Python arbitrary-precision integer (CPU)", True)]

    def multiply(self, lhs: str, rhs: str) -> str:
        try:
            import gmpy2
        except ImportError:
            pass
        else:
            return str(gmpy2.mpz(lhs) * gmpy2.mpz(rhs))
        return _int_to_decimal(_decimal_to_int(lhs.lstrip('-')) *
                               _decimal_to_int(rhs.lstrip('-')) *
                               (-1 if lhs.startswith('-') != rhs.startswith('-') else 1))


class PyKolmBackend(CpuBackend):
    name='pykolm'
    def devices(self):return [Device('pykolm','PyKolm exact CPU (GMP if available)',True)]
    def multiply(self,lhs,rhs):
        from pykolm import multiply
        from pykolm.tree import Integer
        value=multiply(_decimal_to_int(lhs),_decimal_to_int(rhs)) if Integer is int else multiply(Integer(lhs),Integer(rhs))
        if type(value) is int:return _int_to_decimal(value)
        return str(value)


class ReferenceNTTBackend:
    """Slow pure-Python exact NTT, used to validate algorithms without a GPU."""
    name = "ntt-ref"

    def available(self) -> bool:
        return True

    def devices(self) -> list[Device]:
        return [Device(self.name, "CPU reference NTT/CRT (not optimized)", True)]

    @staticmethod
    def _ntt(values: list[int], p: int, root: int, inverse: bool) -> None:
        n = len(values)
        j = 0
        for i in range(1, n):
            bit = n >> 1
            while j & bit:
                j ^= bit
                bit >>= 1
            j ^= bit
            if i < j:
                values[i], values[j] = values[j], values[i]
        size = 2
        while size <= n:
            omega = pow(root, (p-1)//size, p)
            if inverse:
                omega = pow(omega, p-2, p)
            half = size//2
            for start in range(0, n, size):
                w = 1
                for k in range(half):
                    u = values[start+k]
                    v = values[start+k+half]*w % p
                    values[start+k] = (u+v) % p
                    values[start+k+half] = (u-v) % p
                    w = w*omega % p
            size *= 2
        if inverse:
            inv = pow(n, p-2, p)
            for i in range(n):
                values[i] = values[i]*inv % p

    def _convolve(self, a: list[int], b: list[int], p: int, root: int, n: int) -> list[int]:
        x = a + [0]*(n-len(a))
        y = b + [0]*(n-len(b))
        self._ntt(x, p, root, False)
        self._ntt(y, p, root, False)
        z = [u*v % p for u,v in zip(x,y)]
        self._ntt(z, p, root, True)
        return z[:len(a)+len(b)-1]

    def multiply(self, lhs: str, rhs: str) -> str:
        a, b = to_limbs(lhs), to_limbs(rhs)
        n = required_ntt_length(len(a), len(b))
        if n > MAX_REFERENCE_NTT_LENGTH:
            raise ComputeError("La NTT Python está limitada a 65536 posiciones; usá cpp/cpu/GPU.")
        first = self._convolve(a, b, P1, R1, n)
        second = self._convolve(a, b, P2, R2, n)
        coeffs = [x + P1 * (((y-x) % P2)*INV_P1_P2 % P2)
                  for x,y in zip(first,second)]
        return from_coefficients(coeffs, lhs.startswith("-") != rhs.startswith("-"))


class NativeConvolutionBackend:
    """Optional CPU C++, CUDA or ROCm/HIP native backend (shared library)."""
    def __init__(self, name: str):
        if name not in ("cuda", "rocm", "cpp", "neocruncher"):
            raise ComputeError(f"Backend nativo desconocido: {name}")
        self.name = name
        self._lib = None
        self._error = "No se encontró el plugin nativo"
        root = Path(__file__).resolve().parents[2]
        libname = f"libkolmogorov_{name}.so"
        candidates = [root / "native" / "build" / libname]
        if name == "neocruncher" and os.environ.get("KOLMOGOROV_NEOCRUNCHER_LIB"):
            candidates.insert(0, Path(os.environ["KOLMOGOROV_NEOCRUNCHER_LIB"]))
        custom = os.environ.get("KOLMOGOROV_BACKEND_PATH")
        if custom:
            candidates.insert(0, Path(custom) / libname)
        for path in candidates:
            if not path.is_file():
                continue
            try:
                lib = ctypes.CDLL(str(path))
                lib.km_device_count.argtypes = []
                lib.km_device_count.restype = ctypes.c_int
                lib.km_device_name.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_size_t]
                lib.km_device_name.restype = ctypes.c_int
                lib.km_convolve_u32.argtypes = [
                    ctypes.POINTER(ctypes.c_uint32), ctypes.c_size_t,
                    ctypes.POINTER(ctypes.c_uint32), ctypes.c_size_t,
                    ctypes.POINTER(ctypes.c_uint64), ctypes.c_size_t,
                ]
                lib.km_convolve_u32.restype = ctypes.c_int
                self._lib = lib
                self._error = ""
                break
            except (OSError, AttributeError) as exc:
                self._error = str(exc)

    def available(self) -> bool:
        try:
            return bool(self._lib and self._lib.km_device_count() > 0)
        except (OSError, ValueError):
            return False

    def devices(self) -> list[Device]:
        if not self._lib:
            return [Device(self.name, self.name.upper(), False, self._error)]
        count = self._lib.km_device_count()
        if count <= 0:
            return [Device(self.name, self.name.upper(), False, "No se detectaron dispositivos compatibles")]
        found = []
        for i in range(count):
            buffer = ctypes.create_string_buffer(256)
            status = self._lib.km_device_name(i, buffer, ctypes.sizeof(buffer))
            found.append(Device(self.name, buffer.value.decode("utf8", errors="replace") if status == 0 else f"GPU #{i}", True))
        return found

    def multiply(self, lhs: str, rhs: str) -> str:
        if not self.available():
            raise ComputeError(f"Backend {self.name} no disponible. {self._error}")
        if lhs == "0" or rhs == "0":
            return "0"
        a, b = to_limbs(lhs), to_limbs(rhs)
        required_ntt_length(len(a), len(b))
        aa = (ctypes.c_uint32 * len(a))(*a)
        bb = (ctypes.c_uint32 * len(b))(*b)
        cap = len(a)+len(b)-1
        out = (ctypes.c_uint64 * cap)()
        status = self._lib.km_convolve_u32(aa, len(a), bb, len(b), out, cap)
        if status:
            raise ComputeError(f"Error del plugin nativo ({self.name}, código {status}). No se sustituyó silenciosamente por CPU.")
        # Do not trust potentially buggy plugin outputs, even with verify=False.
        limit=coefficient_bound(len(a),len(b))
        if any(x>limit for x in out):
            raise ComputeError(f"Plugin {self.name}: coeficiente excede la cota matemática.")
        return from_coefficients(list(out), lhs.startswith("-") != rhs.startswith("-"))


def _opencl_factory():
    from .gpu.opencl import OpenCLBackend
    return OpenCLBackend()

_FACTORIES: dict[str, Callable[[], Backend]] = {
    "cpu": CpuBackend,
    "pykolm": PyKolmBackend,
    "ntt-ref": ReferenceNTTBackend,
    "opencl": lambda: _opencl_factory(),
}


def register_backend(name: str, factory: Callable[[], Backend]) -> None:
    """Install an optional backend without editing the arithmetic engine.

    A backend exposes name, available(), devices(), multiply(a,b).
    Third-party backend code is trusted Python code; install it deliberately.
    """
    if not re.fullmatch(r"[a-z][a-z0-9-]{1,31}", name):
        raise ComputeError("Nombre inválido de backend.")
    if name in _FACTORIES:
        raise ComputeError(f"El backend {name} ya está registrado.")
    if not callable(factory):
        raise ComputeError("Factory de backend inválida.")
    _FACTORIES[name] = factory


class Engine:
    """Unified dispatcher. Never mislabels a CPU result as GPU work."""
    def __init__(self, backend: str = "auto", min_gpu_digits: int = 4096):
        if type(min_gpu_digits) is not int or min_gpu_digits < 1:
            raise ComputeError("min_gpu_digits debe ser un entero positivo.")
        if backend not in (*_FACTORIES.keys(),'auto'):raise ComputeError(f'Backend inválido: {backend}')
        # Explicit CPU providers never initialize optional OpenCL libraries.
        self.backends: dict[str, Backend] = ({name: factory() for name, factory in _FACTORIES.items()}
            if backend=='auto' else {backend:_FACTORIES[backend]()})
        if backend not in (*self.backends.keys(), "auto"):
            raise ComputeError(f"Backend inválido: {backend}")
        self.backend = backend
        self.min_gpu_digits = min_gpu_digits

    def devices(self) -> list[Device]:
        return [device for backend in self.backends.values() for device in backend.devices()]

    def _choose(self, a: str, b: str) -> Backend:
        if self.backend == 'auto':
            # Heuristics only: GPU selection requires BOTH operands to be large.
            if min(len(a.lstrip('-')), len(b.lstrip('-'))) >= self.min_gpu_digits:
                for name in ('opencl-neocruncher', 'opencl', 'rocm', 'cuda', 'neocruncher'):
                    impl = self.backends.get(name)
                    if impl is not None and impl.available():
                        try:
                            required_ntt_length((len(a.lstrip('-'))+3)//4,
                                                (len(b.lstrip('-'))+3)//4)
                        except ComputeError:
                            continue
                        if name == 'opencl' and hasattr(impl,'_memory_guard'):
                            try:
                                impl._memory_guard(required_ntt_length(
                                    (len(a.lstrip('-'))+3)//4,
                                    (len(b.lstrip('-'))+3)//4))
                            except ComputeError:
                                continue
                        return impl
            if min(len(a.lstrip('-')), len(b.lstrip('-'))) >= 512 and max(len(a), len(b)) >= 16000:
                impl = self.backends.get('cpp')
                if impl is not None and impl.available():
                    aa=(len(a.lstrip('-'))+3)//4
                    bb=(len(b.lstrip('-'))+3)//4
                    try:
                        if required_ntt_length(aa,bb) <= (1 << 22):
                            return impl
                    except ComputeError:
                        pass
            return self.backends['cpu']
        impl = self.backends[self.backend]
        if not impl.available():
            raise ComputeError(f"Backend {self.backend} no disponible; elegí 'cpu' o compilá el plugin.")
        return impl

    def multiply_many(self, pairs, verify=True, strict=False) -> list[Multiplication]:
        """Use GPU batch when selected backend implements it; never silently relabel CPU."""
        normalized=[(normalize_integer(a),normalize_integer(b)) for a,b in pairs]
        if not normalized:return []
        choices=[self._choose(a,b) for a,b in normalized]
        if not all(impl is choices[0] for impl in choices) or not hasattr(choices[0],'multiply_many'):
            return [self.multiply(a,b,verify=verify,strict=strict) for a,b in normalized]
        impl=choices[0]
        before=time.perf_counter()
        try:outs=impl.multiply_many(normalized)
        except ComputeError:raise
        except Exception as exc:raise ComputeError(f'Falló GPU batch: {exc}') from exc
        elapsed=time.perf_counter()-before
        if not isinstance(outs,list) or len(outs)!=len(normalized):
            raise ComputeError('GPU batch devolvió una cantidad de resultados incorrecta.')
        answers=[]
        for (a,b),out in zip(normalized,outs):
            if not isinstance(out,str) or not DIGITS_RE.fullmatch(out) or out!=normalize_integer(out):
                raise ComputeError('GPU batch devolvió un entero inválido.')
            correct=verify_modular(a,b,out) if verify or strict else False
            if (verify or strict) and not correct:raise ComputeError('Fallo verificación modular batch.')
            if strict and out!=CpuBackend().multiply(a,b):
                raise ComputeError('Falló verificación exacta batch.')
            answers.append(Multiplication(out,impl.name,elapsed/len(outs),correct,
                                          'exact CPU + modular' if strict else 'modular' if verify else 'disabled',
                                          len(out.lstrip('-'))))
        return answers

    def multiply(self, lhs: str | int, rhs: str | int, verify: bool = True, strict: bool = False) -> Multiplication:
        a, b = normalize_integer(lhs), normalize_integer(rhs)
        implementation = self._choose(a, b)
        start = time.perf_counter()
        try:
            result = implementation.multiply(a, b)
        except ComputeError:
            raise
        except Exception as exc:
            raise ComputeError(f"Falló el backend {implementation.name}: {type(exc).__name__}: {exc}") from exc
        if not isinstance(result, str) or not DIGITS_RE.fullmatch(result):
            raise ComputeError(f"El backend {implementation.name} devolvió un producto no válido.")
        if result != normalize_integer(result):
            raise ComputeError(f"El backend {implementation.name} devolvió un producto no normalizado.")
        elapsed = time.perf_counter()-start
        verified = verify_modular(a, b, result) if (verify or strict) else False
        if (verify or strict) and not verified:
            raise ComputeError("Fallo en verificación modular: se rechaza el resultado.")
        if strict:
            # Deterministic independent full-result comparison. Runs AFTER the
            # timed backend computation, so elapsed_seconds excludes the check.
            if result != CpuBackend().multiply(a, b):
                raise ComputeError('Falló el control exacto CPU: producto incorrecto.')
            verified = True
        return Multiplication(
            value=result, backend=implementation.name, elapsed_seconds=elapsed,
            verified=verified, verification=('exact CPU comparison + 2 modular checks' if strict
                                            else '2 modular checks (not a proof)' if verify else 'disabled'),
            digits=len(result.lstrip("-")),
        )

# Backwards-compatible class alias from Kolmogorov 0.2.
NativeGpuBackend = NativeConvolutionBackend
