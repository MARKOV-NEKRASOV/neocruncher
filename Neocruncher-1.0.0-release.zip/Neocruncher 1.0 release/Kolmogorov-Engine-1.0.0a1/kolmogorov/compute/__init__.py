# SPDX-License-Identifier: GPL-3.0-only
"""Portable, exact computation engine for Kolmogorov."""
from .core import (Engine, Device, Multiplication, ComputeError,
                   CpuBackend, NativeGpuBackend, NativeConvolutionBackend, ReferenceNTTBackend, register_backend)

__all__ = ["Engine", "Device", "Multiplication", "ComputeError",
           "CpuBackend", "NativeGpuBackend", "NativeConvolutionBackend", "ReferenceNTTBackend", "register_backend"]

from .gpu.opencl import OpenCLBackend
from .batch import BatchPlanner, Operation
from .contract import ArithmeticAPI, API_VERSION, estimate_ntt_memory
__all__ += ["OpenCLBackend", "BatchPlanner", "Operation", "ArithmeticAPI", "API_VERSION", "estimate_ntt_memory"]


from .integration import ExactIntegerEngine, PreparedMultiplication
__all__ += ['ExactIntegerEngine','PreparedMultiplication']

# Separate version labels retain the older decimal contract without ambiguity.
from .integration import API_VERSION as INTEGER_API_VERSION
DECIMAL_API_VERSION = API_VERSION
__all__ += ["INTEGER_API_VERSION", "DECIMAL_API_VERSION"]
