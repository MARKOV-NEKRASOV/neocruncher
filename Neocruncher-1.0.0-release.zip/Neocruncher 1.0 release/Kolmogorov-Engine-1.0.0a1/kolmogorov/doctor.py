# SPDX-License-Identifier: GPL-3.0-only
"""Compile AND execute a GPU kernel in a subprocess; contain native loader exits."""
import argparse
from functools import lru_cache
import importlib.metadata
import json
import os
import subprocess
import sys
import time
from .environment import ensure_opencl_environment, environment_report


def child_probe(device, full=False):
    ensure_opencl_environment()
    print('stage=import_pyopencl', flush=True)
    import numpy as np
    import pyopencl as cl
    print('stage=enumerate_gpu', flush=True)
    devices = [d for p in cl.get_platforms() for d in p.get_devices(device_type=cl.device_type.GPU)]
    if not 0 <= device < len(devices):
        raise RuntimeError('GPU index unavailable; check the OpenCL ICD and RUSTICL_ENABLE=radeonsi on AMD.')
    dev = devices[device]
    print('stage=create_context', flush=True)
    ctx = cl.Context([dev]); queue = cl.CommandQueue(ctx)
    print('stage=compile_kernel', flush=True)
    program = cl.Program(ctx, '__kernel void probe(__global uint *out) { out[get_global_id(0)] = 42u; }').build()
    out = np.zeros(16, dtype=np.uint32)
    buf = cl.Buffer(ctx, cl.mem_flags.WRITE_ONLY, out.nbytes)
    cl.Kernel(program, 'probe')(queue, (16,), None, buf)
    cl.enqueue_copy(queue, out, buf).wait()
    if not np.all(out == 42):
        raise ArithmeticError('GPU smoke kernel produced incorrect output')
    if full:
        print('stage=compile_resident_engine', flush=True)
        from .compute.resident import DeviceArithmetic
        rt = DeviceArithmetic(device)
        if rt.decimal(rt.coerce(12345) * 6789, 8) != '83810205':
            raise ArithmeticError('Resident arithmetic smoke test failed')
    result = dict(status='PASS', device=dev.name, vendor=dev.vendor, driver=dev.driver_version,
                  opencl=dev.version, environment=environment_report(), full=full,
                  packages={n: importlib.metadata.version(n) for n in ('numpy','pyopencl','kolmogorov-core')})
    print(json.dumps(result), flush=True)


@lru_cache(maxsize=8)
def _probe(device, full, timeout, environment_key):
    started = time.perf_counter()
    command = [sys.executable, '-m', 'kolmogorov.doctor', '--child', '--device', str(device)]
    if full: command.append('--full')
    try:
        run = subprocess.run(command, capture_output=True, text=True, timeout=timeout)
    except subprocess.TimeoutExpired as exc:
        raise RuntimeError(f'OpenCL preflight exceeded {timeout}s; no calculation started. '
                           'Use python -m kolmogorov.doctor --timeout 600 to investigate.') from exc
    if run.returncode:
        detail = (run.stdout + '\n' + run.stderr)[-12000:]
        raise RuntimeError(f'OpenCL preflight failed in an isolated process (exit {run.returncode}).\n{detail}\n'
                           'For LLVM symbol errors check Conda libraries and use the system-Python launcher. '
                           'No CPU fallback was used.')
    result = json.loads(run.stdout.strip().splitlines()[-1])
    result['preflight_seconds'] = time.perf_counter() - started
    return result


def probe(device=0, full=False, timeout=180):
    ensure_opencl_environment()
    key = tuple((k, os.environ.get(k)) for k in ('RUSTICL_ENABLE','OCL_ICD_VENDORS','LD_LIBRARY_PATH','LD_PRELOAD'))
    return dict(_probe(device, full, timeout, key))


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--child', action='store_true', help=argparse.SUPPRESS)
    p.add_argument('--device', type=int, default=0)
    p.add_argument('--full', action='store_true')
    p.add_argument('--timeout', type=int, default=180)
    a = p.parse_args()
    try:
        if a.child: child_probe(a.device, a.full)
        else: print(json.dumps(probe(a.device, a.full, a.timeout), indent=2))
    except Exception as exc:
        print(str(exc), file=sys.stderr)
        return 1
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
