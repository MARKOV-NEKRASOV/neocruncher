# SPDX-License-Identifier: GPL-3.0-only
"""Shared OpenCL environment contract. No driver imports at module import time."""
import os
from pathlib import Path
import sys


def environment_report():
    maps = Path('/proc/self/maps')
    loaded = []
    if maps.exists():
        loaded = sorted({line.split()[-1] for line in maps.read_text().splitlines()
                         if '/' in line and any(s in line for s in ('libLLVM', 'libclang', 'libRusticl', 'libstdc++'))})
    return {'python': sys.executable, 'python_version': sys.version,
            'base_prefix': sys.base_prefix, 'prefix': sys.prefix,
            'loaded_compiler_libraries': loaded,
            'rusticl_enable': os.environ.get('RUSTICL_ENABLE', '')}


def ensure_opencl_environment():
    report = environment_report()
    paths = [sys.base_prefix, *report['loaded_compiler_libraries'],
             os.environ.get('LD_LIBRARY_PATH', ''), os.environ.get('LD_PRELOAD', '')]
    conda = (Path(sys.base_prefix) / 'conda-meta').is_dir()
    conda = conda or any(any(s in p.lower() for s in ('anaconda', 'miniconda', 'miniforge', 'mambaforge')) for p in paths)
    if conda:
        raise RuntimeError('OpenCL environment rejected: Conda/Anaconda Python or compiler libraries detected. '
                           'System Rusticl may bind to an incompatible LLVM. Run the bundle install.sh --gpu '
                           'and its root run_neocruncher.sh / run_kolmogorov.sh (system-Python .venv-system). '
                           f'Current Python: {sys.executable}; base: {sys.base_prefix}')
    if 'RUSTICL_ENABLE' not in os.environ:
        # Enable before the first platform enumeration; do not override a choice.
        for vendor in Path('/sys/class/drm').glob('card*/device/vendor'):
            try:
                if vendor.read_text().strip().lower() == '0x1002':
                    os.environ['RUSTICL_ENABLE'] = 'radeonsi'
                    break
            except OSError:
                continue
    return report
