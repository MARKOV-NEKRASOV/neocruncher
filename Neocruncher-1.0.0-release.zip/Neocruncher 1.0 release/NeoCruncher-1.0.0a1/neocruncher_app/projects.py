# SPDX-License-Identifier: GPL-3.0-only
"""Named presets for per-project compute budgets. No credentials stored."""
from __future__ import annotations
import json,os,re,tempfile
from pathlib import Path
FIELDS=('ram_mib','vram_mib','workers','backend','device')

def _file(name):
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,49}',name) or name in ('.','..'):
        raise ValueError('Project name: 1..50 ASCII letters/numbers/_/-/. (not . or ..).')
    base=Path(os.environ.get('XDG_CONFIG_HOME',str(Path.home()/'.config')))/'neocruncher'/'projects'
    return base/(name+'.json')

def save_profile(name,parameters):
    p=_file(name);p.parent.mkdir(mode=0o700,parents=True,exist_ok=True)
    payload={f:parameters[f] for f in FIELDS}
    fd,tmp=tempfile.mkstemp(dir=p.parent,prefix='.project-')
    try:
        with os.fdopen(fd,'w') as f:json.dump(payload,f,indent=2);f.write('\n')
        os.chmod(tmp,0o600);os.replace(tmp,p)
    finally:
        if os.path.exists(tmp):os.unlink(tmp)
    return p

def load_profile(name):
    p=_file(name)
    if p.stat().st_size>1024**2:raise ValueError('Project config exceeds 1 MiB')
    data=json.loads(p.read_text())
    if not isinstance(data,dict) or set(data)!=set(FIELDS):
        raise ValueError('Malformed project config')
    if type(data['ram_mib']) not in (int,float) or type(data['vram_mib']) not in (int,float):
        raise ValueError('Invalid memory budgets')
    if type(data['workers']) is not int or type(data['device']) is not int:
        raise ValueError('Invalid project worker / device / tile values')
    if data['backend'] not in ('cpu','opencl-ntt','hybrid-ntt','opencl-bellard','hybrid-bellard'):
        raise ValueError('Invalid project backend')
    return data
