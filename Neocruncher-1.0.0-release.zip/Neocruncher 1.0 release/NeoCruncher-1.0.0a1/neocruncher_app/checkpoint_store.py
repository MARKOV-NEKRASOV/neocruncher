# SPDX-License-Identifier: GPL-3.0-only
"""Durable binary subtree checkpoints, not a full out-of-core arithmetic engine.

A recursion frontier holds file references. Each merge still loads both exact
operands and builds its result in RAM. Local checksums detect accidental damage;
checkpoints are not authenticated mathematical certificates. Never unpickle.
"""
from __future__ import annotations
from contextlib import contextmanager
from contextvars import ContextVar
from dataclasses import dataclass
import hashlib,json,os,shutil,struct,tempfile,time
from pathlib import Path

_ACTIVE=ContextVar('neo041_checkpoint_store',default=None)
REVISION='binary-splitting-v1'
@dataclass(frozen=True)
class NodeRef:
    path:Path
    header:dict

class BinaryNodeStore:
    def __init__(self,folder,*,chunk_terms=4096,max_node_bytes=2**30):
        if type(chunk_terms) is not int or not 32<=chunk_terms<=100000:raise ValueError('Checkpoint terms must be 32..100000')
        self.folder=Path(folder).expanduser().resolve();self.folder.mkdir(parents=True,exist_ok=True,mode=0o700)
        self.chunk_terms=chunk_terms;self.max_node_bytes=int(max_node_bytes)
        self.stats=dict(reused_nodes=0,written_nodes=0,corrupt_nodes=0,bytes_read=0,bytes_written=0,io_seconds=0.0)
    def key(self,family,a,b,arg):
        return dict(revision=REVISION,family=family,start=a,stop=b,arg=arg,chunk_terms=self.chunk_terms)
    def path(self,key):
        digest=hashlib.sha256(json.dumps(key,sort_keys=True,separators=(',',':')).encode()).hexdigest()
        return self.folder/('node-'+digest+'.ncb')
    def lookup(self,key):
        path=self.path(key)
        if not path.exists():return None
        if path.is_symlink():raise ValueError('Checkpoint symlinks are not accepted')
        begin=time.perf_counter()
        try:
            with path.open('rb') as f:
                raw=f.read(4)
                if len(raw)!=4:raise ValueError('Truncated header')
                size=struct.unpack('<I',raw)[0]
                if not 1<=size<=4096:raise ValueError('Oversized checkpoint header')
                header_raw=f.read(size);d=json.loads(header_raw)
                if not isinstance(d,dict):raise ValueError('Invalid checkpoint header')
                if d.get('schema')!='neo041-node-v1' or d.get('key')!=key:raise ValueError('Wrong checkpoint identity')
                fields=d.get('values')
                if not isinstance(fields,list) or len(fields)!=(2 if key['family']=='exp' else 3):raise ValueError('Wrong tuple arity')
                for field in fields:
                    if not isinstance(field,dict) or type(field.get('bytes')) is not int or field['bytes']<1 or type(field.get('sign')) is not int or field.get('sign') not in (-1,0,1):raise ValueError('Invalid integer descriptor')
                payload=sum(v['bytes'] for v in fields)
                if payload>self.max_node_bytes or path.stat().st_size!=4+size+payload+32:raise ValueError('Invalid checkpoint size')
                digest=hashlib.sha256(raw+header_raw)
                remaining=payload
                while remaining:
                    block=f.read(min(1024**2,remaining))
                    if not block:raise ValueError('Truncated payload')
                    digest.update(block);remaining-=len(block)
                if f.read(32)!=digest.digest():raise ValueError('Checkpoint checksum mismatch')
                self.stats['bytes_read']+=4+size+payload+32
            self.stats['reused_nodes']+=1
            return NodeRef(path,d)
        except (OSError,ValueError,KeyError,TypeError,UnicodeError,struct.error):
            self.stats['corrupt_nodes']+=1
            return None
        finally:self.stats['io_seconds']+=time.perf_counter()-begin
    def load(self,ref):
        begin=time.perf_counter()
        result=[]
        with ref.path.open('rb') as f:
            raw=f.read(4)
            if len(raw)!=4:raise ValueError('Truncated checkpoint header')
            size=struct.unpack('<I',raw)[0]
            if not 1<=size<=4096:raise ValueError('Invalid checkpoint header size')
            header_raw=f.read(size)
            digest=hashlib.sha256(raw+header_raw)
            if json.loads(header_raw)!=ref.header:raise ValueError('Checkpoint changed after lookup')
            for field in ref.header['values']:
                raw_value=f.read(field['bytes'])
                if len(raw_value)!=field['bytes']:raise ValueError('Truncated checkpoint integer')
                digest.update(raw_value)
                value=int.from_bytes(raw_value,'little')
                if (field['sign']==0)!=(value==0):raise ValueError('Noncanonical checkpoint zero')
                result.append(field['sign']*value)
            if f.read(32)!=digest.digest() or f.read(1):raise ValueError('Checkpoint changed or is corrupt')
        self.stats['bytes_read']+=ref.path.stat().st_size
        self.stats['io_seconds']+=time.perf_counter()-begin
        return tuple(result)
    def put(self,key,values):
        values=tuple(int(v) for v in values)
        if len(values) not in (2,3):raise ValueError('Checkpoint needs exact int tuples')
        fields=[dict(sign=0 if v==0 else -1 if v<0 else 1,bytes=max(1,(abs(v).bit_length()+7)//8)) for v in values]
        total=sum(f['bytes'] for f in fields)
        if total>self.max_node_bytes:raise MemoryError('Checkpoint node exceeds configured admission size')
        if total+8192>shutil.disk_usage(self.folder).free*.9:raise OSError('Insufficient checkpoint disk space')
        header=dict(schema='neo041-node-v1',key=key,values=fields)
        header_raw=json.dumps(header,separators=(',',':'),sort_keys=True).encode()
        prefix=struct.pack('<I',len(header_raw))+header_raw
        path=self.path(key)
        if path.is_symlink():raise ValueError('Checkpoint symlinks are not accepted')
        begin=time.perf_counter();fd,temp=tempfile.mkstemp(prefix='.partial-',dir=self.folder)
        try:
            with os.fdopen(fd,'wb') as f:
                digest=hashlib.sha256(prefix);f.write(prefix)
                for value,field in zip(values,fields):
                    raw=abs(value).to_bytes(field['bytes'],'little')
                    for start in range(0,len(raw),1024**2):
                        block=raw[start:start+1024**2];digest.update(block);f.write(block)
                f.write(digest.digest());f.flush();os.fsync(f.fileno())
            os.replace(temp,path)
            if hasattr(os,'O_DIRECTORY'):
                directory_fd=os.open(self.folder,os.O_RDONLY|os.O_DIRECTORY)
                try:os.fsync(directory_fd)
                finally:os.close(directory_fd)
            self.stats['written_nodes']+=1;self.stats['bytes_written']+=path.stat().st_size
        finally:
            if os.path.exists(temp):os.unlink(temp)
            self.stats['io_seconds']+=time.perf_counter()-begin
        return NodeRef(path,header)
    def prune(self,refs):
        # Parent is durable before completed children are pruned.
        for ref in refs:
            try:ref.path.unlink()
            except FileNotFoundError:pass

@contextmanager
def use_checkpoint_store(folder,*,chunk_terms=4096,max_node_bytes=2**30):
    store=BinaryNodeStore(folder,chunk_terms=chunk_terms,max_node_bytes=max_node_bytes) if folder else None
    lock=None
    if store is not None:
        import fcntl
        lock_path=store.folder/'.run.lock'
        if lock_path.is_symlink():raise ValueError('Checkpoint lock cannot be a symlink')
        lock=lock_path.open('a+b')
        try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:
            lock.close()
            raise RuntimeError('Another calculation is using this checkpoint directory') from None
    token=_ACTIVE.set(store)
    try:yield store
    finally:
        _ACTIVE.reset(token)
        if lock is not None:
            fcntl.flock(lock,fcntl.LOCK_UN);lock.close()

def active_store():return _ACTIVE.get()

def checkpointed_splitting(store,family,a,b,arg,leaf,merge,tracking,progress_context):
    if tracking is not None:tracking.start(b-a)
    def credit(count):
        if tracking is not None:
            tracking.done+=count;tracking.overall_done+=count;tracking.report()
    def visit(start,stop):
        key=store.key(family,start,stop,arg)
        cached=store.lookup(key)
        if cached is not None:
            credit(stop-start-1)
            return cached
        chunks=(stop-start+store.chunk_terms-1)//store.chunk_terms
        if chunks<=1:
            token=progress_context.set(None)
            try:value=leaf(family,start,stop,arg)
            finally:progress_context.reset(token)
            credit(stop-start-1)
            return store.put(key,value)
        split=start+(chunks//2)*store.chunk_terms
        left=visit(start,split)
        right=visit(split,stop)
        lv,rv=store.load(left),store.load(right)
        value=merge(family,lv,rv)
        del lv,rv
        parent=store.put(key,value)
        del value
        store.prune((left,right))
        return parent
    return store.load(visit(a,b))
