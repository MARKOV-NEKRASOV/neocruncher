# SPDX-License-Identifier: GPL-3.0-only
"""Non-executing large-precision feasibility checks, NOT a fake 1B benchmark."""
from __future__ import annotations
import json
from .budgets import estimate_ram_mib
from .hardware import _human_bytes,diagnosis

def probe(digits=1_000_000_000):
    if type(digits) is not int or digits<1:raise ValueError('Precision must be a positive integer.')
    return {'test_kind':'preflight only (no billion-digit computation)',
            'requested_decimal_places':digits,
            'current_engine_cap':None,
            'within_current_engine_cap':True,
            'minimum_txt_bytes':digits+3, # '3.' + digits + LF for pi
            'approx_chudnovsky_terms':digits//14+4,
            'rough_cpu_ram_estimate_mib':estimate_ram_mib(digits,'pi_chudnovsky',1),
            'available_ram_bytes':diagnosis()['ram'].get('available_bytes'),
            'conclusion':'NOT RUN: resource viability requires a real benchmark; no artificial count cap',
            'warning':'RAM figure is a rough guide, not a safe upper bound; runtime and scratch storage unmeasured'}

def print_probe(digits=1_000_000_000):
    p=probe(digits)
    print('\n  NeoCruncher one-billion-digit feasibility probe — NO calculation executed')
    print(f"  Digits requested: {p['requested_decimal_places']:,}")
    print('  CPU hard precision cap: none (resource-limited)')
    print('  TXT minimum: '+_human_bytes(p['minimum_txt_bytes']))
    print(f"  Approximate Chudnovsky terms: {p['approx_chudnovsky_terms']:,}")
    print(f"  Rough RAM planning estimate: {p['rough_cpu_ram_estimate_mib']:,.0f} MiB (not a bound)")
    print('  '+p['conclusion'])
    print('  Actual billion-digit execution, timings and correctness are NOT tested.')
    return p
