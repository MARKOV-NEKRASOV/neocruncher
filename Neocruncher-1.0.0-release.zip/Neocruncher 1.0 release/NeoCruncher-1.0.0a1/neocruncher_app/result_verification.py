# SPDX-License-Identifier: GPL-3.0-only
"""Validate verification scope before work, preserve output before external checks."""
import json,os,tempfile,time
from pathlib import Path
from .verification import MAX_VERIFY_DIGITS,SUPPORTED,verify_text

def request_scope(a):
    prefix=getattr(a,'verify_prefix',0)
    full=bool(getattr(a,'verify',False))
    if full and prefix:raise ValueError('Choose --verify OR --verify-prefix, not both')
    if not full and not prefix:return None
    if a.benchmark:raise ValueError('Independent result verification requires a calculation, not --benchmark')
    if a.expression is not None or a.function is not None or a.bellard_offset is not None:
        raise ValueError('Independent verification applies to supported built-in decimal constants only')
    if a.constant not in SUPPORTED:raise ValueError('No independent numerical verifier for this constant')
    places=a.digits if full else prefix
    if type(places) is not int or not 1<=places<=MAX_VERIFY_DIGITS:
        raise ValueError(f'Full verification supports 1..{MAX_VERIFY_DIGITS:,} decimal places. '
            f'For a larger result use --verify-prefix {MAX_VERIFY_DIGITS} explicitly, or omit verification.')
    if places>a.digits:raise ValueError('--verify-prefix cannot exceed the requested decimal places')
    return dict(kind='full' if full else 'prefix',requested_decimal_places=a.digits,checked_decimal_places=places,
        limitation='Independent mpmath numerical comparison; prefix mode does not check remaining digits')

def update_owned_report(path,report,expected):
    """Atomically replace only the just-created sidecar, reject detected external edits."""
    path=Path(path)
    if path.read_bytes()!=expected:raise RuntimeError('Saved report changed externally; refusing to replace it')
    fd,tmp=tempfile.mkstemp(prefix=path.name+'.',suffix='.tmp',dir=path.parent)
    try:
        with os.fdopen(fd,'w',encoding='utf8') as f:
            json.dump(report,f,ensure_ascii=False,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
        if path.read_bytes()!=expected:raise RuntimeError('Saved report changed externally; refusing to replace it')
        os.replace(tmp,path)
    finally:
        if os.path.exists(tmp):os.unlink(tmp)

def save_then_verify(output,text,report,scope,notify=None):
    from .core import save_result
    report['independent_verification_scope']=scope or dict(kind='none',checked_decimal_places=0)
    report['independent_verification']='PENDING: result saved; independent verification not completed' if scope else 'NOT RUN'
    if notify:notify(dict(stage='Saving computed TXT and report before independent verification'))
    path,sidecar=save_result(output,text,report)
    if scope is None:return path,sidecar
    expected=sidecar.read_bytes();start=time.perf_counter()
    try:
        if notify:notify(dict(stage=f'Independent {scope["kind"]} verification: {scope["checked_decimal_places"]:,} decimals'))
        places=scope['checked_decimal_places']
        candidate=text if scope['kind']=='full' else text[:text.index('.')+1+places]
        verify_text(candidate,report['constant'],places)
        report['independent_verification']=('PASS: all requested decimal places match an independent mpmath computation'
            if scope['kind']=='full' else f'PASS_PREFIX: first {places:,} decimal places match independent mpmath; remaining digits NOT independently checked')
    except BaseException as exc:
        report['independent_verification']=('CANCELLED: ' if isinstance(exc,KeyboardInterrupt) else 'FAIL: ')+str(exc)
        report['independent_verification_seconds']=time.perf_counter()-start
        update_owned_report(sidecar,report,expected)
        print(f'  Computed result preserved: {path} + {sidecar}',flush=True)
        raise
    report['independent_verification_seconds']=time.perf_counter()-start
    update_owned_report(sidecar,report,expected)
    return path,sidecar
