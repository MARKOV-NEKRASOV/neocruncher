# SPDX-License-Identifier: GPL-3.0-only
"""A small hardware smoke test never qualifies a billion-digit calculation."""
import json
from pathlib import Path

def readiness(device=0,report_file=None):
    from .core import compute,independently_verify
    samples=[]
    for engine in ('native','kolmogorov'):
        try:
            text,report=compute('pi',100,'pi_chudnovsky','opencl-ntt',device=device,engine=engine)
            independently_verify(text,'pi',100)
            samples.append(dict(engine=engine,status='PASS small GPU-pure computation',
                digits=100,seconds=report['seconds'],metrics=report['details']['metrics']))
        except Exception as exc:
            samples.append(dict(engine=engine,status='FAIL',error=f'{type(exc).__name__}: {exc}'))
    data=dict(version='1.0.0a1',target_decimal_places=1000000000,
        full_gpu_pi_implemented=True,full_gpu_pi_ready=False,
        status='UNQUALIFIED FOR 1B',samples=samples,
        scope='Small computations plus separate CPU verification, not a billion-digit run',
        remaining_requirements=[
            'Validate 100M and 1B on the target GPU and driver.',
            'Measure whole-job time, working memory and RAM storage traffic.',
            'Confirm output independently at the target precision.',
            'GPU division uses full-precision Newton; large-scale performance is unqualified.',
            'SSD arithmetic storage is not implemented.'
        ])
    print(json.dumps(data,indent=2))
    if report_file:
        path=Path(report_file)
        with path.open('x',encoding='utf8') as stream:json.dump(data,stream,indent=2)
    return 3
