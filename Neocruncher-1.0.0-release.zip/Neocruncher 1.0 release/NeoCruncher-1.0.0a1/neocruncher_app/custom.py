# SPDX-License-Identifier: GPL-3.0-only
"""A restricted real-valued, arbitrary precision expression language.

Only AST nodes listed below are accepted.  This is numerical evaluation, not
an interval proof; matching guard-precision runs are a heuristic only.
"""
from __future__ import annotations
import ast
import hashlib
import re
from fractions import Fraction
import time
import sys

# High-precision decimal export may legitimately exceed Python's default
# 4300-digit integer-to-string conversion protection. Inputs are restricted AST.
if hasattr(sys, "set_int_max_str_digits"):
    sys.set_int_max_str_digits(0)

MAX_EXPRESSION = 250
MAX_NODES = 65
MAX_LITERAL_CHARS = 128
MAX_LITERAL_EXPONENT = 100000

CONSTANTS = ('pi', 'e', 'tau', 'phi', 'sqrt2', 'ln2', 'ln10', 'zeta3', 'zeta5',
             'catalan', 'euler_gamma', 'gamma_quarter', 'gamma_third', 'gamma_fifth')
FUNCTION_DOMAINS = {
    'sqrt':'x >= 0', 'root':'x >= 0 for even roots',
    'ln':'x > 0', 'log':'x > 0; optional base > 0 and != 1', 'log2':'x > 0', 'log10':'x > 0',
    'exp':'all real x',
    'sin':'all real x', 'cos':'all real x', 'tan':'cos(x) != 0',
    'cot':'sin(x) != 0', 'sec':'cos(x) != 0', 'csc':'sin(x) != 0',
    'asin':'-1 <= x <= 1', 'acos':'-1 <= x <= 1', 'atan':'all real x',
    'acot':'all real x', 'asec':'|x| >= 1', 'acsc':'|x| >= 1',
    'sinh':'all real x', 'cosh':'all real x', 'tanh':'all real x',
    'coth':'x != 0', 'sech':'all real x', 'csch':'x != 0',
    'asinh':'all real x', 'acosh':'x >= 1', 'atanh':'-1 < x < 1',
    'acoth':'|x| > 1', 'asech':'0 < x <= 1', 'acsch':'x != 0',
    'gamma':'x not in {0, -1, -2, ...}', 'zeta':'x != 1',
    'agm':'two positive real inputs',
}
FUNCTIONS=tuple(FUNCTION_DOMAINS)
_ALIAS = {'arcsin':'asin','arccos':'acos','arctan':'atan','arcsinh':'asinh',
          'arccosh':'acosh','arctanh':'atanh','arccot':'acot',
          'arcsec':'asec','arccsc':'acsc', 'arccoth':'acoth',
          'arcsech':'asech','arccsch':'acsch'}


def _safe_real(value, mp, label):
    if isinstance(value,mp.mpc) or not mp.isfinite(value):
        raise ValueError(f'{label}: result must be finite and real.')
    return value


def _exact_integer_log_power(x, base, mp):
    """Exact small integer-power identities, independent of floating log.

    A ratio of two transcendental log evaluations can be one ulp below an
    *integer* even at thousands of digits (log(8)/log(2) is a common case).
    Returning the exact exponent prevents exporting the wrong truncated digit.
    This recognizes only simple integer powers and their reciprocals; it does
    not claim to resolve all symbolic identities.
    """
    if x == 1:
        return mp.mpf(0)
    if x == base:
        return mp.mpf(1)
    if base < 2 or base != mp.floor(base) or base > 10**12:
        return None
    b = int(base)
    inverted = False
    y = x
    if 0 < y < 1:
        y = 1 / y
        inverted = True
    if y < 1 or y > 10**120 or y != mp.floor(y):
        return None
    n = int(y)
    k = 0
    while n > 1 and k <= 400:
        n, r = divmod(n, b)
        if r:
            return None
        k += 1
    if n == 1:
        return mp.mpf(-k if inverted else k)
    return None


def _exact_integer_root(x, degree, mp):
    """Detect small perfect integer powers with exact integer arithmetic."""
    if x == 0 or x == 1:
        return x
    if x < 0 or x > 10**120 or x != mp.floor(x):
        return None
    n = int(x)
    lo, hi = 0, 1 << ((n.bit_length() + degree - 1) // degree)
    while lo + 1 < hi:
        mid = (lo + hi) // 2
        if pow(mid, degree) > n:
            hi = mid
        else:
            lo = mid
    return mp.mpf(lo) if pow(lo, degree) == n else (mp.mpf(hi) if pow(hi, degree) == n else None)


def _function(name, args, mp):
    name=_ALIAS.get(name,name)
    if name not in FUNCTION_DOMAINS:
        raise ValueError(f'Function {name!r} is not permitted.')
    if name == 'agm':
        if len(args)!=2:raise ValueError('agm requires exactly two arguments.')
        a,b=args
        if a<=0 or b<=0:raise ValueError('agm requires two positive real inputs.')
        return _safe_real(mp.agm(a,b),mp,name)
    if name == 'log' and len(args)==2:
        x,base=args
        if x<=0 or base<=0 or base==1:
            raise ValueError('log(x,base) requires x > 0, base > 0, base != 1.')
        exact = _exact_integer_log_power(x, base, mp)
        if exact is not None:
            return exact
        return _safe_real(mp.log(x)/mp.log(base),mp,name)
    if name == 'root':
        if len(args)!=2:raise ValueError('root(x,n) requires exactly two arguments.')
        x,n=args
        if not 1<=n<=1024 or n!=int(n):raise ValueError('root exponent must be integer 1..1024.')
        n=int(n)
        if x<0 and n%2==0:raise ValueError('root(x,n): even root requires x >= 0.')
        exact = _exact_integer_root(abs(x), n, mp)
        if exact is not None:
            return exact if x >= 0 else -exact
        return mp.root(x,n) if x>=0 else -mp.root(-x,n)
    if len(args)!=1:
        raise ValueError(f'{name}(x) requires exactly one argument, except log(x,base), root(x,n) and agm(a,b).')
    x=args[0]
    if name in ('sqrt',) and x >= 0:
        exact = _exact_integer_root(x, 2, mp)
        if exact is not None: return exact
    if name in ('sqrt',) and x<0:raise ValueError('sqrt requires x >= 0.')
    if name in ('ln','log','log10','log2') and x<=0:raise ValueError(f'{name} requires x > 0.')
    if name in ('asin','acos') and abs(x)>1:raise ValueError(f'{name} requires -1 <= x <= 1.')
    if name in ('acosh',) and x<1:raise ValueError('acosh requires x >= 1.')
    if name in ('atanh',) and abs(x)>=1:raise ValueError('atanh requires -1 < x < 1.')
    if name in ('acoth',) and abs(x)<=1:raise ValueError('acoth requires |x| > 1.')
    if name in ('asech',) and not (0<x<=1):raise ValueError('asech requires 0 < x <= 1.')
    if name in ('asec','acsc') and abs(x)<1:raise ValueError(f'{name} requires |x| >= 1.')
    if name in ('coth','csch','acsch') and x==0:raise ValueError(f'{name} requires x != 0.')
    if name in ('gamma',) and x<=0 and x==int(x):raise ValueError('gamma has a pole at nonpositive integers.')
    if name=='zeta' and x==1:raise ValueError('zeta has a pole at x=1.')
    if name in ('tan','sec') and mp.cos(x)==0:
        raise ValueError(f'{name} is undefined when cos(x)=0.')
    if name in ('cot','csc') and mp.sin(x)==0:
        raise ValueError(f'{name} is undefined when sin(x)=0.')
    fn={
        'sqrt':mp.sqrt,'ln':mp.log,'log':mp.log, 'log2':lambda x:mp.log(x,2),
        'log10':mp.log10, 'exp':mp.exp,
        'sin':mp.sin,'cos':mp.cos,'tan':mp.tan,
        'cot':mp.cot,'sec':mp.sec,'csc':mp.csc,
        'asin':mp.asin,'acos':mp.acos,'atan':mp.atan,
        'acot':lambda x:mp.pi/2-mp.atan(x),
        'asec':lambda x:mp.acos(1/x), 'acsc':lambda x:mp.asin(1/x),
        'sinh':mp.sinh,'cosh':mp.cosh,'tanh':mp.tanh,
        'coth':mp.coth,'sech':mp.sech,'csch':mp.csch,
        'asinh':mp.asinh,'acosh':mp.acosh,'atanh':mp.atanh,
        'acoth':lambda x:mp.atanh(1/x),
        'asech':lambda x:mp.acosh(1/x),
        'acsch':lambda x:mp.asinh(1/x),
        'gamma':mp.gamma,'zeta':mp.zeta,
    }[name]
    return _safe_real(fn(x),mp,name)


def _evaluate(expression, mp):
    if not isinstance(expression,str) or not expression.strip() or len(expression)>MAX_EXPRESSION:
        raise ValueError('Expression must contain 1..250 characters.')
    try:tree=ast.parse(expression,mode='eval')
    except SyntaxError as e:raise ValueError(f'Invalid expression: {e.msg}') from e
    if sum(1 for _ in ast.walk(tree))>MAX_NODES:
        raise ValueError('Expression too complicated (maximum 65 AST nodes).')
    def rational_expr(n):
        """Recognize a small exact rational without evaluating floating values."""
        if isinstance(n,ast.Constant) and type(n.value) is int and abs(n.value)<=1000000:
            return Fraction(n.value)
        if isinstance(n,ast.UnaryOp) and isinstance(n.op,(ast.UAdd,ast.USub)):
            z=rational_expr(n.operand)
            return (z if isinstance(n.op,ast.UAdd) else -z) if z is not None else None
        if isinstance(n,ast.BinOp) and isinstance(n.op,(ast.Mult,ast.Div,ast.Add,ast.Sub)):
            a,b=rational_expr(n.left),rational_expr(n.right)
            if a is None or b is None:return None
            if isinstance(n.op,ast.Mult):return a*b
            if isinstance(n.op,ast.Div):return a/b if b else None
            if isinstance(n.op,ast.Add):return a+b
            return a-b
        return None

    def pi_factor(n):
        """Find literal rational multiples of pi, for exact trig special values."""
        if isinstance(n,ast.Name) and n.id=='pi':return Fraction(1)
        if isinstance(n,ast.UnaryOp) and isinstance(n.op,(ast.UAdd,ast.USub)):
            z=pi_factor(n.operand)
            return (z if isinstance(n.op,ast.UAdd) else -z) if z is not None else None
        if isinstance(n,ast.BinOp):
            if isinstance(n.op,(ast.Mult,ast.Div)):
                a,b=pi_factor(n.left),rational_expr(n.right)
                if a is not None and b is not None:
                    return a*b if isinstance(n.op,ast.Mult) else (a/b if b else None)
                a,b=rational_expr(n.left),pi_factor(n.right)
                if isinstance(n.op,ast.Mult) and a is not None and b is not None:return a*b
            if isinstance(n.op,(ast.Add,ast.Sub)):
                a,b=pi_factor(n.left),pi_factor(n.right)
                if a is not None and b is not None:
                    return a+b if isinstance(n.op,ast.Add) else a-b
        return None

    def exact_trig(name,arg_node):
        k=pi_factor(arg_node)
        if k is None:
            k=rational_expr(arg_node)
            if k!=0:return None
        k=k%2
        if name in ('sin','cos','tan','cot','sec','csc'):
            # Exact rational values where the identity is elementary.
            sinhalf={Fraction(0):0,Fraction(1,6):Fraction(1,2),Fraction(1,2):1,
                     Fraction(5,6):Fraction(1,2),Fraction(1):0,
                     Fraction(7,6):-Fraction(1,2),Fraction(3,2):-1,
                     Fraction(11,6):-Fraction(1,2)}
            coshalf={Fraction(0):1,Fraction(1,3):Fraction(1,2),Fraction(1,2):0,
                     Fraction(2,3):-Fraction(1,2),Fraction(1):-1,
                     Fraction(4,3):-Fraction(1,2),Fraction(3,2):0,
                     Fraction(5,3):Fraction(1,2)}
            if name=='sin' and k in sinhalf:return mp.mpf(sinhalf[k].numerator)/sinhalf[k].denominator if isinstance(sinhalf[k],Fraction) else mp.mpf(sinhalf[k])
            if name=='cos' and k in coshalf:return mp.mpf(coshalf[k].numerator)/coshalf[k].denominator if isinstance(coshalf[k],Fraction) else mp.mpf(coshalf[k])
            if name in ('tan','sec') and k in (Fraction(1,2),Fraction(3,2)):
                raise ValueError(f'{name} undefined: cos(x) = 0.')
            if name in ('cot','csc') and k in (Fraction(0),Fraction(1)):
                raise ValueError(f'{name} undefined: sin(x) = 0.')
            if name=='tan' and k in (Fraction(0),Fraction(1)):return mp.mpf(0)
            if name=='tan' and k in (Fraction(1,4),Fraction(5,4)):return mp.mpf(1)
            if name=='tan' and k in (Fraction(3,4),Fraction(7,4)):return -mp.mpf(1)
            if name=='cot' and k in (Fraction(1,2),Fraction(3,2)):return mp.mpf(0)
            if name=='cot' and k in (Fraction(1,4),Fraction(5,4)):return mp.mpf(1)
            if name=='cot' and k in (Fraction(3,4),Fraction(7,4)):return -mp.mpf(1)
            if name=='sec' and k in coshalf and coshalf[k]:
                return mp.mpf(coshalf[k].denominator)/coshalf[k].numerator if isinstance(coshalf[k],Fraction) else mp.mpf(1)/coshalf[k]
            if name=='csc' and k in sinhalf and sinhalf[k]:
                return mp.mpf(sinhalf[k].denominator)/sinhalf[k].numerator if isinstance(sinhalf[k],Fraction) else mp.mpf(1)/sinhalf[k]
        return None

    values={
        'pi':lambda:mp.pi, 'tau':lambda:2*mp.pi,'e':lambda:mp.e,
        'phi':lambda:(1+mp.sqrt(5))/2,
        'sqrt2':lambda:mp.sqrt(2),'ln2':lambda:mp.log(2),'ln10':lambda:mp.log(10),
        'zeta3':lambda:mp.zeta(3),'zeta5':lambda:mp.zeta(5),
        'catalan':lambda:mp.catalan,'euler_gamma':lambda:mp.euler,
        'gamma_quarter':lambda:mp.gamma(mp.mpf(1)/4),
        'gamma_third':lambda:mp.gamma(mp.mpf(1)/3),
        'gamma_fifth':lambda:mp.gamma(mp.mpf(1)/5),
    }
    def go(n):
        if isinstance(n,ast.Constant) and type(n.value) in (int,float):
            raw=ast.get_source_segment(expression,n)
            if not raw or len(raw)>MAX_LITERAL_CHARS:
                raise ValueError('Numeric literals must contain at most 128 characters.')
            raw=raw.replace('_','')
            match=re.search(r'[eE]([+-]?\d+)$',raw)
            if match and (len(match.group(1))>8 or abs(int(match.group(1)))>MAX_LITERAL_EXPONENT):
                raise ValueError('Decimal literal exponent exceeds safe limits.')
            return _safe_real(mp.mpf(raw),mp,'literal')
        if isinstance(n,ast.Name) and n.id in values:return values[n.id]()
        if isinstance(n,ast.UnaryOp) and isinstance(n.op,(ast.UAdd,ast.USub)):
            v=go(n.operand);return v if isinstance(n.op,ast.UAdd) else -v
        if isinstance(n,ast.BinOp) and isinstance(n.op,(ast.Add,ast.Sub,ast.Mult,ast.Div,ast.Pow)):
            a=go(n.left);b=go(n.right)
            if isinstance(n.op,ast.Add):r=a+b
            elif isinstance(n.op,ast.Sub):r=a-b
            elif isinstance(n.op,ast.Mult):r=a*b
            elif isinstance(n.op,ast.Div):
                if b==0:raise ValueError('Division by zero.')
                r=a/b
            else:
                if abs(b)>256 or b != int(b):
                    raise ValueError('Only integer powers with |exponent| <= 256 are supported.')
                if a==0 and b<0:raise ValueError('Zero to a negative power is undefined.')
                r=a**int(b)
            return _safe_real(r,mp,'arithmetic')
        if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and not n.keywords:
            name=n.func.id
            if name not in FUNCTION_DOMAINS and name not in _ALIAS:
                raise ValueError(f'Function {name!r} is not permitted.')
            if len(n.args)==1:
                if name in ('ln','log') and isinstance(n.args[0],ast.Name) and n.args[0].id=='e':
                    return mp.mpf(1)
                if name in ('sin','cos','tan','cot','sec','csc'):
                    exact=exact_trig(name,n.args[0])
                    if exact is not None:return exact
            return _function(name,[go(arg) for arg in n.args],mp)
        raise ValueError('Unsupported syntax. Use numbers, named constants, functions and + - * / ** only.')
    return _safe_real(go(tree.body),mp,'expression')


def _format_truncated(value,places,mp):
    sign='-' if value<0 else ''
    scaled=int(mp.floor(abs(value)*mp.power(10,places)))
    raw=str(scaled).zfill(places+1)
    return sign+raw[:-places]+'.'+raw[-places:]


def compute_custom(expression:str,places:int):
    """Numerically evaluate twice using additional guard digits, NOT a proof."""
    if type(places) is not int or places<1:raise ValueError('Precision must be a positive integer.')
    try:import mpmath as mp
    except ImportError as err:
        raise RuntimeError('Custom constants require mpmath: run the root install.sh') from err
    from .progress import emitter
    progress=emitter(console=False)
    progress({'stage':'Evaluating custom expression: first precision pass'})
    start=time.perf_counter()
    try:
        with mp.workdps(places+30):first=_format_truncated(_evaluate(expression,mp),places,mp)
        progress({'stage':'Evaluating custom expression: second precision pass'})
        with mp.workdps(places+60):second=_format_truncated(_evaluate(expression,mp),places,mp)
    except (ZeroDivisionError,OverflowError) as err:
        raise ValueError(f'Custom expression undefined or exceeds limits: {err}') from err
    progress({'stage':'Checking custom numerical stability'})
    if first!=second:
        raise ArithmeticError('Numerical instability detected: guard-precision runs disagreed; no TXT written.')
    from .core import APP_VERSION
    return second,{
        'program':'NeoCruncher','version':APP_VERSION,'constant':'custom','algorithm':'custom_expression',
        'expression':expression,'backend':'cpu','cpu_workers':1,
        'decimal_places':places,'rounding':'truncation toward zero',
        'seconds':time.perf_counter()-start,
        'verification_scope':'UNCERTIFIED approximate computation; two mpmath guard-precision runs agree; NOT a proof.',
        'independent_verification':'NOT PROVEN','details':{'stability':'two mpmath evaluations', 'certification':'NOT CERTIFIED'},
        'sha256':hashlib.sha256((second+'\n').encode('ascii')).hexdigest(),
    }
