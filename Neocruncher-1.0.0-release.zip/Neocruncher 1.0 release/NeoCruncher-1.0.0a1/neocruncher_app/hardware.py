# SPDX-License-Identifier: GPL-3.0-only
"""Read-only device discovery. Drivers are never installed silently."""
from __future__ import annotations
import json
import os
import ctypes.util
from pathlib import Path
import platform
import shutil
import subprocess
import sys


def _human_bytes(count):
    if count is None:return 'unknown'
    try:value=float(count)
    except OverflowError:return f'>10^308 bytes (far beyond addressable storage)'
    mib=value/(1024**2)
    if not 0<=mib<float('inf'):return 'not estimated'
    primary=f'{mib:,.0f} MiB' if mib>=100 else f'{mib:,.2f} MiB'
    return primary+(f' ({mib/1024:,.2f} GiB)' if mib>=1024 else '')



def _meminfo():
    data={};process_limit=None
    try:
        for line in Path('/proc/meminfo').read_text().splitlines():
            if ':' not in line:continue
            key,_,rest=line.partition(':')
            if key in ('MemTotal','MemAvailable','SwapTotal'):
                data[key]=int(rest.split()[0])*1024
    except (OSError,ValueError,IndexError):pass
    # Respect a Linux cgroup-v2 limit instead of reporting the host's full RAM
    # as available inside a container or a constrained service.
    try:
        raw=Path('/sys/fs/cgroup/memory.max').read_text().strip()
        if raw!='max':
            ceiling=int(raw)
            current=int(Path('/sys/fs/cgroup/memory.current').read_text().strip())
            process_limit=ceiling
            data['MemAvailable']=min(data.get('MemAvailable',ceiling),max(0,ceiling-current))
    except (OSError,ValueError):pass
    if 'MemTotal' not in data and hasattr(os,'sysconf'):
        try:data['MemTotal']=os.sysconf('SC_PHYS_PAGES')*os.sysconf('SC_PAGE_SIZE')
        except (ValueError,OSError):pass
    return {'total_bytes':data.get('MemTotal'),'available_bytes':data.get('MemAvailable'),
            'swap_total_bytes':data.get('SwapTotal'),'process_limit_bytes':process_limit,
            'effective_capacity_bytes':min(data.get('MemTotal',process_limit) or 0,process_limit) if process_limit else data.get('MemTotal')}


def _cpu_info():
    name=platform.processor() or 'unknown'
    try:
        for line in Path('/proc/cpuinfo').read_text().splitlines():
            if line.startswith('model name'):
                name=line.split(':',1)[1].strip();break
    except OSError:pass
    return {'model':name,'logical_threads':os.cpu_count() or 1}


def _gpu_vram(pci_path):
    drm=pci_path/'drm'
    if drm.is_dir():
        for card in sorted(drm.glob('card[0-9]*')):
            try:
                total=int((card/'device/mem_info_vram_total').read_text().strip())
                try:used=int((card/'device/mem_info_vram_used').read_text().strip())
                except (OSError,ValueError):used=None
                return {'total_bytes':total,'used_bytes':used, 'source':'amdgpu sysfs'}
            except (OSError,ValueError):pass
    try:
        total=int((pci_path/'mem_info_vram_total').read_text().strip())
        try:used=int((pci_path/'mem_info_vram_used').read_text().strip())
        except (OSError,ValueError):used=None
        return {'total_bytes':total,'used_bytes':used, 'source':'amdgpu sysfs'}
    except (OSError,ValueError):pass
    return {'total_bytes':None,'used_bytes':None,'source':None}


def _pci_display():
    found=[]
    for p in sorted(Path('/sys/bus/pci/devices').glob('*')):
        try:
            if int((p/'class').read_text().strip(),16)>>16 != 3:continue
            vid=(p/'vendor').read_text().strip().lower()
            found.append({'pci':p.name,'vendor_id':vid,
                          'vendor':{'0x1002':'AMD','0x10de':'NVIDIA','0x8086':'Intel'}.get(vid,'Other'),
                          'driver':(p/'driver').resolve().name if (p/'driver').exists() else 'none',
                          'vram':_gpu_vram(p)})
        except (OSError,ValueError): pass
    return found


def opencl_devices():
    """Returns GPU device objects; enable AMD Rusticl for this process only."""
    if 'RUSTICL_ENABLE' not in os.environ and any(x['vendor']=='AMD' for x in _pci_display()):
        os.environ['RUSTICL_ENABLE']='radeonsi'
    try:
        from kolmogorov.environment import ensure_opencl_environment
        ensure_opencl_environment()
        import pyopencl as cl
    except (ImportError, RuntimeError):
        return []

    def enumerate_devs():
        result=[]
        try:
            for platform in cl.get_platforms():
                for d in platform.get_devices(device_type=cl.device_type.GPU):
                    result.append({'object':d,'name':d.name.strip(),
                                   'vendor':d.vendor.strip(),'platform':platform.name.strip(),
                                   'global_memory_bytes':int(d.global_mem_size),
                                   'max_alloc_bytes':int(d.max_mem_alloc_size)})
        except cl.Error:
            pass
        return result

    result = enumerate_devs()
    if not result and any(x['vendor']=='AMD' for x in _pci_display()) and 'RUSTICL_ENABLE' not in os.environ:
        # Only affects this process, not user's global system settings.
        os.environ['RUSTICL_ENABLE']='radeonsi'
        result=enumerate_devs()
    return result


def diagnosis(include_gpu=True):
    if not include_gpu:
        return {'cpu':_cpu_info(),'ram':_meminfo(),'opencl_gpus':[],'gpu_probe':'not requested'}
    info={'cpu':_cpu_info(),'ram':_meminfo(),'pci_gpus':_pci_display(),'python':sys.executable,
          'opencl_loader':ctypes.util.find_library('OpenCL'),
          'opencl_icd_files':[p.name for p in sorted(Path('/etc/OpenCL/vendors').glob('*.icd'))],
          'pyopencl_installed':False,'opencl_gpus':[],
          'rusticl_enabled':os.environ.get('RUSTICL_ENABLE','')}
    try:
        import pyopencl as cl
        info['pyopencl_installed']=True
        info['pyopencl_version']=getattr(cl,'VERSION_TEXT','unknown')
    except ImportError as e:
        info['python_error']=str(e)
    try:
        from kolmogorov.environment import ensure_opencl_environment
        ensure_opencl_environment()
    except (ImportError, RuntimeError) as exc:
        info['environment_error'] = str(exc)
    info['opencl_gpus']=[{k:v for k,v in d.items() if k!='object'} for d in opencl_devices()]
    info['rusticl_enabled']=os.environ.get('RUSTICL_ENABLE','')
    if info.get('environment_error'):
        info['advice']=info['environment_error']
    elif not info['pyopencl_installed']:
        info['advice']='CPU works without OpenCL. Install GPU extras: python -m pip install -r requirements-gpu.txt'
    elif not info['opencl_gpus']:
        info['advice']='No GPU OpenCL runtime found. On Ubuntu AMD, inspect: clinfo -l; consider mesa-opencl-icd (with consent).'
    else:
        info['advice']='OpenCL GPU detected. Start with --ntt-self-test to validate the shared GPU multiplication engine.'
    return info


def print_diagnosis():
    print(json.dumps(diagnosis(),indent=2))


def print_resources():
    """Text-only hardware dashboard; PCI GPUs shown even without pyopencl."""
    d=diagnosis()
    print('\n  NeoCruncher | Compute resources')
    print('  CPU: '+d['cpu']['model'])
    print(f"  Logical CPU threads: {d['cpu']['logical_threads']}")
    print('  RAM total: '+_human_bytes(d['ram']['total_bytes']))
    if d['ram'].get('process_limit_bytes') is not None:print('  Process cgroup RAM ceiling: '+_human_bytes(d['ram']['process_limit_bytes']))
    print('  RAM available: '+_human_bytes(d['ram']['available_bytes']))
    print('  Swap total: '+_human_bytes(d['ram']['swap_total_bytes']))
    if d['pci_gpus']:
        for i,g in enumerate(d['pci_gpus']):
            print(f"  GPU PCI #{i}: {g['vendor']} {g['pci']} | driver: {g['driver']}")
            print('    VRAM total: '+_human_bytes(g['vram']['total_bytes']))
            print('    VRAM used: '+_human_bytes(g['vram']['used_bytes']))
            if g['vram']['total_bytes'] is None:
                print('    VRAM unavailable via sysfs (not necessarily 0).')
    else:print('  No PCI GPU reported by sysfs (can be unavailable in a container).')
    for i,g in enumerate(d['opencl_gpus']):
        print(f"  OpenCL GPU #{i}: {g['name']} ({g['platform']})")
        print('    OpenCL reported global memory: '+_human_bytes(g['global_memory_bytes']))
    print('  OpenCL Python: '+('installed' if d['pyopencl_installed'] else 'unavailable'))
    print('  OpenCL ICD loader: '+str(d['opencl_loader'] or 'not found'))
    print('  OpenCL ICD files: '+(', '.join(d['opencl_icd_files']) or 'none found'))
    print('  Advice: '+d['advice'])
    return d
