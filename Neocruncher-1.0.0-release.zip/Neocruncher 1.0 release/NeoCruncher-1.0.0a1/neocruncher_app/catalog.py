# SPDX-License-Identifier: GPL-3.0-only
"""Public catalog: a missing implementation must never be advertised as runnable."""
from dataclasses import dataclass
from typing import Callable

@dataclass(frozen=True)
class Algorithm:
    key: str
    constant: str
    title: str
    family: str
    status: str  # ready, reference, planned
    backends: tuple[str, ...]
    notes: str = ""

ALGORITHMS = (
    Algorithm('pi_chudnovsky','pi','Chudnovsky (1988)','binary splitting','ready',('cpu','opencl-ntt','hybrid-ntt'),'Certified interval via alternating next term.'),
    Algorithm('pi_ramanujan','pi','Ramanujan (1910)','binary splitting','ready',('cpu','opencl-ntt','hybrid-ntt'),'Positive series, explicit tail bound.'),
    Algorithm('pi_bellard','pi','Bellard (1997) — hex digit extraction','BBP binary digit extraction','ready',('cpu','hybrid-bellard'),'Requires --bellard-offset; emits a certified HEX block, not a decimal TXT.'),
    Algorithm('pi_machin','pi','Machin’s Formula (1706)','arctangent','ready',('cpu','opencl-ntt','hybrid-ntt'),'GPU via shared exact NTT multiplications; CPU manages the rational series.'),
    Algorithm('e_taylor','e','Taylor exp(+1)','factorial series','ready',('cpu','opencl-ntt','hybrid-ntt'),'CPU/GPU shared binary splitting with NTT offload.'),
    Algorithm('e_inverse','e','Reciprocal Taylor exp(-1)','factorial series','ready',('cpu','opencl-ntt','hybrid-ntt'),'Alternating interval for exp(-1).'),
    Algorithm('sqrt2_integer','sqrt2','Integer square root / Newton family','integer isqrt','ready',('cpu',),'Exact floor using integer square root.'),
    Algorithm('phi_integer','phi','Golden ratio via sqrt(5)','algebraic','ready',('cpu',),'Exact floor via integer square root.'),
    Algorithm('ln2_atanh','ln2','Atanh(1/3) series','hyperbolic series','ready',('cpu','opencl-ntt','hybrid-ntt'),'CPU/GPU shared binary splitting with NTT offload.'),
    Algorithm('zeta3_apery','zeta3','Apéry alternating binomial series','alternating series','ready',('cpu','opencl-ntt','hybrid-ntt'),'Prototype: slower than modern Zúñiga formulas.'),
    # New functional CPU reference calculations. These do NOT reproduce the
    # specialized paper algorithms listed as planned below.
    Algorithm('pi_gauss_legendre','pi','Gauss–Legendre (AGM)','quadratic iteration','reference',('cpu',),'mpmath reference, no rigorous enclosing interval.'),
    Algorithm('pi_borwein_quartic','pi','Borwein quartic','quartic iteration','reference',('cpu',),'mpmath reference, no rigorous enclosing interval.'),
    Algorithm('catalan_mpmath','catalan','Catalan — numerical reference','special functions','reference',('cpu',),'Not Pilehrood/Zúñiga implementation.'),
    Algorithm('gamma_mpmath','gamma','Euler–Mascheroni — numerical reference','special functions','reference',('cpu',),'Not Brent–McMillan.'),
    Algorithm('ln10_mpmath','ln10','ln(10) — numerical reference','logarithms','reference',('cpu',)),
    Algorithm('zeta5_mpmath','zeta5','Zeta(5) — numerical reference','special functions','reference',('cpu',)),
    Algorithm('lemniscate_mpmath','lemniscate','Lemniscate constant — numerical reference','special functions','reference',('cpu',)),
    Algorithm('gamma_quarter_mpmath','gamma_quarter','Gamma(1/4) — numerical reference','special functions','reference',('cpu',)),
    Algorithm('gamma_third_mpmath','gamma_third','Gamma(1/3) — numerical reference','special functions','reference',('cpu',)),
    Algorithm('gamma_fifth_mpmath','gamma_fifth','Gamma(1/5) — numerical reference','special functions','reference',('cpu',)),
    Algorithm('ln2_zuniga2024ii','ln2','Zúñiga (2024-II)','binary splitting','planned',(),'Official y-cruncher default formula; not implemented.'),
    Algorithm('ln2_zuniga2024i','ln2','Zúñiga (2024-I)','binary splitting','planned',(),'Alternative formula.'),
    Algorithm('zeta3_zuniga2023vi','zeta3','Zúñiga (2023-VI)','binary splitting','planned',(),'Official alternative to Apéry series.'),
    Algorithm('zeta3_zuniga2023v','zeta3','Zúñiga (2023-V)','binary splitting','planned',()),
    Algorithm('catalan_pilehrood_short','catalan','Pilehrood (2010, short)','binary splitting','planned',()),
    Algorithm('catalan_zuniga2023','catalan','Zúñiga (2023)','binary splitting','planned',()),
    Algorithm('lemniscate_zuniga2023x','lemniscate','Zúñiga (2023-X)','binary splitting','planned',()),
    Algorithm('lemniscate_guillera','lemniscate','Guillera','binary splitting','planned',()),
    Algorithm('euler_gamma_brent_refined','gamma','Brent–McMillan refined','special series','planned',()),
    Algorithm('euler_gamma_brent_original','gamma','Brent–McMillan original','special series','planned',()),
    Algorithm('gamma_quarter_brown','gamma_quarter','Gamma(1/4) Brown','special series','planned',()),
    Algorithm('gamma_third_brown','gamma_third','Gamma(1/3) Brown','special series','planned',()),
    Algorithm('gamma_fifth_vidunas','gamma_fifth','Gamma(1/5) Vidunas–Lamprecht','special series','planned',()),
    Algorithm('ln10_machin','ln10','ln(10) Machin-like','logarithms','planned',()),
    Algorithm('zeta5_broadhurst','zeta5','Zeta(5) Broadhurst','binary splitting','planned',()),
)

from dataclasses import replace
PURE_KEYS={'pi_chudnovsky','e_taylor','sqrt2_integer','phi_integer'}
ALGORITHMS=tuple(replace(a,backends=tuple(b for b in a.backends if b!='opencl-ntt')+
                        (('opencl-ntt',) if a.key in PURE_KEYS else ()))
                 for a in ALGORITHMS if a.status!='planned')
INDEX={a.key:a for a in ALGORITHMS}
DEFAULT={'pi':'pi_chudnovsky','e':'e_taylor','sqrt2':'sqrt2_integer','phi':'phi_integer','ln2':'ln2_atanh','zeta3':'zeta3_apery','catalan':'catalan_mpmath','gamma':'gamma_mpmath','ln10':'ln10_mpmath','zeta5':'zeta5_mpmath','lemniscate':'lemniscate_mpmath','gamma_quarter':'gamma_quarter_mpmath','gamma_third':'gamma_third_mpmath','gamma_fifth':'gamma_fifth_mpmath'}

def select_algorithm(constant: str, algorithm: str|None=None):
    key=algorithm or DEFAULT.get(constant)
    if key not in INDEX: raise ValueError(f'Unknown algorithm {key!r}; see --list-algorithms.')
    spec=INDEX[key]
    if spec.constant != constant: raise ValueError(f'Algorithm {key} does not compute {constant}.')
    if spec.status=='planned': raise NotImplementedError(f'{key} is in the roadmap, not implemented.')
    return spec
