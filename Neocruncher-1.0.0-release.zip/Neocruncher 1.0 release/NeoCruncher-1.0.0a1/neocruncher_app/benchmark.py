# SPDX-License-Identifier: GPL-3.0-only
"""Reproducible local performance measurement (no TXT during timed trials)."""
from __future__ import annotations
import hashlib
import json
import statistics
import time
from pathlib import Path
from .core import compute
from .hardware import diagnosis


def run_benchmark(constant:str, algorithm:str, digits:int=1000, *,backend:str='cpu',workers:int=1,
                  repetitions:int=3, warmup:int=0,device:int=0,engine:str='native',vram_mib=0,ram_mib=0,gpu_batch_size=1024,hybrid_policy="fixed",calibration_file=None,cpu_library="legacy",pykolm_reduce=True,hybrid_chunk_terms=0):
    if not 1<=repetitions<=20 or not 0<=warmup<=5:
        raise ValueError('Benchmarks accept repetitions 1..20 and warmup 0..5.')
    if type(digits) is not int or digits<1:
        raise ValueError('Precision must be a positive integer.')
    # Bellard is a separate hex extractor; this measures decimal algorithms only.
    if algorithm=='pi_bellard':
        raise ValueError('Bellard uses --bellard-offset, not decimal-digit benchmarks.')
    digests=[]; times=[]
    from .progress import emitter
    notify=emitter(console=False)
    for index in range(warmup+repetitions):
        notify({'stage':f'Benchmark trial {index+1}/{warmup+repetitions}'})
        text,report=compute(constant,digits,algorithm,backend,workers=workers,device=device,engine=engine,vram_mib=vram_mib,ram_mib=ram_mib,gpu_batch_size=gpu_batch_size,hybrid_policy=hybrid_policy,calibration_file=calibration_file,cpu_library=cpu_library,pykolm_reduce=pykolm_reduce,hybrid_chunk_terms=hybrid_chunk_terms)
        digest=hashlib.sha256(text.encode('ascii')).hexdigest()
        if digests and digests[0]!=digest:
            raise ArithmeticError('Benchmark produced inconsistent output between runs!')
        digests.append(digest)
        if index>=warmup:times.append(report['seconds'])
    return {'program':'NeoCruncher','test':'calculation benchmark',
            'cpu_library':cpu_library,'version':report['version'],'constant':constant,'algorithm':algorithm,
            'backend':backend,'engine_id':engine,'cpu_workers':workers if backend=='cpu' else None,
            'decimal_places':digits,'repetitions':repetitions,'warmup':warmup,
            'samples_seconds':times,'min_seconds':min(times),
            'median_seconds':statistics.median(times),'mean_seconds':statistics.mean(times),
            'sha256_no_newline':digests[0],
            'timing_note':'wall-clock calculation time from compute(); excludes GUI and TXT disk writes. Not tamper-proof.',
            'hardware':diagnosis(include_gpu=backend!='cpu')}


def save_benchmark(path,report):
    p=Path(path)
    if p.suffix.lower()!='.json':raise ValueError('Benchmark output must end in .json')
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('x',encoding='utf-8') as f:
        json.dump(report,f,indent=2,ensure_ascii=False)
        f.write('\n')
    return p


def run_bellard_benchmark(offset:int,hex_digits:int=4,*,backend:str='cpu',
                          repetitions:int=3,warmup:int=0,device:int=0,vram_mib:float=0.0):
    """Benchmark a Bellard HEX extractor, not a decimal-digit calculation.

    Measures extraction only; never claims GPU speedup until run on real hardware.
    """
    from .algorithms.bellard import extract
    if not 1<=repetitions<=20 or not 0<=warmup<=5:
        raise ValueError('Benchmarks accept repetitions 1..20 and warmup 0..5.')
    digests=[];times=[]
    from .progress import emitter
    notify=emitter(console=False)
    for index in range(warmup+repetitions):
        notify({'stage':f'Benchmark trial {index+1}/{warmup+repetitions}'})
        start=time.perf_counter()
        result=extract(offset,hex_digits,backend,device,vram_mib)
        delta=time.perf_counter()-start
        digest=hashlib.sha256(result.hex_block.encode('ascii')).hexdigest()
        if digests and digest!=digests[0]:
            raise ArithmeticError('Bellard output differed between benchmark trials')
        digests.append(digest)
        if index>=warmup:times.append(delta)
    from .core import APP_VERSION
    return {'program':'NeoCruncher','test':'Bellard hexadecimal extraction benchmark',
            'version':APP_VERSION,'constant':'pi','algorithm':'pi_bellard',
            'backend':backend,'binary_offset':offset,'hex_digits':hex_digits,
            'cpu_workers':1 if backend=='cpu' else None,'repetitions':repetitions,
            'warmup':warmup,'samples_seconds':times,'min_seconds':min(times),
            'median_seconds':statistics.median(times),'mean_seconds':statistics.mean(times),
            'sha256_no_newline':digests[0],
            'verified_block':result.hex_block,
            'timing_note':'elapsed Bellard extraction only; includes OpenCL startup/compiler per repetition. Not tamper-proof.',
            'hardware':diagnosis(include_gpu=backend!='cpu')}


def run_custom_benchmark(expression:str,digits:int,*,repetitions:int=3,warmup:int=0):
    """Benchmark the expression evaluator (including its two guard passes)."""
    from .custom import compute_custom
    if not 1<=repetitions<=20 or not 0<=warmup<=5:
        raise ValueError('Benchmarks accept repetitions 1..20 and warmup 0..5.')
    digests=[];samples=[]
    from .progress import emitter
    notify=emitter(console=False)
    for idx in range(repetitions+warmup):
        notify({'stage':f'Custom benchmark trial {idx+1}/{repetitions+warmup}'})
        text,report=compute_custom(expression,digits)
        digest=hashlib.sha256(text.encode('ascii')).hexdigest()
        if digests and digest != digests[0]:
            raise ArithmeticError('Custom benchmark produced inconsistent results')
        digests.append(digest)
        if idx>=warmup:samples.append(report['seconds'])
    return {'program':'NeoCruncher','version':report['version'],
            'test':'uncertified custom expression benchmark','expression':expression,
            'decimal_places':digits,'backend':'cpu','cpu_workers':1,
            'repetitions':repetitions,'warmup':warmup,'samples_seconds':samples,
            'min_seconds':min(samples),'median_seconds':statistics.median(samples),
            'mean_seconds':statistics.mean(samples),
            'sha256_no_newline':digests[0],
            'certification':'NOT CERTIFIED',
            'timing_note':'Each timed trial includes both mpmath guard-precision runs; excludes TXT disk writes.'}
