# SPDX-License-Identifier: GPL-3.0-only
"""Best-effort Linux live process-tree samples; unavailable values stay null.

Summed RSS double-counts shared pages. Summed PSS apportions shared pages but
is not an atomic snapshot. Neither is a kernel-enforced memory reservation.
"""
import os,time
from pathlib import Path


def process_tree_sample(root_pid, *, proc_root='/proc'):
    started=time.perf_counter();base=Path(proc_root);records={}
    if proc_root=='/proc':
        try:
            if int((base/'self/stat').read_text().split()[0])!=os.getpid():
                return dict(available=False,rss_bytes=None,pss_bytes=None,reason='procfs PID namespace differs from caller')
        except (OSError,ValueError):return dict(available=False,rss_bytes=None,pss_bytes=None)
    try:
        pages=os.sysconf('SC_PAGE_SIZE');ticks=os.sysconf('SC_CLK_TCK')
        for p in base.iterdir():
            if not p.name.isdecimal():continue
            try:
                fields=(p/'stat').read_text().rsplit(')',1)[1].split()
                records[int(p.name)]=(int(fields[1]),int(fields[21])*pages,
                                       (int(fields[11])+int(fields[12]))/ticks)
            except (OSError,ValueError,IndexError):continue
    except (OSError,ValueError):return dict(available=False,rss_bytes=None,pss_bytes=None)
    selected={int(root_pid)};changed=True
    while changed:
        added={pid for pid,(parent,_,_) in records.items() if parent in selected}-selected
        changed=bool(added);selected.update(added)
    selected.intersection_update(records)
    if not selected:return dict(available=False,rss_bytes=None,pss_bytes=None)
    pss=0;pss_complete=True;io={'read_bytes':0,'write_bytes':0};io_complete=True
    for pid in selected:
        try:
            lines=(base/str(pid)/'smaps_rollup').read_text().splitlines()
            pss+=next(int(line.split()[1])*1024 for line in lines if line.startswith('Pss:'))
        except (OSError,ValueError,StopIteration):pss_complete=False
        try:
            values=dict(line.split(': ',1) for line in (base/str(pid)/'io').read_text().splitlines())
            for key in io:io[key]+=int(values[key])
        except (OSError,ValueError,KeyError):io_complete=False
    return dict(available=True,processes=len(selected),rss_bytes=sum(records[p][1] for p in selected),
        pss_bytes=pss if pss_complete else None,
        live_process_cpu_seconds=sum(records[p][2] for p in selected),
        live_process_io_bytes=io if io_complete else None,
        sample_cost_seconds=time.perf_counter()-started,
        scope='live descendants including root; RSS shares counted repeatedly; PSS preferred; exited workers excluded')
