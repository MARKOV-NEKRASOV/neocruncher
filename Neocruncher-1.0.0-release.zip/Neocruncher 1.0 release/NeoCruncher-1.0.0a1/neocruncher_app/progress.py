# SPDX-License-Identifier: GPL-3.0-only
"""Phase events and a renderer independent of numerical execution."""
import json, os, sys, time, shutil

def emitter(path=None, console=True):
    paths=list(dict.fromkeys(str(p) for p in (path or os.environ.get('NEO_PUBLIC_EVENTS'),os.environ.get('NEO_JOB_EVENTS')) if p))
    renderer=ProgressRenderer() if console and not os.environ.get('NEO_JOB_EVENTS') else None
    def send(data):
        event={'event':'progress','monotonic':time.monotonic(),**data}
        for target in paths:
            with open(target,'a',encoding='utf8') as f:f.write(json.dumps(event)+'\n')
        if renderer:renderer.update(event);renderer.tick(force=True)
    return send

class ProgressRenderer:
    def __init__(self, stream=None):
        self.stream=stream or sys.stderr
        self.started=time.monotonic();self.last=0;self.frame=0;self.width=0
        self.event={'stage':'Preparing job'};self.last_stage=None
    def update(self,event):self.event=event
    def clear(self):
        if self.width and self.stream.isatty():
            self.stream.write('\r'+' '*self.width+'\r');self.stream.flush();self.width=0
    def tick(self,force=False,terminal=None):
        now=time.monotonic();stage=self.event.get('stage','Computing')
        tty=self.stream.isatty()
        if not force and now-self.last<(0.15 if tty else 5):return
        self.last=now;self.frame+=1
        phase=self.event.get('phase_percent');total=self.event.get('work_total',0)
        if terminal:
            bar='='*20 if terminal=='Completed' else '-'*20;label=terminal
        elif phase is not None and total:
            filled=max(0,min(20,int(phase/5)));bar='='*filled+' '*(20-filled)
            label=f'{stage} | phase {phase:.1f}%'
        else:
            pos=self.frame%18;bar=' '*pos+'>>'+' '*(18-pos)
            label=stage+' | ETA unknown'
        line=f'  [{bar}] {label} | {now-self.started:.1f}s'
        if tty:
            width=max(20,shutil.get_terminal_size((80,24)).columns-1)
            line=line[:width];self.clear();self.stream.write('\r'+line);self.width=len(line)
            if terminal:self.stream.write('\n');self.width=0
        else:self.stream.write(line+'\n')
        self.stream.flush()
