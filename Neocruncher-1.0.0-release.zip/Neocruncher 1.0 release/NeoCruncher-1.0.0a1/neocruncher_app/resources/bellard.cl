/* SPDX-License-Identifier: GPL-3.0-only */
// Bellard pi formula (1997): one independent k per OpenCL work-item.
// Fractional part of 2^binary_offset*pi; exact modular arithmetic + 56-bit
// fixed-point fractions. No double precision or float sums on the GPU.
// Limited to offset <= 8,000,000; denominators squared fit in uint64.
#define MASK56 ((1UL << 56) - 1UL)
inline ulong powmod2(ulong exponent, ulong divisor) {
    if (divisor == 1UL) return 0UL;
    ulong result = 1UL, x = 2UL % divisor;
    while (exponent) {
        if (exponent & 1UL) result = (result*x) % divisor;
        x = (x*x) % divisor;
        exponent >>= 1;
    }
    return result;
}
inline ulong fraction56(ulong remainder, ulong divisor) {
    ulong step = remainder << 28;
    ulong hi = step / divisor;
    ulong rem = step % divisor;
    ulong lo = (rem << 28) / divisor;
    return (hi << 28) | lo;
}
inline ulong contribution(ulong e, ulong k, long coeff, ulong den) {
    ulong r = powmod2(e, den);
    ulong f = fraction56(r, den);
    // unsigned wraparound is well-defined; masking computes mod 2^56.
    return (((ulong)coeff)*f) & MASK56;
}
__kernel void bellard_terms(__global ulong *out, ulong start,
                            ulong offset, uint count) {
    ulong gid = get_global_id(0);
    if (gid >= count) return;
    ulong k = start + gid;
    ulong e = offset - 6UL - 10UL*k;
    ulong result = 0UL;
    result += contribution(e,k,-32L, 4UL*k+1UL);
    result += contribution(e,k,-1L,  4UL*k+3UL);
    result += contribution(e,k,256L, 10UL*k+1UL);
    result += contribution(e,k,-64L,10UL*k+3UL);
    result += contribution(e,k,-4L, 10UL*k+5UL);
    result += contribution(e,k,-4L, 10UL*k+7UL);
    result += contribution(e,k,1L,  10UL*k+9UL);
    if (k & 1UL) result = 0UL - result;
    out[gid] = result & MASK56;
}
