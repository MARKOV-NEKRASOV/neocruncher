# SPDX-License-Identifier: GPL-3.0-only
"""Versioned job boundary for CLI and future frontends.

A separate interpreter keeps the progress UI responsive during GIL-bound work.
No numerical values travel through the control channel. Output files remain
owned by the worker. CPU/GPU selection is never changed by this supervisor.
"""
import json, os, queue, signal, subprocess, sys, tempfile, threading, time
from pathlib import Path
from .progress import ProgressRenderer
API_VERSION=1

def run_job(arguments, *, on_event=None, console=True):
    args=dict(vars(arguments)) if not isinstance(arguments,dict) else dict(arguments)
    renderer=ProgressRenderer() if console else None
    started=time.perf_counter()
    from .telemetry import process_tree_sample
    from .hardware import diagnosis
    from .budgets import _auto_ram
    available=diagnosis(include_gpu=False)['ram'].get('available_bytes')
    budget=float(args.get('ram_mib',0)) or _auto_ram(available)
    peak_rss=peak_pss=None;last_sample=-1.0
    resource_failure=None
    with tempfile.TemporaryDirectory(prefix='neo-job-') as tmp:
        events=Path(tmp)/'events.jsonl';events.touch()
        env=os.environ.copy();env['NEO_JOB_EVENTS']=str(events);env['PYTHONUNBUFFERED']='1'
        if args.get('progress_file'):env['NEO_PUBLIC_EVENTS']=str(Path(args['progress_file']).absolute())
        args['progress']=True
        proc=subprocess.Popen([sys.executable,'-m','neocruncher_app.job_worker'],
             stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,
             text=True,env=env,start_new_session=os.name=='posix' and not env.get('NEO_AUDIT_GROUP'))
        proc.stdin.write(json.dumps({'api_version':API_VERSION,'arguments':args}));proc.stdin.close()
        messages=queue.Queue()
        def read_stream(stream,target):
            for line in stream:messages.put((target,line))
            stream.close()
        threads=[threading.Thread(target=read_stream,args=(proc.stdout,sys.stdout),daemon=True),
                 threading.Thread(target=read_stream,args=(proc.stderr,sys.stderr),daemon=True)]
        for t in threads:t.start()
        pending=''
        def poll(f):
            nonlocal pending
            pending+=f.read()
            while '\n' in pending:
                line,pending=pending.split('\n',1)
                if not line:continue
                event=json.loads(line)
                if renderer:renderer.update(event)
                if on_event:on_event(event)
            while not messages.empty():
                target,line=messages.get()
                if renderer:renderer.clear()
                target.write(line);target.flush()
        try:
            with events.open() as f:
                while proc.poll() is None:
                    poll(f)
                    now=time.perf_counter()
                    if now-last_sample>=.5:
                        last_sample=now
                        sample=process_tree_sample(proc.pid)
                        if sample.get('rss_bytes') is not None:peak_rss=max(peak_rss or 0,sample['rss_bytes'])
                        if sample.get('pss_bytes') is not None:peak_pss=max(peak_pss or 0,sample['pss_bytes'])
                        event=dict(event='resource_sample',elapsed_seconds=now-started,ram_budget_mib=budget,**sample)
                        if on_event:on_event(event)
                        if args.get('progress_file'):
                            with open(args['progress_file'],'a',encoding='utf8') as log:log.write(json.dumps(event)+'\n')
                        measured=sample.get('pss_bytes')
                        # RSS fallback is deliberately conservative when PSS permissions are absent.
                        if measured is None:measured=sample.get('rss_bytes')
                        if measured is not None and measured>budget*1024**2:
                            resource_failure='Sampled process-tree memory exceeded RAM budget'
                            raise MemoryError(resource_failure)
                    if renderer:renderer.tick()
                    try:proc.wait(timeout=.15)
                    except subprocess.TimeoutExpired:pass
                for t in threads:t.join()
                poll(f)
        except BaseException as exc:
            failure=dict(event='job_stopped',status='MEMORY_LIMIT' if isinstance(exc,MemoryError) else 'CANCELLED',
                         reason=str(exc),elapsed_seconds=time.perf_counter()-started,
                         peak_tree_rss_bytes_sampled=peak_rss,peak_tree_pss_bytes_sampled=peak_pss)
            if on_event:on_event(failure)
            if args.get('progress_file'):
                with open(args['progress_file'],'a',encoding='utf8') as log:log.write(json.dumps(failure)+'\n')
            if proc.poll() is None:
                if os.name=='posix' and not env.get('NEO_AUDIT_GROUP'):os.killpg(proc.pid,signal.SIGTERM)
                else:proc.terminate()
                try:proc.wait(timeout=2)
                except subprocess.TimeoutExpired:
                    if os.name=='posix' and not env.get('NEO_AUDIT_GROUP'):os.killpg(proc.pid,signal.SIGKILL)
                    else:proc.kill()
                    proc.wait()
            if renderer:renderer.tick(force=True,terminal='Cancelled')
            raise
        status='Completed' if proc.returncode==0 else 'Failed'
        final={'event':'job_finished','status':status,'returncode':proc.returncode,
               'wall_seconds':time.perf_counter()-started,'api_version':API_VERSION,
               'peak_tree_rss_bytes_sampled':peak_rss,'peak_tree_pss_bytes_sampled':peak_pss,
               'ram_budget_mib':budget}
        if on_event:on_event(final)
        if args.get('progress_file'):
            with open(args['progress_file'],'a',encoding='utf8') as f:f.write(json.dumps(final)+'\n')
        if renderer:renderer.tick(force=True,terminal=status)
        return proc.returncode
