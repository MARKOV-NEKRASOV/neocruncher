# SPDX-License-Identifier: GPL-3.0-only
"""Unbounded-count preflight: estimates only, never allocates an integer of target size."""
from __future__ import annotations
import shutil
from pathlib import Path

from .hardware import diagnosis, _human_bytes

def short(n):
    # Avoid rendering enormous counts into the terminal.
    s=str(n)
    return f'{s[:5]}… ×10^{len(s)-5}' if len(s)>35 else f'{n:,}'

def scale_probe(digits, mode='cpu',backend='cpu',hardware=None,disk=None, scratch='.',algorithm='pi_chudnovsky'):
    if type(digits) is not int or digits<1:raise ValueError('Positive integer precision required.')
    hw=diagnosis() if hardware is None else hardware
    try:free=shutil.disk_usage(Path(scratch)).free if disk is None else disk
    except (OSError,ValueError):free=None
    output=digits+3 # pi prefix + line feed (minimum; not a scratch estimate)
    terms=(digits*100+1417)//1418+4 # ~14.18 digits/term; rough
    return {'kind':'CAPACITY ESTIMATE — NOT A COMPUTATION', 'target_decimal_places':digits,
            'target_mode':mode,'backend':backend,'minimum_pi_txt_bytes':output,
            'free_disk_bytes':free,'txt_fits':free is not None and free>=output,'enough_space_for_txt_alone':free is not None and free>=output,
            'approximate_chudnovsky_terms':terms if algorithm in ('pi','pi_chudnovsky') else None,
            'ram_available_bytes':hw.get('ram',{}).get('available_bytes'),
            'ram_total_bytes':hw.get('ram',{}).get('total_bytes'),
            'swap_total_bytes':hw.get('ram',{}).get('swap_total_bytes'),
            'gpus':[{k:g.get(k) for k in ('name','vendor','global_memory_bytes')} for g in hw.get('opencl_gpus',[])],
            'cpu_engine_limit':None, 'can_execute':mode=='cpu' or backend in ('opencl-ntt','hybrid-ntt'), 'supported_now':mode=='cpu' or backend in ('opencl-ntt','hybrid-ntt'), 'gpu_pi_10b_ready':False,
            'gpu_decimal_backend_ready':backend in ('opencl-ntt','hybrid-ntt'),
            'notice':'GPU-pure supports RAM storage spill. SSD arithmetic spill is not implemented.'}

def print_scale_probe(digits,mode='cpu',backend='cpu',scratch='.',algorithm='pi_chudnovsky'):
    p=scale_probe(digits,mode,backend,scratch=scratch,algorithm=algorithm)
    print('\n  NEOCRUNCHER | CAPACITY PREFLIGHT (no digits computed)')
    from .prefs import paint
    print('  Requested decimal digits: '+paint(short(digits),'1;36'))
    approx = _human_bytes(p['minimum_pi_txt_bytes']) if len(str(digits))<280 else 'extremely large'
    print('  Minimum TXT size: '+paint(short(p['minimum_pi_txt_bytes']),'36')+' bytes ('+approx+')')
    print('  Free disk: '+_human_bytes(p['free_disk_bytes']))
    print('  RAM available: '+_human_bytes(p['ram_available_bytes'])+' | OS swap total: '+_human_bytes(p['swap_total_bytes']))
    if p['approximate_chudnovsky_terms'] is not None:print('  Approx. Chudnovsky terms: '+short(p['approximate_chudnovsky_terms']))
    else:print('  Algorithm-specific working set and term count not estimated.')
    if p['free_disk_bytes'] is not None and p['minimum_pi_txt_bytes']>p['free_disk_bytes']:
        print('  Storage assessment: INSUFFICIENT SPACE for this TXT on selected disk.')
    print('  Status: '+('No numerical cap; actual computation depends on resources, time and the backend' if p['can_execute'] else 'GPU algorithm unavailable for this selected backend'))
    print('  No result is computed by this planner. RAM, disk and time may make execution infeasible.')
    print('  GPU-pure can use RAM as a storage bank. SSD arithmetic spill is not implemented.')
    return p
