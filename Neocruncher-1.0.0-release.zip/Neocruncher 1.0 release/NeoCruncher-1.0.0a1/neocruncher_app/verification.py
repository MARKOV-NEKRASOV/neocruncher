# SPDX-License-Identifier: GPL-3.0-only
"""Bounded saved-result validation. Numerical agreement is not a formal proof."""
from __future__ import annotations
import argparse
import hashlib
import json
import re
import sys
import time
from pathlib import Path

SUPPORTED = ('pi', 'e', 'ln2', 'sqrt2', 'phi', 'zeta3')
MAX_VERIFY_DIGITS = 100_000


def reference_digits(constant, places):
    """Use a private mpmath context and two guard precisions, without engine imports."""
    import mpmath
    if constant not in SUPPORTED:
        raise ValueError('No independent numerical verifier for this constant')
    if type(places) is not int or not 1 <= places <= MAX_VERIFY_DIGITS:
        raise ValueError(f'Verifier supports 1..{MAX_VERIFY_DIGITS:,} decimal places')
    mp = mpmath.mp.clone()
    values = []
    for guard in (60, 100):
        mp.dps = places + guard
        funcs = {'pi': lambda: mp.pi, 'e': lambda: mp.exp(1),
                 'ln2': lambda: mp.log(2), 'sqrt2': lambda: mp.sqrt(2),
                 'phi': lambda: (1 + mp.sqrt(5)) / 2, 'zeta3': lambda: mp.zeta(3)}
        # Chunked conversion avoids Python's large decimal-string limit.
        n = int(mp.floor(funcs[constant]() * mp.power(10, places)))
        chunks = []
        while n:
            n, chunk = divmod(n, 10**1000)
            chunks.append(str(chunk).zfill(1000))
        s = ''.join(reversed(chunks)).lstrip('0').zfill(places + 1)
        values.append(s[:-places] + '.' + s[-places:])
    if values[0] != values[1]:
        raise ArithmeticError('Reference is unstable at the two working precisions')
    return values[1]


def verify_text(text, constant, places):
    expected = reference_digits(constant, places)
    if text != expected:
        mismatch = next((i for i, pair in enumerate(zip(text, expected)) if pair[0] != pair[1]), min(len(text), len(expected)))
        raise ArithmeticError(f'Independent numerical mismatch at character {mismatch + 1} (including decimal point)')
    return 'PASS: all requested decimal places match an independent mpmath computation'


def verify_file(path):
    start = time.perf_counter()
    path = Path(path)
    result = {'schema': 'neocruncher-verification-v1', 'file': path.name,
              'status': 'FAIL', 'integrity': 'NOT RUN', 'numerical': 'NOT RUN',
              'scope': 'SHA-256 consistency plus numerical recomputation; not a formal proof or execution authentication.'}
    try:
        sidecar = Path(str(path) + '.json')
        if sidecar.stat().st_size > 1024 * 1024:
            raise ValueError('Manifest exceeds 1 MiB validation limit')
        report = json.loads(sidecar.read_text(encoding='utf-8'))
        if not isinstance(report, dict):
            raise ValueError('Manifest must be a JSON object')
        places = report.get('decimal_places')
        if type(places) is not int or not 1 <= places <= MAX_VERIFY_DIGITS:
            raise ValueError('Only decimal results with 1..100,000 places are supported; HEX blocks are not supported')
        if report.get('constant') not in SUPPORTED:
            raise ValueError('Unsupported constant: numerical verification was not performed')
        if path.stat().st_size != places + 3:
            raise ValueError('TXT length differs from declared decimal precision')
        raw = path.read_bytes()
        digest = hashlib.sha256(raw).hexdigest()
        result['sha256'] = digest
        if digest != report.get('sha256'):
            result['integrity'] = 'FAIL'
            raise ValueError('TXT SHA-256 differs from the manifest')
        text = raw.decode('ascii')
        if not re.fullmatch(r'[0-9]\.[0-9]{' + str(places) + r'}\n', text):
            raise ValueError('Malformed decimal TXT (expected ASCII and LF terminator)')
        result.update(integrity='PASS', constant=report['constant'], decimal_places=places)
        result['numerical'] = 'FAIL'
        verify_text(text[:-1], report['constant'], places)
        result.update(status='PASS', numerical='PASS', message='Every decimal place matches at two reference precisions')
    except (OSError, ValueError, ArithmeticError, UnicodeError, ImportError) as exc:
        result['message'] = str(exc)
    result['seconds'] = time.perf_counter() - start
    return result


def main(argv=None):
    import os
    if argv is None:argv=sys.argv[1:]
    if argv and not any(x in argv for x in ('--help','-h')) and not os.environ.get('KOLMOGOROV_CONSOLE_WORKER'):
        from kolmogorov.compute.console import supervise
        return supervise(argv,module='neocruncher_app.verification',label='Verifying TXT')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('digits_file')
    parser.add_argument('--report', help='Save verification JSON (exclusive creation)')
    args = parser.parse_args(argv)
    result = verify_file(args.digits_file)
    print(json.dumps(result, indent=2, ensure_ascii=False))
    if args.report:
        try:
            with open(args.report, 'x', encoding='utf-8') as f:
                json.dump(result, f, indent=2, ensure_ascii=False)
                f.write('\n')
        except OSError as exc:
            print(f'Cannot save verification report: {exc}', file=sys.stderr)
            return 2
    return 0 if result['status'] == 'PASS' else 1


if __name__ == '__main__':
    sys.exit(main())
