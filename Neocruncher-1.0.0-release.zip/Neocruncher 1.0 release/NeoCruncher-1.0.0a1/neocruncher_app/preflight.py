# SPDX-License-Identifier: GPL-3.0-only
"""Snapshot of resources before a job. These estimates are NOT rigorous bounds."""
from __future__ import annotations
import shutil
from pathlib import Path
from .budgets import estimate_ram_mib,memory_plan
from .hardware import diagnosis,_human_bytes

def preflight(*,digits,algorithm,backend,workers,ram_budget,vram_budget,output,scratch='.',disk_budget_gib=0,device=0):
    h=diagnosis(include_gpu=backend!='cpu')
    dest=Path(output).absolute().parent
    scratch_path=Path(scratch)
    while not dest.exists() and dest!=dest.parent:dest=dest.parent
    if not dest.is_dir():raise ValueError('Output parent is not a directory')
    # A checkpoint directory may be created when computing; inspect its existing parent.
    source=scratch_path
    while not scratch_path.exists() and scratch_path!=scratch_path.parent:scratch_path=scratch_path.parent
    if not scratch_path.is_dir():raise ValueError(f'Scratch parent is not a directory: {scratch_path}')
    disk=shutil.disk_usage(dest).free
    scratch_free=shutil.disk_usage(scratch_path).free
    output_size=digits+3+65536  # decimal TXT plus reserved report space
    import math
    if not isinstance(disk_budget_gib,(int,float)) or not math.isfinite(disk_budget_gib) or disk_budget_gib<0:
        raise ValueError('Disk limit must be finite and nonnegative; 0=automatic')
    # Reserve part of the filesystem for the OS and applications.
    reserve=min(disk//2,max(256*1024**2,disk//10))
    auto_disk=max(0,disk-reserve)
    disk_allowance=min(disk,int(disk_budget_gib*1024**3)) if disk_budget_gib else auto_disk
    gpu=h.get('opencl_gpus',[])
    vram=None
    if backend!='cpu' and 0<=device<len(gpu):vram=gpu[device].get('global_memory_bytes')
    ram_estimate=estimate_ram_mib(digits,algorithm,workers)
    return {'backend':backend,'ram_estimate_scope':'CPU heuristic; not resident GPU peak',
            'ram_available_bytes':h['ram'].get('available_bytes'),
            'ram_total_bytes':h['ram'].get('total_bytes'),
            'os_swap_bytes':h['ram'].get('swap_total_bytes'),
            'memory_plan':memory_plan(digits,algorithm,workers),
            'ram_estimate_mib':ram_estimate,'ram_budget_mib':ram_budget,
            'vram_capacity_bytes':vram,'vram_available_or_total_bytes':vram,'vram_budget_mib':vram_budget,
            'output_free_bytes':disk,'scratch_free_bytes':scratch_free,
            'expected_output_bytes_approx':output_size,
            'output_space_ok':output_size<=disk_allowance,
            'disk_usable_budget_bytes':disk_allowance,
            'disk_budget_mode':'custom' if disk_budget_gib else 'auto',
            'scratch_directory':str(source),
            'scratch_shares_output_volume':dest.stat().st_dev==scratch_path.stat().st_dev,
            'warning':'These are estimates, not guaranteed peak memory bounds; no out-of-core integer engine.'}

def resource_table(snapshot, *, colors=None):
    """Terminal table: figures are padded BEFORE ANSI styling to keep columns aligned.

    Only measurements/estimates actually available are displayed. 'Unknown' for
    VRAM and scratch requirements is intentional: RAM estimates are not GPU plans.
    """
    from .prefs import paint
    cols = (14, 29, 28)

    def cell(value, width, style=None):
        padded = str(value).rjust(width) if style else str(value).ljust(width)
        return paint(padded, style, enabled=colors) if style else padded

    def row(name, available, required):
        return ('  '+cell(name, cols[0])+'  '
                +cell(available, cols[1], '36')+'  '
                +cell(required, cols[2], '33'))

    headers = '  '+f'{"RESOURCE":<{cols[0]}}  {"AVAILABLE":>{cols[1]}}  {"REQUIRED (est.)":>{cols[2]}}'
    lines=[headers, '  '+'-'*(sum(cols)+4)]
    lines.append(row('RAM total',_human_bytes(snapshot.get('ram_total_bytes')),'Physical / process capacity'))
    lines.append(row('RAM budget',_human_bytes(snapshot.get('ram_budget_mib',0)*1024**2),'Sampled process-tree guard'))
    lines.append(row('RAM available',_human_bytes(snapshot['ram_available_bytes']),
                     ('Not estimated (GPU route)' if snapshot.get('backend')=='opencl-ntt' else _human_bytes(snapshot['ram_estimate_mib']*1024**2))))
    if snapshot.get('backend')!='cpu':lines.append(row('VRAM total',_human_bytes(snapshot['vram_capacity_bytes']),
                     'Not estimated'))
    lines.append(row('Disk',_human_bytes(snapshot['output_free_bytes']),
                     '~'+_human_bytes(snapshot['expected_output_bytes_approx'])))
    if not snapshot['scratch_shares_output_volume']:lines.append(row('Scratch',_human_bytes(snapshot['scratch_free_bytes']),
                     'Not estimated'))
    return '\n'.join(lines)


def print_preflight(**kwargs):
    s=preflight(**kwargs)
    from .prefs import paint
    print(paint('\n  ─── PRE-COMPUTATION RESOURCE ESTIMATE ───', '1;36'))
    print(resource_table(s))
    print('\n  Planning range is advisory; sampled RAM enforcement can miss short peaks.')
    if s['ram_estimate_mib']>s['ram_budget_mib']:
        print('  WARNING: uncalibrated working-set estimate exceeds RAM budget; execution may stop.')
    if kwargs['backend']!='cpu':print('  GPU memory is total capacity; free VRAM is not measured.')
    print('  Disk estimate: TXT and report allowance. Temporary-file demand is not estimated.')
    if s['scratch_shares_output_volume']:
        print('  Output and temporary storage share the same free disk space.')
    print('  Temporary directory: '+s['scratch_directory'])
    print()
    if not s['output_space_ok']:
        raise ValueError('Insufficient free disk space for the requested output and report.')
    return s
