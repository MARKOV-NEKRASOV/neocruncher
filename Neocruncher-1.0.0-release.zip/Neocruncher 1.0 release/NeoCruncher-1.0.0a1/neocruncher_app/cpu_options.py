# SPDX-License-Identifier: GPL-3.0-only
"""User-facing CPU process choice, based on affinity rather than a magic 32."""
import os


def available_processes():
    try:return max(1,len(os.sched_getaffinity(0)))
    except (AttributeError,OSError):return max(1,os.cpu_count() or 1)


def topology():
    from pathlib import Path
    try:logical=sorted(os.sched_getaffinity(0))
    except (AttributeError,OSError):logical=list(range(os.cpu_count() or 1))
    cores=set()
    try:
        for cpu in logical:
            base=Path(f'/sys/devices/system/cpu/cpu{cpu}/topology')
            cores.add(((base/'physical_package_id').read_text().strip(),(base/'core_id').read_text().strip()))
        physical=len(cores)
    except OSError:physical=None
    return dict(logical_threads=len(logical),physical_cores=physical)

def select_workers(ask, *, show=print):
    total=available_processes()
    show(f'  [1] All available ({total})  [2] One process  [3] Custom')
    choice=str(ask('CPU allocation','1')).strip()
    if choice=='1':return total
    if choice=='2':return 1
    if choice=='3':return ask('Worker processes',str(total),low=1,high=total)
    raise ValueError('Choose 1, 2 or 3.')
