# SPDX-License-Identifier: GPL-3.0-only
"""Isolated, reproducible OpenCL integer-arithmetic stress suite.

Every tested multiplication is performed by the OpenCL backend. Python
computes only independent validation products (never a fallback result).
Each case runs as a separate process with a hard timeout, and the parent
persists failures so a stalled NTT cannot discard prior measurements.
This is NOT a full GPU-only algorithm for mathematical constants.
"""
from __future__ import annotations
import argparse
import csv
import hashlib
import json
import os
import platform
import random
import signal
import subprocess
import sys
import time
import traceback
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path

@dataclass(frozen=True)
class Case:
    key: str
    kind: str  # scalar, batch, boundary
    bits: int
    count: int
    repetitions: int
    seed: int


def profiles():
    return {
        'quick': [
            Case('tiny_signed', 'batch', 32, 257, 2, 1001),
            Case('batch_1024', 'batch', 128, 1024, 3, 1002),
            Case('schoolbook_edge', 'batch', 2048, 128, 2, 1003),
            Case('ntt_32k', 'scalar', 32768, 1, 3, 1004),
            Case('ntt_128k', 'scalar', 131072, 1, 2, 1005),
        ],
        'full': [
            Case('tiny_signed', 'batch', 32, 257, 2, 1001),
            Case('batch_1024', 'batch', 128, 1024, 8, 1002),
            Case('batch_1024_512bits', 'batch', 512, 1024, 6, 1006),
            Case('schoolbook_edge', 'batch', 2048, 128, 4, 1003),
            Case('transition_2049bits', 'scalar', 2049, 1, 4, 1007),
            Case('ntt_32k', 'scalar', 32768, 1, 6, 1004),
            Case('ntt_128k', 'scalar', 131072, 1, 5, 1005),
            Case('ntt_1m', 'scalar', 1048576, 1, 3, 1008),
            Case('ntt_2m', 'scalar', 2097152, 1, 2, 1009),
        ],
        'extreme': [
            Case('tiny_signed', 'batch', 32, 257, 2, 1001),
            Case('batch_1024', 'batch', 128, 1024, 14, 1002),
            Case('batch_1024_512bits', 'batch', 512, 1024, 12, 1006),
            Case('schoolbook_edge', 'batch', 2048, 128, 8, 1003),
            Case('transition_2049bits', 'scalar', 2049, 1, 8, 1007),
            Case('ntt_32k', 'scalar', 32768, 1, 10, 1004),
            Case('ntt_128k', 'scalar', 131072, 1, 8, 1005),
            Case('ntt_1m', 'scalar', 1048576, 1, 5, 1008),
            Case('ntt_2m', 'scalar', 2097152, 1, 4, 1009),
            Case('ntt_4m', 'scalar', 4194304, 1, 2, 1010),
            Case('ntt_8m', 'scalar', 8388608, 1, 2, 1011),
        ],
    }


def _make_pairs(c):
    r=random.Random(c.seed)
    pairs=[]
    for i in range(c.count):
        a=r.getrandbits(c.bits) | (1 << (c.bits-1))
        b=r.getrandbits(c.bits) | (1 << (c.bits-1))
        if i % 11 == 0:a=-a
        if i % 17 == 0:b=-b
        if c.kind=='batch' and i%173==1:a=0
        pairs.append((a,b))
    return pairs


def _gpu_snapshot():
    from .telemetry import amd_gpus
    return [asdict(s) for s in amd_gpus()]


def _case_child(c,device,output):
    from .arithmetic.ntt import OpenCLMultiplier
    start=time.perf_counter()
    engine=OpenCLMultiplier(device)
    setup=time.perf_counter()-start
    pairs=_make_pairs(c)
    samples=[]
    before=_gpu_snapshot()
    reference_hash=hashlib.sha256()
    for i in range(c.repetitions):
        started=time.perf_counter()
        values=(engine.multiply_many(pairs) if c.kind=='batch' else
                [engine.multiply(pairs[0][0],pairs[0][1])])
        elapsed=time.perf_counter()-started
        if len(values)!=len(pairs):raise ArithmeticError('GPU changed the number of products')
        # Host is strictly a verifier, not the multiplication compute backend.
        verification_started=time.perf_counter()
        for (a,b),value in zip(pairs,values):
            if value!=a*b:raise ArithmeticError(f'GPU mismatch in {c.key}, repetition {i}')
            encoded=value.to_bytes(max(1,(abs(value).bit_length()+8)//8),'little',signed=True)
            reference_hash.update(len(encoded).to_bytes(8,'little'))
            reference_hash.update(encoded)
        verify_seconds=time.perf_counter()-verification_started
        samples.append({'iteration':i+1,'gpu_wall_seconds':elapsed,
                        'cpu_reference_verification_seconds':verify_seconds})
        print(f'  {c.key}: repetition {i+1}/{c.repetitions} GPU {elapsed:.4f}s EXACT PASS',flush=True)
    report={
        'schema':'neocruncher-gpu-stress-case-v1','status':'PASS','case':asdict(c),
        'device':str(engine.device.name),'driver_version':str(engine.device.driver_version),
        'opencl_version':str(engine.device.version),
        'setup_context_and_compile_seconds':setup,
        'timings':samples,'gpu_before':before,'gpu_after':_gpu_snapshot(),
        'counters':{'gpu_calls':engine.calls,'schoolbook_calls':engine.schoolbook_calls,
                    'ntt_calls':engine.ntt_calls,'batch_dispatches':engine.batch_dispatches,
                    'batched_products':engine.batched_products,'root_cache_hits':engine.root_cache_hits,
                    'root_cache_misses':engine.root_cache_misses,'max_transform_n':engine.max_transform_n,
                    'bytes_uploaded':engine.bytes_uploaded,'bytes_downloaded':engine.bytes_downloaded},
        'result_sha256':reference_hash.hexdigest(),
        'meaning':'OpenCL exact integer multiplication, Python independently verifies every product; not full GPU-only Pi.',
    }
    dest=Path(output);dest.parent.mkdir(parents=True,exist_ok=True)
    tmp=dest.with_suffix('.partial')
    tmp.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    tmp.replace(dest)
    return 0


def _append_csv(path,records):
    columns=('case','status','bits','count','repetitions','context_seconds','first_gpu_seconds',
             'warm_gpu_seconds','ntt_calls','schoolbook_calls','batch_dispatches',
             'upload_bytes','download_bytes','failure')
    with open(path,'w',newline='',encoding='utf-8') as fp:
        writer=csv.DictWriter(fp,fieldnames=columns);writer.writeheader()
        for row in records:
            c=row['case'];detail=row.get('detail') or {};times=detail.get('timings') or []
            gpu=detail.get('counters') or {}
            writer.writerow({'case':c['key'],'status':row['status'],'bits':c['bits'],
                             'count':c['count'],'repetitions':c['repetitions'],
                             'context_seconds':detail.get('setup_context_and_compile_seconds'),
                             'first_gpu_seconds':times[0]['gpu_wall_seconds'] if times else '',
                             'warm_gpu_seconds':times[-1]['gpu_wall_seconds'] if times else '',
                             'ntt_calls':gpu.get('ntt_calls'),
                             'schoolbook_calls':gpu.get('schoolbook_calls'),
                             'batch_dispatches':gpu.get('batch_dispatches'),
                             'upload_bytes':gpu.get('bytes_uploaded'),
                             'download_bytes':gpu.get('bytes_downloaded'),
                             'failure':row.get('failure','')})


def _write_report(dest,manifest):
    dest.mkdir(parents=True,exist_ok=True)
    tmp=dest/'report.partial'
    tmp.write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
    tmp.replace(dest/'report.json')
    _append_csv(dest/'results.csv',manifest['records'])


def orchestrate(args):
    cases=profiles()[args.profile]
    print(f'GPU stress suite {args.profile} | {len(cases)} isolated cases',flush=True)
    if args.dry_run:
        for c in cases:print(f'{c.key:24s} {c.bits:>9,d} bits x {c.count} operands, {c.repetitions} reps')
        return 0
    dest=Path(args.output).expanduser().resolve()
    if (dest/'report.json').exists():
        raise FileExistsError('Report directory already contains report.json; choose a new --output directory')
    dest.mkdir(parents=True,exist_ok=True)
    clfile=Path(__file__).resolve().parent/'resources'/'ntt.cl'
    manifest={
        'schema':'neocruncher-gpu-stress-suite-v1','profile':args.profile,
        'started_utc':datetime.now(timezone.utc).isoformat(),
        'machine':{'python':sys.version.split()[0],'system':platform.platform(),
                   'processor':platform.processor()},'kernel_sha256':hashlib.sha256(clfile.read_bytes()).hexdigest(),
        'device_index':args.device,'per_case_timeout_seconds':args.case_timeout,
        'maximum_total_seconds':args.max_wall_seconds,
        'scope':'Multiplication primitive OpenCL GPU, CPU only for reference verification. '
                'Not GPU-only Pi, not 1B readiness, not formal proof.',
        'records':[]}
    initial=time.monotonic()
    for c in cases:
        if time.monotonic()-initial>=args.max_wall_seconds:
            print('Overall time budget exhausted; stopping suite.',flush=True)
            break
        remaining=args.max_wall_seconds-(time.monotonic()-initial)
        budget=max(0.1,min(args.case_timeout,remaining))
        out=dest/(c.key+'.json'); logfile=dest/(c.key+'.log')
        cmd=[sys.executable,'-u','-m','neocruncher_app.gpu_stress','--_child-case',c.key,
             '--profile',args.profile,'--device',str(args.device),'--output',str(out)]
        env=os.environ.copy()
        for k in ('LD_LIBRARY_PATH','LD_PRELOAD','PYTHONPATH','PYTHONHOME'):env.pop(k,None)
        env.setdefault('RUSTICL_ENABLE','radeonsi')
        t0=time.perf_counter();status='ERROR';failure=''
        print(f'[{len(manifest["records"])+1}/{len(cases)}] {c.key}  bits={c.bits:,} ...',flush=True)
        with open(logfile,'w',encoding='utf-8') as log:
            proc=subprocess.Popen(cmd,cwd=Path(__file__).resolve().parent.parent,
                                  stdout=log,stderr=subprocess.STDOUT,env=env,start_new_session=(os.name=='posix'))
            try:
                return_code=proc.wait(timeout=budget)
                status='PASS' if return_code==0 and out.exists() else 'FAIL'
                if status!='PASS':failure=f'Worker exited {return_code}; inspect {logfile.name}'
            except subprocess.TimeoutExpired:
                status='TIMEOUT';failure=f'Exceeded {budget:.1f}s; worker terminated'
                if os.name=='posix':os.killpg(proc.pid,signal.SIGKILL)
                else:proc.kill()
                proc.wait()
            except KeyboardInterrupt:
                if os.name=='posix':os.killpg(proc.pid,signal.SIGKILL)
                else:proc.kill()
                proc.wait()
                status='CANCELLED';failure='Interrupted by user'
        try:detail=json.loads(out.read_text()) if status=='PASS' else None
        except (OSError,ValueError):detail=None;status='FAIL';failure='Missing or unreadable case JSON'
        manifest['records'].append({'case':asdict(c),'status':status,
                                    'elapsed_seconds':time.perf_counter()-t0,
                                    'detail':detail,'failure':failure,'log_file':logfile.name})
        _write_report(dest,manifest)
        print(' ',status, f'{time.perf_counter()-t0:.2f}s',failure,flush=True)
        if status=='CANCELLED':break
    manifest['ended_utc']=datetime.now(timezone.utc).isoformat()
    manifest['complete']=len(manifest['records'])==len(cases)
    manifest['pass_count']=sum(r['status']=='PASS' for r in manifest['records'])
    manifest['failure_count']=len(manifest['records'])-manifest['pass_count']
    _write_report(dest,manifest)
    print('Report:',dest/'report.json','| CSV:',dest/'results.csv',flush=True)
    return 0 if manifest['complete'] and manifest['failure_count']==0 else 1


def main(argv=None):
    parser=argparse.ArgumentParser(description='Isolated, measured OpenCL GPU multiplication stress suite')
    parser.add_argument('--profile',choices=('quick','full','extreme'),default='quick')
    parser.add_argument('--device',type=int,default=0)
    parser.add_argument('--output',default='gpu_stress_results')
    parser.add_argument('--case-timeout',type=float,default=900)
    parser.add_argument('--max-wall-seconds',type=float,default=7200)
    parser.add_argument('--dry-run',action='store_true')
    parser.add_argument('--_child-case',default=None,help=argparse.SUPPRESS)
    a=parser.parse_args(argv)
    if a.device<0 or a.case_timeout<=0 or a.max_wall_seconds<=0:parser.error('Invalid device or time budget')
    try:
        if a._child_case:
            matching=[c for c in profiles()[a.profile] if c.key==a._child_case]
            if len(matching)!=1:parser.error('Unknown internal case')
            return _case_child(matching[0],a.device,a.output)
        return orchestrate(a)
    except Exception as exc:
        traceback.print_exc()
        print('GPU STRESS FAILED:',exc,file=sys.stderr,flush=True)
        return 1

if __name__=='__main__':raise SystemExit(main())
