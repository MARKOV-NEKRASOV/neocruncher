# SPDX-License-Identifier: GPL-3.0-only
"""Explicit CPU subtree policy; GPU-resident routes cannot activate PyKolm."""
from contextvars import ContextVar
from contextlib import contextmanager
ACTIVE = ContextVar('neocruncher_cpu_library', default=None)

@contextmanager
def use_library(name='legacy', *, reduce=True, progress=None):
    if name not in ('legacy', 'pykolm'):
        raise ValueError('Unknown CPU library')
    state = None
    if name == 'pykolm':
        from pykolm import Session
        state = Session(progress, reduce)
    token = ACTIVE.set(state)
    try:
        yield state
    finally:
        ACTIVE.reset(token)
HYBRID_CHUNK_TERMS = ContextVar('neo_hybrid_chunk_terms', default=0)
