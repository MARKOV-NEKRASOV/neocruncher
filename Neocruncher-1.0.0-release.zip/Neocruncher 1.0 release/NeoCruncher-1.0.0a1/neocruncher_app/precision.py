# SPDX-License-Identifier: GPL-3.0-only
"""Exact number of decimal digits. No fixed precision cap.

For extremely huge exponents a Python integer cannot be materialized safely;
report this as a resource limitation rather than allocating gigabytes merely
while interpreting a quantity. The human input itself has a length guard.
"""
import re
import sys

MAX_DIGITS = None  # compatibility alias: there is no numerical engine limit
MAX_TARGET_DIGITS = None
_RE = re.compile(r'^(\d+(?:\.\d+)?)(?:[eE]([+-]?\d+))?$')
_POW = re.compile(r'^(\d+)\^(\d+)$')
_SUFFIX = {'k':3,'m':6,'b':9,'g':9,'t':12,'q':15,'qa':15,'qi':18,'s':21}


def _materialization_budget():
    """Reject infeasible count-object allocation; not a digit-precision limit.

    The planner must not allocate huge arbitrary integers on hostile inputs.
    This cap concerns bytes consumed simply parsing the *count* itself.
    """
    import os
    try: available=os.sysconf('SC_AVPHYS_PAGES')*os.sysconf('SC_PAGE_SIZE')
    except (AttributeError,OSError,ValueError): available=256*1024**2
    return max(4096, min(8*1024**2, available//2048))


def _large_count_guard(estimated_bits):
    if estimated_bits > _materialization_budget()*8:
        raise ValueError('The count itself would require excessive memory to materialize. '
                         'Use a smaller exponent or an external symbolic planner.')


def parse_count(value, *, maximum=None, minimum=1):
    if isinstance(value,bool):raise ValueError('A digit count must be an integer.')
    if isinstance(value,int):n=value
    elif isinstance(value,str):
        s=value.strip().replace('_','').lower()
        if re.fullmatch(r'\d{1,3}(?:,\d{3})+',s):s=s.replace(',','')
        if len(s)>1100:raise ValueError('Input text too long (1100 characters).')
        m=re.fullmatch(r'(\d+(?:\.\d+)?)(qa|qi|[kmbgtqs])',s)
        if m:s=m.group(1)+'e'+str(_SUFFIX[m.group(2)])
        m=_POW.fullmatch(s)
        if m:
            base=int(m.group(1)); exponent=int(m.group(2))
            if base>1: _large_count_guard((base.bit_length())*exponent)
            n=pow(base,exponent)
        else:
            m=_RE.fullmatch(s)
            if not m:raise ValueError('Use an integer, 10b, 10t, 5.4e20 or 2^19.')
            mantissa, exponent=m.groups()
            exponent=int(exponent or 0)
            whole,dot,frac=mantissa.partition('.')
            significand=int(whole+frac)
            power=exponent-len(frac)
            if power>=0:
                if significand:_large_count_guard((power+len(whole+frac))*4)
                n=significand*10**power
            else:
                # A huge negative exponent can only yield zero or a fraction.
                if -power>len(whole+frac):
                    raise ValueError('Requested digit count must be a positive integer.')
                n,rem=divmod(significand,10**(-power))
                if rem:raise ValueError('Requested digit count must be an exact integer.')
    else:raise ValueError('A digit count must be an integer or a string.')
    if n<minimum or (maximum is not None and n>maximum):
        end='no fixed maximum' if maximum is None else f'{maximum:,}'
        raise ValueError(f'Allowed range: {minimum:,} .. {end}.')
    return n


def parse_target_count(value):return parse_count(value,maximum=None)
