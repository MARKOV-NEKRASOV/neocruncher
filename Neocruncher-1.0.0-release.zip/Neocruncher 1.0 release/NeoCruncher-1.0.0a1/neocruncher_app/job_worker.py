# SPDX-License-Identifier: GPL-3.0-only
"""Private worker for jobs API v1; use jobs.run_job from clients."""
import argparse,json,sys
from .cli import _execute,_args

def main():
    request=json.load(sys.stdin)
    if request.get('api_version')!=1:raise ValueError('Unsupported job API version')
    return _execute(_args(**request['arguments']))
if __name__=='__main__':
    try:raise SystemExit(main())
    except (OSError,ArithmeticError,ValueError,RuntimeError,MemoryError,NotImplementedError) as exc:
        print(f'ERROR: {exc}',file=sys.stderr);raise SystemExit(1)
