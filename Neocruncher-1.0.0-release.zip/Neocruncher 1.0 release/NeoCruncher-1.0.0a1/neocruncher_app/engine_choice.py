# SPDX-License-Identifier: GPL-3.0-only
"""GPU compute-engine selection. Choice is explicit, never silently rerouted."""
from dataclasses import dataclass
@dataclass(frozen=True)
class EngineChoice:
    key: str
    title: str
    available: bool
    detail: str

def _kolmogorov_installed():
    try:
        from kolmogorov.compute.integration import API_VERSION
        return API_VERSION.startswith(('1.2.',))
    except (ImportError, AttributeError):
        return False

GPU_CHOICES=(
    EngineChoice('native','NeoCruncher / OpenCL',True,'Native OpenCL resident arithmetic in GPU mode; CPU/GPU arithmetic in hybrid mode.'),
    EngineChoice('kolmogorov','Kolmogorov Engine',_kolmogorov_installed(),
                 'Kolmogorov resident arithmetic in GPU mode; explicit CPU/GPU hybrid API.'),
)

def validate_engine(mode: str, engine: str):
    if mode not in ('cpu','gpu','both'):
        raise ValueError('Unknown compute mode')
    if engine not in ('native','kolmogorov'):
        raise ValueError('Unknown computing engine')
    if engine == 'kolmogorov' and mode not in ('gpu','both'):
        raise ValueError('Kolmogorov integration supports only GPU or explicit fixed-threshold hybrid.')
    return True
