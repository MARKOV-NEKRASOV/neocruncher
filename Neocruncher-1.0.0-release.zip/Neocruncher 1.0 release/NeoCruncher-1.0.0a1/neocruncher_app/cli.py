# SPDX-License-Identifier: GPL-3.0-only
"""Small and dependency-light terminal frontend for NeoCruncher.

Core calculations never create graphical windows or require GPU drivers.
"""
import argparse
import os
import hashlib
import sys
import time
from pathlib import Path
from .catalog import ALGORITHMS, DEFAULT, select_algorithm
from .core import compute, independently_verify, save_result, APP_VERSION
from .precision import parse_count, parse_target_count
from .workflow import Back
PARALLEL_KEYS = {'pi_chudnovsky', 'pi_ramanujan', 'pi_machin', 'e_taylor', 'e_inverse', 'ln2_atanh', 'zeta3_apery'}
CLI_WORKFLOW_API = 2

def print_catalog():
    print('  NeoCruncher algorithms | positive integer precision, no fixed numerical maximum')
    print('  Computability is constrained by RAM, VRAM, disk, algorithm and elapsed time.')
    print('  GPU NTT multiplication is experimental; first validate with --ntt-self-test on your GPU.')
    print('  Status: ready = integer-bound method; reference = mpmath (NOT CERTIFIED); planned = unavailable.')
    for name in dict.fromkeys((a.constant for a in ALGORITHMS)):
        print(f'\n  {name.upper()}')
        for a in ALGORITHMS:
            if a.constant == name:
                mode = 'multicore' if a.key in PARALLEL_KEYS else 'single'
                print(f'    {a.key:<29} {a.status:<11} {True:<19} {mode:<10} {a.title}')

def _ask_text(message, default=None):
    suffix = f' [{default}]' if default is not None else ''
    print('  [B] Back')
    value = input(f'{message}{suffix} > ').strip()
    if value.lower() in ('b', 'back', '..'):
        raise Back()
    return value if value else default if default is not None else ''

def _args(**updates):
    defaults = dict(constant='pi', algorithm=None, backend='cpu', engine='native', digits=1000, output=None, verify=False, device=0, ram_mib=0.0, save_profile=None, load_profile=None, vram_mib=0.0, disk_budget_gib=0.0, stress_probe=False, list_devices=False, list_algorithms=False, diagnose=False, resources=False, benchmark=False, benchmark_output=None, scale_test=None, gpu_setup=False, gpu_self_test=False, ntt_self_test=False, gpu_1b_readiness=False, readiness_report=None, ntt_scale_probe=False, probe_bits='16384,131072,1048576', probe_report=None, repeats=3, warmup=0, workers=1, compute_mode=None, gpu_vendor='auto', plan=False, expression=None, function=None, x=None, list_functions=False, bellard_offset=None, hex_digits=4)
    defaults.update(verify_prefix=0, hybrid_chunk_terms=0)
    defaults.update(cpu_library='legacy', pykolm_reduce=True)
    defaults.update(hybrid_policy='fixed', calibration_file=None, gpu_batch_size=1024)
    defaults.update(gui=False, checkpoint_dir=None, checkpoint_terms=512, progress=False, progress_file=None, scratch_dir='.', storage_mode='ram', preflight_accepted=False)
    defaults.update(updates)
    return argparse.Namespace(**defaults)

def _print_header():
    from .branding import render_header
    print(render_header(APP_VERSION))

def print_functions():
    from .custom import FUNCTION_DOMAINS, CONSTANTS
    print('  CUSTOM MATHEMATICAL FUNCTIONS (CPU / mpmath; NOT CERTIFIED)')
    print('  Available constants: ' + ', '.join(CONSTANTS))
    print('  Syntax: + - * / **, parentheses, functions; trig arguments in radians.')
    for name, domain in FUNCTION_DOMAINS.items():
        print(f'    {name:<9} domain: {domain}')
    print('  Examples: sin(pi/6), acos(1/2), ln(7), log(8,2), root(27,3), gamma(1/4)')

def interactive():
    from .prefs import first_run_wizard, read
    _print_header()
    if sys.stdin.isatty():
        first_run_wizard(None)
    else:
        read()
    while True:
        from .prefs import paint
        print(paint('\n  ─── MAIN MENU ───', '1;36'))
        print('  [1] Calculate a built-in constant  (CPU / GPU / hybrid)')
        print('  [2] Run a benchmark')
        print('  [3] Custom expression / functions (trig, inverse, log, gamma…)')
        print('  [4] Hardware resources (CPU, RAM, GPU, VRAM)')
        print('  [5] Algorithm catalog')
        print('  [7] Large-scale capacity plan (any positive digit count)')
        print('  [8] GPU readiness + correctness self-test')
        print('  [0] Exit\n')
        choice = input('  > ').strip()
        if choice in ('0', 'q', 'quit', 'exit'):
            return 0
        try:
            if choice == '4':
                from .hardware import print_resources
                print_resources()
                continue
            if choice == '5':
                print_catalog()
                continue
            if choice == '7':
                from .precision import parse_target_count
                from .scaling import print_scale_probe
                raw = _ask_text('  Planned decimal digits (1m, 10b, 10t, 5.4e20)', '10b')
                print_scale_probe(parse_target_count(raw), mode='gpu')
                continue
            if choice == '8':
                execute(_args(gpu_self_test=True))
                continue
            if choice in ('1', '2'):
                from .workflow import wizard
                chosen = wizard(benchmark=choice == '2')
                if chosen is not None:
                    execute(chosen)
            elif choice == '3':
                from .workflow import custom_wizard
                chosen = custom_wizard()
                if chosen is not None:
                    execute(chosen)
            else:
                print('  Unknown menu option.')
                continue
        except (OSError, ArithmeticError, ValueError, NotImplementedError, RuntimeError, MemoryError) as err:
            print(f'  ERROR: {err}')
        except KeyboardInterrupt:
            print('\n  Cancelled.')
        except Back:
            print('\n  Back to main menu.')
        print('\n  Returning to main menu...')

def parse_args(argv=None):
    p = argparse.ArgumentParser(description=f'NeoCruncher {APP_VERSION} — arbitrary positive decimal precision; resource preflight')
    p.add_argument('--list-algorithms', action='store_true')
    p.add_argument('--list-devices', action='store_true')
    p.add_argument('--diagnose', action='store_true')
    p.add_argument('--resources', action='store_true', help='display RAM, VRAM, CPU, GPU and OpenCL availability')
    p.set_defaults(gui=False)
    p.add_argument('--checkpoint-dir', help='CPU Chudnovsky or hybrid binary subtree checkpoints; unavailable in GPU pure')
    p.add_argument('--checkpoint-terms', type=int, default=512, help='terms per checkpoint (32..100000)')
    p.add_argument('--progress', action='store_true', help='display work progress; certified decimals only when complete')
    p.add_argument('--progress-file', help='append JSONL progress events (GUI/automation)')
    p.add_argument('--storage-mode', choices=['ram', 'checkpoint'], default='ram', help='ram or checkpoint (CPU Chudnovsky or hybrid series)')
    p.add_argument('--scratch-dir', default='.', help='directory used for disk/scratch capacity preflight; checkpoint data stored via --checkpoint-dir')
    p.add_argument('--benchmark', action='store_true', help='benchmark calculation without writing TXT')
    p.add_argument('--repeats', type=int, default=3, help='benchmark repetitions 1..20')
    p.add_argument('--warmup', type=int, default=0, help='benchmark warmup trials 0..5')
    p.add_argument('--benchmark-output', help='optional JSON results filename; never overwrites')
    p.add_argument('--expression', help='restricted expression: sin(pi/6), ln(10), log(8,2), sqrt(2)+pi (numerically evaluated; uncertified)')
    p.add_argument('--function', help='unary custom function: sin, acos, ln, gamma, etc.; use --x for argument')
    p.add_argument('--x', help='expression for --function argument; e.g. pi/6')
    p.add_argument('--list-functions', action='store_true', help='list custom functions and their real-valued domains')
    p.add_argument('--save-profile', help='save backend/CPU/RAM/VRAM per-project preset and exit')
    p.add_argument('--load-profile', help='load saved per-project backend/CPU/RAM/VRAM preset')
    p.add_argument('--vram-mib', type=float, default=0.0, help='per-job GPU memory limit (MiB), 0=automatic (estimated guard, not hard cap)')
    p.add_argument('--stress-probe', action='store_true', help='capacity planning probe; no computation')
    p.add_argument('--scale-test', type=parse_target_count, metavar='DIGITS', help='arbitrary-size capacity check only; never calculates')
    p.add_argument('--gpu-batch-size', type=int, default=1024, help='Hybrid multiplication batch size 1..1024 (1=legacy unbatched comparison)')
    p.add_argument('--ntt-self-test', action='store_true', help='verify GPU NTT, CRT and carry against independent CPU integer products')
    p.add_argument('--ntt-scale-probe', action='store_true', help='timed GPU exact-integer multiplication probe (NOT 1B Pi)')
    p.add_argument('--probe-bits', default='16384,131072,1048576', help='comma-separated operand bit sizes for --ntt-scale-probe (max 8388608 each)')
    p.add_argument('--probe-report', help='optional exclusive-create JSON file for --ntt-scale-probe')
    p.add_argument('--gpu-1b-readiness', action='store_true', help='GPU smoke test + honest readiness report for 1,000,000,000 digits of Pi; DOES NOT compute Pi')
    p.add_argument('--readiness-report', help='JSON report filename for --gpu-1b-readiness; never overwrites')
    p.add_argument('--gpu-self-test', action='store_true', help='exercise both GPU-pure engines and compare pi/e against CPU references')
    p.add_argument('--gpu-setup', action='store_true', help='interactive permission-based OpenCL setup assistant')
    p.add_argument('--workers', type=int, default=1, help='CPU worker processes (1=single core; <= logical CPU affinity count=multicore)')
    p.add_argument('--bellard-offset', type=lambda v: parse_count(v, minimum=0, maximum=8000000), help='Bellard binary bit position, supports e.g. 1e6 (not decimal position)')
    p.add_argument('--hex-digits', type=int, default=4)
    p.add_argument('--constant', choices=list(dict.fromkeys((a.constant for a in ALGORITHMS))), default='pi')
    p.add_argument('--algorithm', help='algorithm ID from --list-algorithms')
    p.add_argument('--digits', '--precision', type=parse_target_count, default=1000, help='exact decimal digits after separator; supports 10b, 10t, 5.4e20; no fixed precision cap')
    p.add_argument('--compute-mode', choices=['cpu', 'gpu', 'both'], help='CPU, GPU, or hybrid when implemented for the selected algorithm; detects hardware before computation')
    p.add_argument('--gpu-vendor', choices=['auto', 'amd', 'nvidia', 'intel'], default='auto', help='optional GPU vendor filter')
    p.add_argument('--plan', action='store_true', help='show compatibility and estimated RAM before starting computation')
    p.add_argument('--hybrid-chunk-terms', type=int, default=0, help='CPU subtree terms before GPU merges; 0=adaptive, 1024=reproduce 1.2 policy')
    p.add_argument('--cpu-library', choices=['legacy', 'pykolm'], default='legacy', help='Experimental CPU subtree provider; legacy remains the reference')
    p.add_argument('--pykolm-no-reduce', dest='pykolm_reduce', action='store_false', help='Ablation: PyKolm without Chudnovsky common-factor reduction')
    p.add_argument('--hybrid-policy', choices=['fixed', 'calibrated'], default='fixed', help='Explicit fixed threshold or device-measured CPU/GPU routing')
    p.add_argument('--calibration-file', help='Device-bound JSON produced by examples/calibrate_hybrid.py')
    p.add_argument('--engine', choices=['native', 'kolmogorov'], default='native', help='exact arithmetic provider; both GPU modes use distinct resident NTT drivers; the matching Kolmogorov bundle is a shared dependency')
    p.add_argument('--backend', choices=['cpu', 'opencl-ntt', 'hybrid-ntt', 'hybrid-bellard'], default='cpu')
    verification = p.add_mutually_exclusive_group()
    verification.add_argument('--verify', action='store_true', help='Full independent mpmath comparison, at most 100000 decimals')
    verification.add_argument('--verify-prefix', type=lambda v: parse_count(v, minimum=1, maximum=100000), default=0, metavar='N', help='Explicit independent check of first N decimals (1..100000); remaining digits are not checked')
    p.add_argument('--output', help='result .txt filename; never overwrites')
    p.add_argument('--device', type=int, default=0)
    p.add_argument('--disk-mib', type=float, default=0.0, help='work disk space limit in MiB; 0=automatic')
    p.add_argument('--ram-mib', type=float, default=0.0, help='0=automatic RAM limit based on available memory; otherwise MiB (admission guard, not hard cap)')
    args = p.parse_args(argv)
    args.disk_budget_gib = args.disk_mib / 1024
    return args

def _execute(a):
    from .result_verification import request_scope
    request_scope(a)
    if a.cpu_library != 'legacy' or not a.pykolm_reduce:
        if a.expression is not None or a.function is not None or a.bellard_offset is not None:
            raise ValueError('PyKolm options apply only to the supported built-in series')
        if not a.pykolm_reduce and a.cpu_library != 'pykolm':
            raise ValueError('--pykolm-no-reduce requires --cpu-library pykolm')
    if getattr(a, 'storage_mode', 'ram') == 'disk-swap' and (not a.plan) and (a.scale_test is None):
        raise NotImplementedError('Out-of-core disk swap is not implemented yet; use --storage-mode checkpoint for CPU Chudnovsky recovery only.')
    if getattr(a, 'storage_mode', 'ram') == 'checkpoint' and (not a.checkpoint_dir):
        raise ValueError('--storage-mode checkpoint requires --checkpoint-dir PATH')
    if a.save_profile:
        from .projects import save_profile
        path = save_profile(a.save_profile, {k: getattr(a, k) for k in ('ram_mib', 'vram_mib', 'workers', 'backend', 'device')})
        print('  Saved resource profile: ' + str(path))
        return 0
    if a.load_profile:
        from .projects import load_profile
        for key, value in load_profile(a.load_profile).items():
            setattr(a, key, value)
        print('  Loaded resource profile: ' + a.load_profile)
    if a.stress_probe:
        from .scaling import print_scale_probe
        print_scale_probe(1000000000)
        return 0
    if a.gpu_setup:
        from .gpu_setup import interactive_setup
        interactive_setup()
        return 0
    if getattr(a, 'gpu_1b_readiness', False):
        from .gpu_billion import readiness
        return readiness(a.device, getattr(a, 'readiness_report', None))
    if getattr(a, 'ntt_scale_probe', False):
        from .gpu_scale_probe import run_scale_probe, parse_probe_bits
        run_scale_probe(a.device, parse_probe_bits(a.probe_bits), a.probe_report)
        return 0
    if a.ntt_self_test:
        from .arithmetic.selftest import main as ntt_test
        return ntt_test(device=a.device)
    if a.gpu_self_test:
        from .gpu_setup import gpu_self_test
        return 0 if gpu_self_test() else 2
    if a.scale_test is not None:
        from .scaling import print_scale_probe
        print_scale_probe(a.scale_test, mode=True, backend=a.backend, scratch=a.scratch_dir)
        return 0
    if a.plan and (not (a.expression is not None or a.function is not None)):
        from .scaling import print_scale_probe
        print_scale_probe(a.digits, mode=a.compute_mode or ('gpu' if a.backend != 'cpu' else 'cpu'), backend=a.backend, scratch=a.scratch_dir, algorithm=a.algorithm or a.constant)
        return 0
    if a.list_algorithms:
        print_catalog()
        return 0
    if a.list_functions:
        print_functions()
        return 0
    if a.diagnose or a.list_devices:
        from .hardware import print_diagnosis
        print_diagnosis()
        return 0
    if a.resources:
        from .hardware import print_resources
        print_resources()
        return 0
    if a.compute_mode:
        from .compute_modes import resolve_mode
        mode_spec = None if a.expression is not None or a.function is not None else select_algorithm(a.constant, a.algorithm)
        if mode_spec is not None:
            chosen_backend, chosen_device, gpu_info = resolve_mode(mode_spec, a.compute_mode, vendor=a.gpu_vendor, device=None if a.device == 0 else a.device)
            if a.backend != 'cpu' and a.backend != chosen_backend:
                raise ValueError('--backend conflicts with --compute-mode; use one or the other.')
            a.backend, a.device = (chosen_backend, chosen_device)
        elif a.compute_mode != 'cpu':
            raise ValueError('Custom expressions currently support CPU only.')
    from .cpu_options import available_processes
    if a.workers < 1 or a.workers > available_processes():
        raise ValueError(f'--workers must be 1..{available_processes()} for this system.')
    if type(a.digits) is not int or a.digits < 1:
        raise ValueError('Precision must be a positive integer.')
    if a.function is not None:
        from .custom import FUNCTION_DOMAINS
        if a.expression is not None or a.x is None:
            raise ValueError('--function requires --x, and cannot be combined with --expression.')
        if a.function not in FUNCTION_DOMAINS or a.function in ('root', 'agm'):
            raise ValueError('Use --list-functions for unary functions. For root/agm use --expression.')
        a.expression = f'{a.function}({a.x})'
    elif a.x is not None:
        raise ValueError('--x requires --function.')
    if a.expression is not None:
        from .budgets import check_budget
        allocation = check_budget(a.digits, 'custom_expression', a.backend, a.ram_mib, a.vram_mib, a.workers, a.device)
        a.ram_mib, a.vram_mib = (allocation['ram_mib'], allocation['vram_mib'])
        if a.backend != 'cpu' or a.workers != 1 or a.verify:
            raise ValueError('Custom expressions currently support CPU mono only; no independent verification.')
        if a.plan:
            print(f"  PLAN: custom expression | {a.digits:,} decimals | CPU mono | estimated RAM {allocation['estimated_ram_mib']:,.1f} MiB")
            print('  Estimate is not a hard memory bound or time guarantee.')
            return 0
        if a.benchmark:
            from .benchmark import run_custom_benchmark, save_benchmark
            summary = run_custom_benchmark(a.expression, a.digits, repetitions=a.repeats, warmup=a.warmup)
            print(f'  CUSTOM BENCHMARK: {a.expression} ({a.digits:,} decimal places)')
            print('  Times (s): ' + ', '.join((f'{t:.4f}' for t in summary['samples_seconds'])))
            print(f"  Best: {summary['min_seconds']:.4f}s | Median: {summary['median_seconds']:.4f}s")
            if a.benchmark_output:
                print('  Saved ' + str(save_benchmark(a.benchmark_output, summary)))
            return 0
        from .preflight import print_preflight
        (__import__('neocruncher_app.preflight', fromlist=['preflight']).preflight if getattr(a, 'preflight_accepted', False) else print_preflight)(digits=a.digits, algorithm='custom_expression', backend=a.backend, workers=1, ram_budget=a.ram_mib, vram_budget=a.vram_mib, output=a.output or f'custom-{a.digits}.txt', scratch=a.scratch_dir, disk_budget_gib=a.disk_budget_gib)
        from .custom import compute_custom
        txt, report = compute_custom(a.expression, a.digits)
        report['resource_admission'] = allocation
        target = a.output or f'custom-{a.digits}.txt'
        from .progress import emitter
        emitter(getattr(a, 'progress_file', None), console=False)({'stage': 'Writing custom TXT and report'})
        path, json_path = save_result(target, txt, report)
        print('  CUSTOM EXPRESSION — NOT MATHEMATICALLY CERTIFIED')
        print(f"  {txt[:90]}{('...' if len(txt) > 90 else '')}")
        print(f"  Saved {path} + {json_path} | {report['seconds']:.3f}s")
        return 0
    from .engine_choice import validate_engine
    validate_engine('gpu' if a.backend == 'opencl-ntt' else 'cpu' if a.backend == 'cpu' else 'both', a.engine)
    spec = select_algorithm(a.constant, a.algorithm)
    if a.backend not in spec.backends:
        raise ValueError(f'{spec.key} does not implement {a.backend}; no CPU substitution is permitted')
    if a.engine == 'kolmogorov' and a.backend not in ('opencl-ntt', 'hybrid-ntt'):
        raise ValueError('Kolmogorov requires OpenCL NTT or hybrid NTT, not Bellard.')
    from .budgets import check_budget
    allocation = check_budget(a.digits, spec.key, a.backend, a.ram_mib, a.vram_mib, a.workers, a.device)
    a.ram_mib, a.vram_mib = (allocation['ram_mib'], allocation['vram_mib'])
    from .preflight import print_preflight
    if not a.benchmark and (not a.plan):
        preflight_kwargs = dict(digits=a.digits, algorithm=spec.key, backend=a.backend, workers=a.workers, ram_budget=a.ram_mib, vram_budget=a.vram_mib, output=a.output or f'{a.constant}-{a.digits}-{spec.key}.txt', scratch=a.checkpoint_dir or a.scratch_dir, device=a.device, disk_budget_gib=a.disk_budget_gib)
        if getattr(a, 'preflight_accepted', False):
            from .preflight import preflight
            snapshot = preflight(**preflight_kwargs)
            if not snapshot['output_space_ok']:
                raise ValueError('Estimated output exceeds permitted disk allowance.')
        else:
            print_preflight(**preflight_kwargs)
    if spec.key == 'pi_bellard' and (a.bellard_offset is None or not 0 <= a.bellard_offset <= 8000000 or (not 1 <= a.hex_digits <= 6)):
        raise ValueError('Bellard requires --bellard-offset 0..8e6 and --hex-digits 1..6.')
    if a.plan:
        label = f'Bellard binary offset {a.bellard_offset}' if spec.key == 'pi_bellard' else f'{a.digits:,} decimal places'
        print(f'  PLAN: {spec.title} | {label} | backend={a.backend} | engine={a.engine} | CPU workers={a.workers}')
        print(f"  RAM estimate: {allocation['estimated_ram_mib']:,.1f} MiB / limit {a.ram_mib:,.0f} MiB")
        print(f'  VRAM limit: {a.vram_mib:,.0f} MiB (0=auto); hardware preflight complete.')
        if spec.status == 'reference':
            print('  NOTE: Numerical reference, NOT certified; high-precision runtime unvalidated.')
        elif spec.key == 'pi_bellard':
            print('  NOTE: HEX extractor, not a decimal generator.')
        print('  Capacity estimate only, not a time guarantee or proven memory upper bound.')
        return 0
    if spec.key == 'pi_bellard':
        if a.bellard_offset is None:
            raise ValueError('Bellard requires --bellard-offset BINARY_POSITION')
        if a.workers != 1:
            raise ValueError('Bellard CPU currently supports only --workers 1.')
        if a.backend not in spec.backends:
            raise ValueError(f'Bellard supports only {spec.backends}.')
        if a.benchmark:
            from .benchmark import run_bellard_benchmark, save_benchmark
            print(f'  BENCHMARK: Bellard hex offset={a.bellard_offset:,}, block={a.hex_digits} | {a.backend} | {a.repeats} run(s)', flush=True)
            summary = run_bellard_benchmark(a.bellard_offset, a.hex_digits, backend=a.backend, repetitions=a.repeats, warmup=a.warmup, device=a.device, vram_mib=a.vram_mib)
            print('  Times (s): ' + ', '.join((f'{t:.4f}' for t in summary['samples_seconds'])))
            print(f"  Best: {summary['min_seconds']:.4f}s | Median: {summary['median_seconds']:.4f}s")
            print(f"  Extracted hex block: {summary['verified_block']} | consistent across trials: YES")
            if a.benchmark_output:
                print('  Saved ' + str(save_benchmark(a.benchmark_output, summary)))
            return 0
        from .algorithms.bellard import extract
        from .progress import emitter
        emit = emitter(getattr(a, 'progress_file', None), console=getattr(a, 'progress', False)) if getattr(a, 'progress', False) or getattr(a, 'progress_file', None) else None
        if emit:
            emit({'stage': 'extracting Bellard block', 'percent': 0, 'work_done': 0, 'work_total': 1, 'certified_decimal_digits': 0})
        start = time.perf_counter()
        result = extract(a.bellard_offset, a.hex_digits, a.backend, a.device, a.vram_mib)
        elapsed = time.perf_counter() - start
        data = result.hex_block
        checked = 'NOT RUN'
        if a.verify:
            if a.backend not in ('opencl-bellard', 'hybrid-bellard'):
                raise ValueError('Bellard --verify supports GPU-to-CPU cross-check only.')
            reference = extract(a.bellard_offset, a.hex_digits, 'cpu')
            if data != reference.hex_block:
                raise ArithmeticError('Bellard GPU and CPU result mismatch')
            checked = 'PASS cross-check against CPU (same formula; not mathematically independent)'
        output = a.output or f'pi-bellard-bit-{result.offset}.txt'
        report = {'program': 'NeoCruncher', 'version': APP_VERSION, 'constant': 'pi', 'algorithm': spec.key, 'backend': a.backend, 'binary_offset': result.offset, 'hex_digits': result.hex_digits, 'decimal_places': None, 'seconds': elapsed, 'terms': result.terms, 'error_bound': result.error_bound, 'cross_check': checked, 'verification_scope': 'fixed-point interval; no execution attestation', 'sha256': hashlib.sha256((data + '\n').encode('ascii')).hexdigest()}
        report['resource_admission'] = allocation
        path, sidecar = save_result(output, data, report)
        if emit:
            emit({'stage': 'Bellard hexadecimal block finished', 'percent': 100, 'work_done': 1, 'work_total': 1, 'certified_decimal_digits': 0})
        print(f'  Pi HEX at bit {result.offset}: {data} | {elapsed:.3f}s | {a.backend}')
        print(f'  Saved {path} + {sidecar}')
        return 0
    if a.bellard_offset is not None:
        raise ValueError('--bellard-offset requires --algorithm pi_bellard')
    if a.verify and spec.status == 'reference':
        raise ValueError('This reference implementation has no independent verifier; --verify is not supported.')
    if a.backend in ('cpu', 'opencl-ntt', 'hybrid-ntt') and a.workers > 1 and (spec.key not in PARALLEL_KEYS or a.backend != 'cpu'):
        raise ValueError(f'{spec.key} is single-process; use --workers 1.')
    if a.benchmark:
        if a.checkpoint_dir:
            raise ValueError('Benchmarks must recompute; checkpoint reuse is not supported')
        from .benchmark import run_benchmark, save_benchmark
        print(f'  BENCHMARK: {spec.title} | {a.digits:,} decimal places | {a.backend} | workers={a.workers} | {a.repeats} run(s)', flush=True)
        summary = run_benchmark(a.constant, spec.key, a.digits, backend=a.backend, workers=a.workers, repetitions=a.repeats, warmup=a.warmup, device=a.device, engine=a.engine, vram_mib=a.vram_mib, ram_mib=a.ram_mib, gpu_batch_size=a.gpu_batch_size, hybrid_policy=a.hybrid_policy, calibration_file=a.calibration_file, cpu_library=a.cpu_library, pykolm_reduce=a.pykolm_reduce, hybrid_chunk_terms=a.hybrid_chunk_terms)
        print('  Times (s): ' + ', '.join((f'{s:.4f}' for s in summary['samples_seconds'])))
        print(f"  Best: {summary['min_seconds']:.4f}s | Median: {summary['median_seconds']:.4f}s | Mean: {summary['mean_seconds']:.4f}s")
        print('  Results consistent across trials: YES (SHA-256)')
        summary['resource_admission'] = allocation
        if a.benchmark_output:
            print('  Saved ' + str(save_benchmark(a.benchmark_output, summary)))
        return 0
    outfile = a.output or f'{a.constant}-{a.digits}-{spec.key}.txt'
    if Path(outfile).exists() or Path(outfile + '.json').exists():
        raise FileExistsError('Output/report already exists. Select a new --output.')
    print('\n  ─── COMPUTATION IN PROGRESS ───')
    print(f'  NeoCruncher Alpha 1.0 | {spec.title} | {a.digits:,} decimal places | mode={a.backend} | arithmetic provider={a.engine} | CPU coordinator processes={a.workers}', flush=True)
    from .progress import emitter
    console_progress = bool(getattr(a, 'progress', False) or sys.stderr.isatty())
    notify = emitter(getattr(a, 'progress_file', None), console=console_progress) if console_progress or getattr(a, 'progress_file', None) else None
    if notify:
        notify({'stage': 'Preparing numerical calculation', 'percent': None, 'work_done': 0, 'work_total': 0, 'certified_decimal_digits': 0})
    if a.checkpoint_dir and (a.workers != 1 or (a.backend == 'cpu' and spec.key != 'pi_chudnovsky') or a.backend not in ('cpu', 'opencl-ntt', 'hybrid-ntt')):
        raise ValueError('Checkpoints require one worker and no LAN peer; CPU supports Chudnovsky, GPU/hybrid supports binary-splitting series.')
    txt, report = compute(a.constant, a.digits, spec.key, a.backend, workers=a.workers, device=a.device, ram_mib=a.ram_mib, vram_mib=a.vram_mib, checkpoint_dir=a.checkpoint_dir, checkpoint_terms=a.checkpoint_terms, progress=notify, gpu_batch_size=getattr(a, 'gpu_batch_size', 1024), engine=a.engine, hybrid_policy=a.hybrid_policy, calibration_file=a.calibration_file, cpu_library=a.cpu_library, pykolm_reduce=a.pykolm_reduce, hybrid_chunk_terms=a.hybrid_chunk_terms)
    report['resource_admission'] = allocation
    from .result_verification import save_then_verify
    path, json_path = save_then_verify(outfile, txt, report, request_scope(a), notify)
    print(f"  {txt[:90]}{('...' if len(txt) > 90 else '')}")
    print(f"  Saved {path} + {json_path} | calculation {report['seconds']:.4f}s")
    print(f"  Accuracy status: {report['details'].get('certification', 'see JSON report for method and verification scope')}")
    print(f"  Independent verification: {report['independent_verification']}")
    if report['details'].get('gpu_pure'):
        m = report['details']['metrics']
        print('  GPU PURE | all numerical operations executed by device kernels')
        print(f"  Driver: {report['details']['driver']} | kernels: {m['gpu_kernel_launches']:,}")
        print(f"  Storage bank: {m['spill_count']:,} transfers | final bytes: {m['output_bytes_downloaded']:,}")
        print('  Device stability and maximum precision require a separate validation campaign.')
    stats = report['details'].get('arithmetic')
    if stats:
        print('  ─── GPU ARITHMETIC PROFILE ───')
        batch_label = 'GPU logical groups [NOT fused]' if stats.get('engine_choice') == 'kolmogorov' else 'GPU batch launches'
        print(f"  {batch_label}: {stats.get('gpu_batch_dispatches'):,} | Batched products: {stats.get('gpu_batched_products'):,} | Batch size: {True:,}")
        print(f"  GPU products: {stats['gpu_multiplications']:,} / {stats['multiplication_count']:,} | GPU direct: {stats.get('gpu_schoolbook_calls'):,} | GPU NTT: {stats.get('gpu_ntt_calls'):,}")
        print(f"  GPU multiplication wall time: {stats.get('gpu_multiply_wall_seconds', 0):,.3f}s (includes launch/transfer overhead; NOT pure GPU compute time)")
        print(f"  Small operand pairs (<128 bits): {stats.get('multiply_inputs_under_128_bits', 0):,} | (<2048 bits): {stats.get('multiply_inputs_under_2048_bits', 0):,}")
        print(f"  Transfer totals: upload {stats.get('gpu_bytes_uploaded'):,} B; download {stats.get('gpu_bytes_downloaded'):,} B")
        print('  Detailed statistics saved in the JSON report.')
    return 0

def execute(a):
    from .result_verification import request_scope
    request_scope(a)
    local = ('save_profile', 'stress_probe', 'gpu_setup', 'scale_test', 'plan', 'list_algorithms', 'list_functions', 'diagnose', 'list_devices', 'resources')
    if any((getattr(a, k, None) for k in local)):
        return _execute(a)
    from .jobs import run_job
    return run_job(a)

def main(argv=None):
    if argv is None:
        argv = sys.argv[1:]
    if not argv and sys.stdin.isatty():
        return interactive()
    if not argv:
        print(f'NeoCruncher {APP_VERSION} | Decimal precision: no fixed numerical cap. Use --help.')
        return 0
    return execute(parse_args(argv))
