# SPDX-License-Identifier: GPL-3.0-only
"""Blocked host binary splitting, retaining GMP integers above leaf blocks.

The former dispatcher repacked large operands/result for every multiplication.
This path converts once per leaf block and retains mpz until final rendering.
"""
try:
    from gmpy2 import mpz
except ImportError:
    mpz=int

LEAF_TERMS=32

def split(family,a,b,arg=0):
    from ..cpu_library import ACTIVE
    selected=ACTIVE.get()
    if selected is not None:
        from pykolm import Plan
        import time
        begin=time.perf_counter()
        try:return selected.recursive(Plan(family,a,b,arg,reduce=selected.reduce),a,b)
        finally:selected.metrics['local_split_seconds']+=time.perf_counter()-begin
    if b-a<=LEAF_TERMS:
        if family=='exp':
            p,t=1,0
            for k in range(a,b):p*=k;t=t*k+(-1 if arg and k&1 else 1)
            return mpz(p),mpz(t)
        if family=='chud':
            p,q,t=1,1,0
            for k in range(a,b):
                if not k:pk,qk,tk=1,1,13591409
                else:
                    pk=(6*k-5)*(2*k-1)*(6*k-1)
                    qk=k*k*k*10939058860032000
                    tk=(-1 if k&1 else 1)*pk*(13591409+545140134*k)
                t=t*qk+p*tk;p*=pk;q*=qk
            return mpz(p),mpz(q),mpz(t)
        from .classical import _bs_chunk_legacy
        return tuple(mpz(v) for v in _bs_chunk_legacy((family,a,b,arg)))
    mid=(a+b)//2
    left,right=split(family,a,mid,arg),split(family,mid,b,arg)
    if family=='exp':
        p,t=left;q,u=right
        return p*q,t*q+u
    p,q,t=left;r,s,u=right
    return p*r,q*s,t*s+p*u

def task(job):return split(*job)
