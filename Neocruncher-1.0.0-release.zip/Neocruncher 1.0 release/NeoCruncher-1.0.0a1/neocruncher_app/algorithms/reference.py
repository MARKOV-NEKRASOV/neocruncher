# SPDX-License-Identifier: GPL-3.0-only
"""Classical methods and special constants implemented with mpmath precision.

These are *numerical reference implementations*, not formal error-certified
algorithms. Do NOT confuse them with implementations of similarly named
specialized y-cruncher papers that remain in the catalog as planned.
"""
from __future__ import annotations
import time
from .classical import CertifiedDigits
from ..custom import _format_truncated


def _agm_pi(mp):
    a=mp.mpf(1)
    b=1/mp.sqrt(2)
    t=mp.mpf(1)/4
    p=mp.mpf(1)
    # Number of correct digits roughly doubles each AGM iteration.
    # Loop stops when a and b are indistinguishable at working precision.
    for _ in range(80):
        old=a
        a=(a+b)/2
        b=mp.sqrt(old*b)
        t-=p*(old-a)**2
        p*=2
        if abs(a-b)<mp.power(10,-(mp.mp.dps-5)):break
    else:raise ArithmeticError('AGM π iteration failed to converge')
    return (a+b)**2/(4*t)


def _borwein_pi(mp):
    # Borwein quartic algorithm, 1985, in inverse-pi form.
    y=mp.sqrt(2)-1
    a=6-4*mp.sqrt(2)
    for k in range(60):
        root=mp.sqrt(mp.sqrt(1-y**4))
        y=(1-root)/(1+root)
        a=a*(1+y)**4-(2**(2*k+3))*y*(1+y+y**2)
        if abs(y)<mp.power(10,-(mp.mp.dps+8)//4):
            break
    else:raise ArithmeticError('Borwein quartic π iteration failed to converge')
    return 1/a

REFERENCE_EXPRESSIONS={
 'pi_gauss_legendre':_agm_pi,
 'pi_borwein_quartic':_borwein_pi,
 'catalan_mpmath':lambda mp:mp.catalan,
 'gamma_mpmath':lambda mp:mp.euler,
 'gamma_quarter_mpmath':lambda mp:mp.gamma(mp.mpf(1)/4),
 'gamma_third_mpmath':lambda mp:mp.gamma(mp.mpf(1)/3),
 'gamma_fifth_mpmath':lambda mp:mp.gamma(mp.mpf(1)/5),
 'zeta5_mpmath':lambda mp:mp.zeta(5),
 'ln10_mpmath':lambda mp:mp.log(10),
 'lemniscate_mpmath':lambda mp:mp.gamma(mp.mpf(1)/4)**2/(2*mp.sqrt(2*mp.pi)),
}

def compute_reference(algorithm, places):
    if algorithm not in REFERENCE_EXPRESSIONS:raise ValueError(f'Unknown reference algorithm {algorithm}')
    try:import mpmath as mp
    except ImportError as err:raise RuntimeError('Numerical reference formulas require mpmath. Install requirements-cpu.txt') from err
    start=time.perf_counter()
    fn=REFERENCE_EXPRESSIONS[algorithm]
    with mp.workdps(places+30):a=_format_truncated(fn(mp),places,mp)
    with mp.workdps(places+60):b=_format_truncated(fn(mp),places,mp)
    if a!=b:raise ArithmeticError('Reference formula unstable at requested precision; no TXT written.')
    return CertifiedDigits(b,{'algorithm':algorithm,'method':'mpmath arbitrary precision, 2 guard passes',
                              'certification':'NOT CERTIFIED (numerical reference)',
                              'seconds_internal':time.perf_counter()-start})
