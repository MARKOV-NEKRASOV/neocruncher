# SPDX-License-Identifier: GPL-3.0-only
"""Bellard binary digit extraction, scalar CPU and vectorized OpenCL.

Mathematical identity: F. Bellard (1997), https://bellard.org/pi/pi_bin/pi_bin.html
Compute frac(2**offset * pi) to a CERTIFIED short hexadecimal prefix.

Each independent k is evaluated using modular exponentiation and fixed-point
fractions (56-bit; no floating-point accumulation). Both implementations return
mod 2**56 contributions. The host adds a rational tail and encloses all
truncation errors by rational intervals. Failure to prove the requested prefix
raises ArithmeticError instead of guessing digits. No formal proof of this code
or guarantee that OpenCL hardware is error-free is implied.
"""
from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction
from importlib.resources import files

BITS = 56
SCALE = 1 << BITS
MASK = SCALE - 1
MAX_OFFSET = 8_000_000  # keep modular products inside uint64 for GPU kernels
COEFFICIENTS = ((-32, 4, 1), (-1, 4, 3), (256, 10, 1),
                (-64, 10, 3), (-4, 10, 5), (-4, 10, 7), (1, 10, 9))
COEFF_SUM = sum(abs(c) for c, _, _ in COEFFICIENTS)

@dataclass(frozen=True)
class BellardResult:
    offset: int
    hex_digits: int
    hex_block: str
    backend: str
    terms: int
    error_bound: str


def _fraction_bits(remainder: int, divisor: int) -> int:
    """floor(2^56 * remainder/divisor), exact and uint64-compatible."""
    hi, rem = divmod(remainder << 28, divisor)
    lo = (rem << 28) // divisor
    return (hi << 28) | lo


def _term_mod(k: int, offset: int) -> int:
    exponent = offset - 6 - 10 * k
    assert exponent >= 0
    result = 0
    for coefficient, mul, add in COEFFICIENTS:
        divisor = mul*k + add
        r = pow(2, exponent, divisor)
        fraction = _fraction_bits(r, divisor)
        result = (result + coefficient*fraction) & MASK
    return (-result if k & 1 else result) & MASK


def _prefix_cpu(offset: int, count: int, start: int=0) -> int:
    return sum((_term_mod(k, offset) for k in range(start, start + count))) & MASK


def _prefix_opencl(offset: int, count: int, device_index: int, vram_mib:float=0.0, start_index:int=0) -> int:
    try:
        import numpy as np
        import pyopencl as cl
    except ImportError as e:
        raise RuntimeError('OpenCL Bellard requires numpy and pyopencl. '
                           'Install the optional GPU dependencies, then run --diagnose.') from e
    from ..hardware import opencl_devices
    devices = opencl_devices()
    if not devices:
        raise RuntimeError('No usable GPU OpenCL runtime. Run --diagnose; CPU Bellard works without OpenCL.')
    if not 0 <= device_index < len(devices):
        raise ValueError(f'Device index {device_index} not available. Found {len(devices)} GPUs.')
    dev = devices[device_index]['object']
    if dev.max_mem_alloc_size < min(count, 65536)*8:
        raise RuntimeError('GPU has insufficient memory for Bellard tile')
    if 'cl_khr_int64_base_atomics' not in dev.extensions:
        pass  # No atomics required: independent uint64 output per work-item.
    ctx = cl.Context([dev]); queue = cl.CommandQueue(ctx)
    source = files('neocruncher_app').joinpath('resources/bellard.cl').read_text()
    try:
        program = cl.Program(ctx, source).build()
    except Exception as e:
        raise RuntimeError(f'Bellard OpenCL kernel compilation failed: {e}') from e
    tile = min(65536, max(1, count))
    if vram_mib:
        # Device arrays are uint64, so enforce the budget for this allocation.
        tile=min(tile,max(1,int(vram_mib*1024**2//8)))
    buf = cl.Buffer(ctx, cl.mem_flags.WRITE_ONLY, size=tile*8)
    arr = np.empty(tile, dtype=np.uint64)
    total = 0
    for tile_start in range(0, count, tile):
        length = min(tile, count-tile_start)
        program.bellard_terms(queue, (length,), None, buf, np.uint64(start_index+tile_start),
                              np.uint64(offset), np.uint32(length))
        cl.enqueue_copy(queue, arr[:length], buf, is_blocking=True)
        total = (total + int(arr[:length].sum(dtype=np.uint64))) & MASK
    queue.finish()
    return total


def _tail(offset: int, begin: int, tail_terms: int = 12) -> tuple[Fraction, Fraction]:
    """Exact rational tail terms + conservative absolute remainder enclosure."""
    result = Fraction(0)
    for k in range(begin, begin+tail_terms):
        exponent = offset - 6 - 10*k
        assert exponent < 0
        base = Fraction((-1 if k & 1 else 1), 1 << (-exponent))
        for c, mul, add in COEFFICIENTS:
            result += base * Fraction(c, mul*k + add)
    first_omitted = begin + tail_terms
    e = offset - 6 - 10*first_omitted
    assert e < 0
    # Each term <= sum |c| * 2^e, and later terms geometrically <= 1/1024.
    residual = Fraction(COEFF_SUM*1024, 1023 * (1 << (-e)))
    return result, residual


def extract(offset: int, hex_digits: int = 4, backend: str = 'cpu', device: int = 0, vram_mib:float=0.0) -> BellardResult:
    """Return certified hex digits of frac(2^offset*pi); raise if undecidable."""
    if not isinstance(offset, int) or not 0 <= offset <= MAX_OFFSET:
        raise ValueError(f'Binary offset must be between 0 and {MAX_OFFSET:,}')
    if not isinstance(hex_digits, int) or not 1 <= hex_digits <= 6:
        raise ValueError('Bellard certifies between 1 and 6 hex digits per request (subject to error bounds).')
    count = max(0, (offset-6)//10 + 1)
    if backend == 'cpu':
        prefix = _prefix_cpu(offset, count)
    elif backend == 'hybrid-bellard':
        # The CPU and GPU compute disjoint Bellard terms. Their exact modular
        # sums can be combined in any order. No fictitious 'GPU Chudnovsky'.
        if not count:
            prefix = 0
        else:
            from concurrent.futures import ThreadPoolExecutor
            cpu_count = count // 2
            gpu_count = count - cpu_count
            with ThreadPoolExecutor(max_workers=1) as executor:
                cpu_future = executor.submit(_prefix_cpu, offset, cpu_count, 0)
                gpu_value = _prefix_opencl(offset, gpu_count, device, vram_mib, cpu_count)
                prefix = (cpu_future.result() + gpu_value) & MASK
    elif backend == 'opencl-bellard':
        if not count:
            prefix = 0
        else:
            prefix = _prefix_opencl(offset, count, device, vram_mib)
    else:
        raise ValueError('Bellard backend must be cpu, opencl-bellard or hybrid-bellard')
    tail, remainder = _tail(offset, count)
    # Each independent fractional part was floored to an integer / SCALE.
    # Coefficients are signed; enclosing bound covers all 7 terms per k.
    error = Fraction(count*COEFF_SUM, SCALE) + remainder
    center = Fraction(prefix, SCALE) + tail
    factor = 16**hex_digits
    lower = (center-error)*factor
    upper = (center+error)*factor
    lo = lower.numerator // lower.denominator
    hi = upper.numerator // upper.denominator
    if lo != hi:
        raise ArithmeticError('Bellard interval crosses a hexadecimal digit boundary. '
                              'Try fewer --hex-digits or a different offset.')
    return BellardResult(offset, hex_digits, f'{lo % factor:0{hex_digits}x}', backend,
                         count, str(error))
