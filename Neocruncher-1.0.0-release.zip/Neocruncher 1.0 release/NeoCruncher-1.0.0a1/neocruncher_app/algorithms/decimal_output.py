# SPDX-License-Identifier: GPL-3.0-only
"""Divide-and-conquer decimal conversion, independent of global digit limits."""
def decimal_string(value):
    if value < 0:
        return '-' + decimal_string(-value)
    if value.bit_length() < 6000:
        return str(value)
    half = ((value.bit_length()*30103)//100000+2)//2
    high, low = divmod(value,10**half)
    if not high:
        return decimal_string(low)
    return decimal_string(high) + decimal_string(low).zfill(half)
