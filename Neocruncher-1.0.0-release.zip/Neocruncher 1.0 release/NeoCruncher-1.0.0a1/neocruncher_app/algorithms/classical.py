# SPDX-License-Identifier: GPL-3.0-only
"""Independent integer-only classical series backends.

Produces the *truncated*, not rounded, decimal expansion. Intervals are proven
conditional on the classical series identities and standard tail inequalities.
No Lean verification, runtime attestation, or GPU support is claimed here.
"""
from __future__ import annotations
from dataclasses import dataclass
from contextvars import ContextVar
from contextlib import contextmanager
import time
from math import isqrt, lgamma, log
import sys
import multiprocessing as mp
from concurrent.futures import ProcessPoolExecutor
from ..arithmetic import multiplications as mul, multiplications_batch, batch_multiplication_available
try:
    from gmpy2 import mpz as _host_int, isqrt as _host_isqrt
    HOST_INTEGER_ENGINE = 'GMP via gmpy2 (CPU finalization)'
except ImportError:
    _host_int, _host_isqrt = (int, isqrt)
    HOST_INTEGER_ENGINE = 'Python int (CPU finalization)'
_PHASES = ContextVar('neo041_phase_timings', default=None)
_PROGRESS = ContextVar('neocruncher_binary_split_progress', default=None)

class _MergeProgress:
    """Exact per-level merge count. NOT percentage of elapsed runtime/digits."""

    def __init__(self, emit):
        self.emit = emit
        self.total = 0
        self.done = 0
        self.last_update = 0.0
        self.level = None
        self.levels = 0
        self.overall_done = 0
        self.overall_total = 0

    def start(self, leaves):
        self.overall_total = max(0, leaves - 1)
        self.overall_done = 0
        self.levels = (max(1, leaves) - 1).bit_length()
        self.level = None
        self.total = self.overall_total
        self.done = 0
        self.last_update = 0.0
        self.report(force=True)

    def next_level(self, number, merges):
        self.level = number
        self.total = merges
        self.done = 0
        self.last_update = 0.0
        self.report(force=True)

    def report(self, force=False):
        now = time.monotonic()
        if not force and self.done < self.total and (now - self.last_update < 0.3):
            return
        self.last_update = now
        pct = 100.0 if not self.total else round(100 * self.done / self.total, 2)
        stage = f'Binary splitting · level {self.level}/{self.levels}' if self.level is not None else 'Binary splitting · host tree / selected arithmetic'
        self.emit({'stage': stage, 'phase_percent': pct if self.total else None, 'percent': None, 'progress_scope': 'current binary-splitting level' if self.level is not None else 'completed binary-splitting merges', 'work_done': self.done, 'work_total': self.total, 'level': self.level, 'levels_total': self.levels, 'global_merges_done': self.overall_done, 'global_merges_total': self.overall_total, 'certified_decimal_digits': 0})

    def merged(self):
        self.done += 1
        self.overall_done += 1
        self.report(force=self.done == self.total)

@contextmanager
def track_binary_splitting(emit):
    state = _MergeProgress(emit) if emit is not None else None
    token = _PROGRESS.set(state)
    try:
        yield state
    finally:
        _PROGRESS.reset(token)

def _mark_merge():
    state = _PROGRESS.get()
    if state is not None:
        state.merged()

@dataclass
class CertifiedDigits:
    digits: str
    detail: dict

def _render(value: int, places: int) -> str:
    begin = time.perf_counter()
    tracking = _PROGRESS.get()
    if tracking is not None:
        tracking.emit(dict(stage='Decimal conversion / CPU', percent=None, work_done=0, work_total=0, certified_decimal_digits=0))
    try:
        import gmpy2
        s = gmpy2.digits(gmpy2.mpz(value), 10).zfill(places + 1)
    except ImportError:
        from .decimal_output import decimal_string
        s = decimal_string(value).zfill(places + 1)
    result = s[:-places] + '.' + s[-places:]
    phases = _PHASES.get()
    if phases is not None:
        phases['decimal_conversion'] += time.perf_counter() - begin
    return result

def _certified(low: int, high: int, places: int, metadata: dict) -> CertifiedDigits:
    if low != high:
        raise ArithmeticError('Interval cannot certify the requested decimal prefix.')
    return CertifiedDigits(_render(low, places), {'certification': 'integer enclosing interval: identical decimal prefixes', 'host_integer_engine': HOST_INTEGER_ENGINE, **metadata})

def _chud_leaf(k: int) -> tuple[int, int, int]:
    if k == 0:
        return (1, 1, 13591409)
    p = (6 * k - 5) * (2 * k - 1) * (6 * k - 1)
    q = k * k * k * 10939058860032000
    t = (-1 if k % 2 else 1) * p * (13591409 + 545140134 * k)
    return (p, q, t)

def _bs_chud(a: int, b: int) -> tuple[int, int, int]:
    if b - a == 1:
        return _chud_leaf(a)
    m = (a + b) // 2
    p1, q1, t1 = _bs_chud(a, m)
    p2, q2, t2 = _bs_chud(m, b)
    result = (mul(p1, p2), mul(q1, q2), mul(t1, q2) + mul(p1, t2))
    _mark_merge()
    return result

def _ratio_leaf(index: int, family: str, q: int=0):
    if family == 'ln2':
        return (2 * index + 1, 9 * (2 * index + 3))
    if family == 'zeta3':
        k = index + 1
        return (-k ** 3, 2 * (2 * k + 1) * (k + 1) ** 2)
    if family == 'atan':
        return (-(2 * index + 1), q * q * (2 * index + 3))
    raise ValueError('Unsupported binary-splitting family')

def _bs_chunk_legacy(job):
    """Picklable task for independent CPU processes (true parallelism, no GIL)."""
    family, a, b, arg = job
    if family == 'chud':
        return _bs_chud(a, b)
    if family == 'rama':
        return _bs_rama(a, b)
    if family == 'exp':
        return _exp_pair(a, b, bool(arg))
    if family in ('ln2', 'zeta3', 'atan'):
        return _split_ratios(a, b, lambda k: _ratio_leaf(k, family, arg))
    raise ValueError('Unknown family')

def _bs_chunk(job):
    from .host_tree import task
    return task(job)

def _merge_chunks(family, left, right):
    if family in ('chud', 'rama', 'ln2', 'zeta3', 'atan'):
        p1, q1, t1 = left
        p2, q2, t2 = right
        products = multiplications_batch(((p1, p2), (q1, q2), (t1, q2), (p1, t2)))
        result = (products[0], products[1], products[2] + products[3])
    elif family == 'exp':
        p1, t1 = left
        p2, t2 = right
        products = multiplications_batch(((p1, p2), (t1, p2)))
        result = (products[0], products[1] + t2)
    else:
        raise ValueError('Unknown family')
    _mark_merge()
    return result

def _gpu_level_splitting(family: str, a: int, b: int, arg: int=0):
    """Bottom-up associative binary splitting with batched GPU products.

    Independent nodes within each tree level may be multiplied together.
    The parent sums are assembled on CPU from the exact GPU products; this is
    NOT an entirely GPU-resident arbitrary-precision constant solver.
    """
    if family == 'exp':
        nodes = [(k, -1 if arg and k & 1 else 1) for k in range(a, b)]
    elif family == 'chud':
        nodes = [_chud_leaf(k) for k in range(a, b)]
    elif family == 'rama':
        nodes = [_rama_leaf(k) for k in range(a, b)]
    elif family in ('ln2', 'zeta3', 'atan'):
        nodes = []
        for k in range(a, b):
            p, q = _ratio_leaf(k, family, arg)
            nodes.append((p, q, q))
    else:
        raise ValueError('Unrecognized GPU batch family')
    tracking = _PROGRESS.get()
    if tracking is not None:
        tracking.start(len(nodes))
    level_number = 0
    while len(nodes) > 1:
        level_number += 1
        if tracking is not None:
            tracking.next_level(level_number, len(nodes) // 2)
        merged = []
        pair_count = len(nodes) // 2
        for pair_start in range(0, pair_count, 256):
            start = 2 * pair_start
            end = 2 * min(pair_count, pair_start + 256)
            jobs = []
            for idx in range(start, end, 2):
                left, right = (nodes[idx], nodes[idx + 1])
                if family == 'exp':
                    p1, t1 = left
                    p2, t2 = right
                    jobs.extend(((p1, p2), (t1, p2)))
                else:
                    p1, q1, t1 = left
                    p2, q2, t2 = right
                    jobs.extend(((p1, p2), (q1, q2), (t1, q2), (p1, t2)))
            results = multiplications_batch(jobs)
            step = 2 if family == 'exp' else 4
            for idx in range(start, end, 2):
                j = (idx - start) // 2 * step
                if family == 'exp':
                    merged.append((results[j], results[j + 1] + nodes[idx + 1][1]))
                else:
                    merged.append((results[j], results[j + 1], results[j + 2] + results[j + 3]))
                _mark_merge()
        if len(nodes) & 1:
            merged.append(nodes[-1])
        nodes = merged
    return nodes[0]

def _gpu_streaming_splitting(family, a, b, arg=0):
    """Batch within bounded subtrees; keep only a logarithmic outer frontier."""
    from ..checkpoint_store import active_store, checkpointed_splitting
    store = active_store()
    if store is not None:
        return checkpointed_splitting(store, family, a, b, arg, _gpu_level_splitting, _merge_chunks, _PROGRESS.get(), _PROGRESS)
    if b - a <= 4096:
        return _gpu_level_splitting(family, a, b, arg)
    tracking = _PROGRESS.get()
    if tracking is not None:
        tracking.start(b - a)
    frontier = []
    for start in range(a, b, 4096):
        stop = min(b, start + 4096)
        token = _PROGRESS.set(None)
        try:
            node = _gpu_level_splitting(family, start, stop, arg)
        finally:
            _PROGRESS.reset(token)
        if tracking is not None:
            tracking.done += stop - start - 1
            tracking.overall_done += stop - start - 1
            tracking.report()
        height = 0
        while frontier and frontier[-1][0] == height:
            _, left = frontier.pop()
            node = _merge_chunks(family, left, node)
            height += 1
        frontier.append((height, node))
    node = frontier.pop()[1]
    while frontier:
        node = _merge_chunks(family, frontier.pop()[1], node)
    return node

def _parallel_bs_impl(family: str, a: int, b: int, workers: int=1, arg: int=0):
    """Partition exact binary splitting into CPU processes; merge in order.

    For tiny series, launching processes is slower, so calculate locally.
    Multi-process mode is still a valid choice; its implementation is exact.
    """
    n = b - a
    from ..cpu_library import ACTIVE as CPU_LIBRARY
    selected = CPU_LIBRARY.get()
    if selected is not None:
        from ..arithmetic.dispatch import _ACTIVE
        policy = _ACTIVE.get()
        if policy is None or policy.backend == 'cpu':
            from pykolm import Plan
            return selected.execute(Plan(family, a, b, arg, reduce=selected.reduce), workers)
    from ..checkpoint_store import active_store
    from ..arithmetic.dispatch import _ACTIVE
    if workers == 1 and (batch_multiplication_available() or active_store() is not None or (_ACTIVE.get() is not None and _ACTIVE.get().engine is not None)):
        from ..arithmetic.dispatch import _ACTIVE
        policy = _ACTIVE.get()
        if policy is not None and policy.backend == 'hybrid-ntt' and (active_store() is None):
            from .host_tree import split
            from concurrent.futures import ThreadPoolExecutor
            from collections import deque
            from ..cpu_library import HYBRID_CHUNK_TERMS
            requested_chunk = HYBRID_CHUNK_TERMS.get()
            chunk = requested_chunk or max(1024, 1 << max(0, ((n + 7) // 8 - 1).bit_length()))
            phases = _PHASES.get()
            if phases is not None:
                phases['hybrid_subtree_terms'] = chunk
            frontier = []
            tracking = _PROGRESS.get()
            if tracking is not None:
                tracking.start(b - a)
            with ThreadPoolExecutor(max_workers=1) as pool:
                pending = None
                for lo in range(a, b, chunk):
                    if pending is None:
                        pending = pool.submit(__import__('contextvars').copy_context().run, split, family, lo, min(b, lo + chunk), arg)
                    node = pending.result()
                    pending = pool.submit(__import__('contextvars').copy_context().run, split, family, lo + chunk, min(b, lo + 2 * chunk), arg) if lo + chunk < b else None
                    height = 0
                    while frontier and frontier[-1][0] == height:
                        node = _merge_chunks(family, frontier.pop()[1], node)
                        height += 1
                    frontier.append((height, node))
                    if tracking is not None:
                        internal_merges = min(chunk, b - lo) - 1
                        tracking.done += internal_merges
                        tracking.overall_done += internal_merges
                        tracking.report()
            node = frontier.pop()[1]
            while frontier:
                node = _merge_chunks(family, frontier.pop()[1], node)
            return node
        return _gpu_streaming_splitting(family, a, b, arg)
    if workers == 1 or n < max(1024, workers * 8):
        tracking = _PROGRESS.get()
        if tracking is not None:
            tracking.start(n)
        return _bs_chunk((family, a, b, arg))
    parts = min(workers, n)
    tasks = [(family, a + n * i // parts, a + n * (i + 1) // parts, arg) for i in range(parts)]
    context = mp.get_context('forkserver' if 'forkserver' in mp.get_all_start_methods() else 'spawn')
    phases = _PHASES.get()
    tracking = _PROGRESS.get()
    if tracking is not None:
        tracking.start(n)
    frontier = []
    wait_seconds = 0.0
    merge_seconds = 0.0
    payload = 0
    begin = time.perf_counter()
    with ProcessPoolExecutor(max_workers=parts, mp_context=context) as pool:
        futures = [pool.submit(_bs_chunk, t) for t in tasks]
        startup = time.perf_counter() - begin
        for i in range(parts):
            before = time.perf_counter()
            node = futures[i].result()
            futures[i] = None
            wait_seconds += time.perf_counter() - before
            payload += sum(((abs(v).bit_length() + 7) // 8 for v in node))
            height = 0
            before = time.perf_counter()
            while frontier and frontier[-1][0] == height:
                node = _merge_chunks(family, frontier.pop()[1], node)
                height += 1
            frontier.append((height, node))
            merge_seconds += time.perf_counter() - before
            if tracking is not None:
                internal_merges = tasks[i][2] - tasks[i][1] - 1
                tracking.done += internal_merges
                tracking.overall_done += internal_merges
                tracking.report(force=True)
        before = time.perf_counter()
        result = frontier.pop()[1]
        while frontier:
            result = _merge_chunks(family, frontier.pop()[1], result)
        merge_seconds += time.perf_counter() - before
    if phases is not None:
        phases.update(worker_submit_wall=startup, worker_ordered_wait_wall=wait_seconds, parent_merge_wall=merge_seconds, worker_result_payload_bytes=payload)
    return result

def _parallel_bs(family, a, b, workers=1, arg=0):
    begin = time.perf_counter()
    try:
        return _parallel_bs_impl(family, a, b, workers, arg)
    except PermissionError as exc:
        raise RuntimeError('CPU worker pool was blocked by the operating system. Choose one CPU worker or allow multiprocessing in this environment.') from exc
    finally:
        phases = _PHASES.get()
        if phases is not None:
            phases['binary_splitting'] += time.perf_counter() - begin

def _pi_chudnovsky(places: int, workers: int=1) -> CertifiedDigits:
    terms = max(2, places // 14 + 4)
    root_places = places + 24
    root_scale = _host_int(10) ** root_places
    root_floor = _host_isqrt(10005 * root_scale * root_scale)
    del root_scale
    for attempt in range(6):
        p, q, t = _parallel_bs('chud', 0, terms, workers)
        p, q, t = map(_host_int, (p, q, t))
        pnext, qnext, tnext = _chud_leaf(terms)
        q2 = q * qnext
        t2 = t * qnext + p * tnext
        if t <= 0 or t2 <= 0:
            raise ArithmeticError('Unexpected nonpositive Chudnovsky denominator')
        lq, lt, hq, ht = (q2, t2, q, t) if terms % 2 == 0 else (q, t, q2, t2)
        guard = _host_int(10) ** 24
        low = 426880 * root_floor * lq // (guard * lt)
        high = 426880 * (root_floor + 1) * hq // (guard * ht)
        if low == high:
            return _certified(low, high, places, {'algorithm': 'pi_chudnovsky', 'terms': terms, 'guard_digits': 24})
        terms += 2
    raise ArithmeticError('Insufficient Chudnovsky terms for requested digits')

def _rama_leaf(k: int) -> tuple[int, int, int]:
    if k == 0:
        return (1, 1, 1103)
    p = (4 * k - 3) * (4 * k - 2) * (4 * k - 1) * 4 * k
    q = k ** 4 * 396 ** 4
    return (p, q, p * (1103 + 26390 * k))

def _bs_rama(a: int, b: int) -> tuple[int, int, int]:
    if b - a == 1:
        return _rama_leaf(a)
    m = (a + b) // 2
    p1, q1, t1 = _bs_rama(a, m)
    p2, q2, t2 = _bs_rama(m, b)
    result = (mul(p1, p2), mul(q1, q2), mul(t1, q2) + mul(p1, t2))
    _mark_merge()
    return result

def _pi_ramanujan(places: int, workers: int=1) -> CertifiedDigits:
    terms = max(2, places // 8 + 5)
    root_places = places + 24
    root_scale = _host_int(10) ** root_places
    root_floor = _host_isqrt(2 * root_scale * root_scale)
    result_scale = _host_int(10) ** places
    for attempt in range(6):
        p, q, t = _parallel_bs('rama', 0, terms, workers)
        p, q, t = map(_host_int, (p, q, t))
        pn, qn, _ = _rama_leaf(terms)
        q2 = q * qn
        t2 = t * qn + 2 * p * pn * (1103 + 26390 * terms)
        lo = 9801 * q2 * result_scale * root_scale // (2 * (root_floor + 1) * t2)
        hi = 9801 * q * result_scale * root_scale // (2 * root_floor * t)
        if lo == hi:
            return _certified(lo, hi, places, {'algorithm': 'pi_ramanujan', 'terms': terms, 'guard_digits': 24})
        terms += 2
    raise ArithmeticError('Insufficient Ramanujan terms for requested digits')

def _split_ratios(a: int, b: int, leaf) -> tuple[int, int, int]:
    """Sum of the first factors in a rational hypergeometric recurrence.

    Leaves are (p_k, q_k, q_k): the current term equals one and p/q is
    the ratio to the next term. Combined representation is T/Q and P/Q
    for the sum of normalized terms and the next normalized term.
    """
    if b - a == 1:
        p, q = leaf(a)
        return (p, q, q)
    m = (a + b) // 2
    p1, q1, t1 = _split_ratios(a, m, leaf)
    p2, q2, t2 = _split_ratios(m, b, leaf)
    result = (mul(p1, p2), mul(q1, q2), mul(t1, q2) + mul(p1, t2))
    _mark_merge()
    return result

def _exp_pair(a: int, b: int, alternating: bool=False) -> tuple[int, int]:
    """Return (n!, sum_{k=a}^{b-1} sign(k)*n!/k!) over integer k>=1."""
    if b - a == 1:
        return (a, -1 if alternating and a & 1 else 1)
    m = (a + b) // 2
    p1, t1 = _exp_pair(a, m, alternating)
    p2, t2 = _exp_pair(m, b, alternating)
    result = (mul(p1, p2), mul(t1, p2) + t2)
    _mark_merge()
    return result

def _exp_terms(places: int) -> int:
    """Choose n so 2/(n+1)! < 10^-(places+20), using lgamma."""
    target = (places + 21) * log(10)
    high = 16
    while lgamma(high + 2) <= target:
        high *= 2
    low = 1
    while low + 1 < high:
        m = (low + high) // 2
        if lgamma(m + 2) > target:
            high = m
        else:
            low = m
    return high

def _e_taylor(places: int, workers: int=1) -> CertifiedDigits:
    scale = _host_int(10) ** places
    n = _exp_terms(places)
    for _ in range(8):
        fact, extra = _parallel_bs('exp', 1, n + 1, workers, 0)
        fact, extra = map(_host_int, (fact, extra))
        quotient, remainder = divmod(extra * scale, fact)
        lo = scale + quotient
        if remainder * (n + 1) + 2 * scale < fact * (n + 1):
            return _certified(lo, lo, places, {'algorithm': 'e_taylor', 'terms': n + 1, 'method': 'blocked binary splitting; one-division tail certificate'})
        n += 2
    raise ArithmeticError('Unable to certify e Taylor interval')

def _e_inverse(places: int, workers: int=1) -> CertifiedDigits:
    scale = _host_int(10) ** places
    n = _exp_terms(places)
    for _ in range(8):
        fact, extra = _parallel_bs('exp', 1, n + 1, workers, 1)
        fact, extra = map(_host_int, (fact, extra))
        numerator = fact + extra
        denom = fact * (n + 1)
        next_num = numerator * (n + 1) + (-1 if n + 1 & 1 else 1)
        low = min(numerator * (n + 1), next_num)
        high = max(numerator * (n + 1), next_num)
        if low <= 0:
            raise ArithmeticError('Unexpected negative exp(-1) bound')
        lo = denom * scale // high
        hi = denom * scale // low
        if lo == hi:
            return _certified(lo, hi, places, {'algorithm': 'e_inverse', 'terms': n + 2, 'method': 'binary splitting'})
        n += 2
    raise ArithmeticError('Unable to certify reciprocal Taylor interval')

def _sqrt2(places: int, workers: int=1) -> CertifiedDigits:
    scale = _host_int(10) ** places
    value = _host_isqrt(2 * scale * scale)
    return _certified(value, value, places, {'algorithm': 'sqrt2_integer', 'method': 'isqrt: exact decimal floor'})

def _phi(places: int, workers: int=1) -> CertifiedDigits:
    scale = _host_int(10) ** places
    value = (scale + _host_isqrt(5 * scale * scale)) // 2
    return _certified(value, value, places, {'algorithm': 'phi_integer', 'method': 'integer sqrt(5): exact decimal floor'})

def _ln2(places: int, workers: int=1) -> CertifiedDigits:

    def leaf(k):
        return (2 * k + 1, 9 * (2 * k + 3))
    scale = _host_int(10) ** places
    n = max(2, int((places + 24) * log(10) / log(9)) + 1)
    for _ in range(8):
        p, q, t = _parallel_bs('ln2', 0, n, workers)
        p, q, t = map(_host_int, (p, q, t))
        lo = 2 * t * scale // (3 * q)
        hi = (2 * t + 3 * p) * scale // (3 * q)
        if lo == hi:
            return _certified(lo, hi, places, {'algorithm': 'ln2_atanh', 'terms': n, 'method': 'binary splitting'})
        n += 8
    raise ArithmeticError('Unable to certify ln2 interval')

def _zeta3(places: int, workers: int=1) -> CertifiedDigits:

    def leaf(index):
        k = index + 1
        return (-k ** 3, 2 * (2 * k + 1) * (k + 1) ** 2)
    scale = _host_int(10) ** places
    n = max(2, int((places + 24) * log(10) / log(4)) + 1)
    for _ in range(8):
        p, q, t = _parallel_bs('zeta3', 0, n, workers)
        p, q, t = map(_host_int, (p, q, t))
        lo = 5 * min(t, t + p) * scale // (4 * q)
        hi = 5 * max(t, t + p) * scale // (4 * q)
        if lo == hi:
            return _certified(lo, hi, places, {'algorithm': 'zeta3_apery', 'terms': n, 'method': 'binary splitting'})
        n += 8
    raise ArithmeticError('Unable to certify Apéry interval')

def _atan_interval(q: int, places: int, workers: int=1) -> tuple[int, int]:
    """Certified arctan(1/q) at scale 10^places via alternating ratio BS."""
    from math import log
    n = max(2, int((places + 15) * log(10) / (2 * log(q))) + 2)
    scale = _host_int(10) ** places
    for _ in range(6):

        def leaf(k):
            return (-(2 * k + 1), q * q * (2 * k + 3))
        p, den, t = _parallel_bs('atan', 0, n, workers, q)
        p, den, t = map(_host_int, (p, den, t))
        denominator = q * den
        a = min(t, t + p) * scale
        b = max(t, t + p) * scale
        lower = a // denominator
        upper = (b + denominator - 1) // denominator
        if upper - lower <= 2:
            return (lower, upper)
        n += 4
    raise ArithmeticError('Unable to certify Machin arctan interval')

def _pi_machin_cpu(places: int, workers: int=1) -> CertifiedDigits:
    guard = 24
    lo5, hi5 = _atan_interval(5, places + guard, workers)
    lo239, hi239 = _atan_interval(239, places + guard, workers)
    lo = (16 * lo5 - 4 * hi239) // 10 ** guard
    hi = (16 * hi5 - 4 * lo239) // 10 ** guard
    return _certified(lo, hi, places, {'algorithm': 'pi_machin', 'method': 'binary splitting', 'guard_digits': guard})
CPU_FUNCTIONS = {'pi_chudnovsky': _pi_chudnovsky, 'pi_machin': _pi_machin_cpu, 'pi_ramanujan': _pi_ramanujan, 'e_taylor': _e_taylor, 'e_inverse': _e_inverse, 'sqrt2_integer': _sqrt2, 'phi_integer': _phi, 'ln2_atanh': _ln2, 'zeta3_apery': _zeta3}

def compute_cpu(algorithm: str, places: int, workers: int=1, progress=None) -> CertifiedDigits:
    if type(places) is not int or places < 1:
        raise ValueError('Precision must be a positive integer.')
    from ..cpu_options import available_processes
    if type(workers) is not int or not 1 <= workers <= available_processes():
        raise ValueError(f'CPU worker count must be 1..{available_processes()} on this computer.')
    if workers > 1 and algorithm in ('sqrt2_integer', 'phi_integer'):
        raise ValueError('This integer-root algorithm is single-process only; use --workers 1.')
    try:
        function = CPU_FUNCTIONS[algorithm]
    except KeyError:
        raise NotImplementedError(f'No classical CPU implementation for {algorithm}') from None
    phases = dict(binary_splitting=0.0, decimal_conversion=0.0)
    token = _PHASES.set(phases)
    begin = time.perf_counter()
    try:
        with track_binary_splitting(progress):
            result = function(places, workers)
        phases['total_algorithm'] = time.perf_counter() - begin
        phases['other_cpu_and_orchestration'] = max(0.0, phases['total_algorithm'] - phases['binary_splitting'] - phases['decimal_conversion'])
        result.detail['execution_metrics'] = {k: phases[k] for k in ('worker_result_payload_bytes', 'hybrid_subtree_terms') if k in phases}
        result.detail['phase_wall_seconds'] = {k: v for k, v in phases.items() if k not in ('worker_result_payload_bytes', 'hybrid_subtree_terms')}
        result.detail['phase_timing_scope'] = 'Host wall time; splitting includes packing, GPU waits, verification, assembly, checkpoint I/O. Not device kernel-only timing.'
        return result
    finally:
        _PHASES.reset(token)
