# SPDX-License-Identifier: GPL-3.0-only
"""Readable, opt-in GPU driver dependency setup and short actual GPU test.

No changes to system packages or virtual environment are performed without
explicit confirmation. Never installs a proprietary graphics driver itself.
"""
from __future__ import annotations
import os
import shutil
import subprocess
import sys
from .hardware import diagnosis


def recommended_commands(info=None):
    info=diagnosis() if info is None else info
    vendors={g.get('vendor') for g in info.get('pci_gpus',[])}
    if 'AMD' in vendors:
        packages=['mesa-opencl-icd','ocl-icd-libopencl1','clinfo'] if not info.get('opencl_icd_files') else []
        reason='AMD Mesa Rusticl (the existing amdgpu display driver is left unchanged)'
    elif 'Intel' in vendors:
        packages=['intel-opencl-icd','ocl-icd-libopencl1','clinfo'] if not info.get('opencl_icd_files') else []
        reason='Intel OpenCL compute runtime'
    elif 'NVIDIA' in vendors:
        packages=[]
        reason='NVIDIA: do not replace the GPU driver automatically; install matching distro/vendor OpenCL runtime'
    else:
        packages=[]
        reason='GPU vendor not detected: cannot safely choose a driver package'
    # PyOpenCL is installed in the current active Python environment, not
    # into an arbitrary system Python, only when already in a virtualenv.
    in_venv=sys.prefix!=getattr(sys,'base_prefix',sys.prefix)
    if not in_venv and not info.get('pyopencl_installed'):
        packages+=['python3-pyopencl']
    python_cmd=[sys.executable,'-m','pip','install','pyopencl','numpy'] if in_venv and not info.get('pyopencl_installed') else None
    return {'apt_packages':packages, 'pip_command':python_cmd,
            'apt_command':['sudo','apt','install',*packages] if packages else None,
            'reason':reason,'in_venv':in_venv}


def explain(info=None):
    info=diagnosis() if info is None else info
    commands=recommended_commands(info)
    vendors=[f"{g.get('vendor')} ({g.get('driver','?')} kernel driver)" for g in info.get('pci_gpus',[])]
    print('\n  GPU SETUP — PREPARATION (NO CHANGES MADE)')
    print('  Graphics hardware: '+(', '.join(vendors) or 'not visible'))
    print('  PyOpenCL Python binding: '+('available' if info.get('pyopencl_installed') else 'missing'))
    print('  OpenCL GPU runtime: '+('ready' if info.get('opencl_gpus') else 'not ready'))
    print('  '+commands['reason'])
    if commands['apt_command']:print('  OS packages: '+' '.join(commands['apt_command']))
    if commands['pip_command']:print('  Python packages: '+' '.join(commands['pip_command']))
    if not commands['apt_command'] and not commands['pip_command']:
        print('  Inspect OpenCL runtime with clinfo -l; no safe automatic package choice.')
    if info.get('opencl_icd_files') and not info.get('opencl_gpus'):
        print('  An OpenCL provider exists but cannot expose a GPU here; check group/device access and clinfo -l.')
    print('  No GPU driver will be installed/replaced without permission.')
    return commands


def apply_fix(info=None, *, ask=None, runner=subprocess.run):
    """Run fixed package commands only after exact y/Y authorization per command."""
    if ask is None:ask=input
    commands=explain(info)
    for command in (commands['apt_command'],commands['pip_command']):
        if not command:continue
        print('\n  Planned command: '+' '.join(command))
        consent=ask('  Authorize THIS installation? [y/N]: ').strip().lower()
        if consent not in ('y','yes'):
            print('  Skipped; nothing changed for this step.')
            continue
        if command[0]=='sudo' and (sys.platform!='linux' or shutil.which('apt') is None or shutil.which('sudo') is None):
            print('  apt/sudo unavailable: follow the manual instructions.')
            continue
        try:
            code=runner(command,check=False).returncode
            print('  Installation finished.' if code==0 else f'  Installer exit code {code}; check messages above.')
        except OSError as exc:print('  Installation failed: '+str(exc))
    return diagnosis()


def recovery_menu(info=None, *, ask=None):
    if ask is None: ask=input
    info=diagnosis() if info is None else info
    explain(info)
    print('\n  [1] Try to configure GPU (asks permission before EVERY install)')
    print('  [2] Show safe setup commands / explanation')
    print('  [3] Retry GPU detection')
    print('  [4] Continue using CPU')
    print('  [b] Back to compute-mode selection')
    choice=ask('  Choice [4]: ').strip().lower() or '4'
    if choice=='1':
        apply_fix(info,ask=ask)
        return 'retry'
    if choice=='2':
        explain(info)
        return 'retry'
    if choice=='3':return 'retry'
    if choice in ('b','back','..'):return 'back'
    return 'cpu'


def interactive_setup():
    info=diagnosis()
    if info.get('opencl_gpus'):
        print('  OpenCL GPU already available! Use --gpu-self-test.')
        return True
    action=recovery_menu(info)
    if action=='retry':
        info=diagnosis()
        print('  GPU detected!' if info.get('opencl_gpus') else '  GPU not ready yet. See --diagnose for details.')
    return bool(info.get('opencl_gpus'))


def gpu_self_test():
    """Explicit correctness exercise of BOTH full GPU-pure paths."""
    from .core import compute, independently_verify
    for engine in ('native','kolmogorov'):
        for constant,key in (('e','e_taylor'),('pi','pi_chudnovsky')):
            text,report=compute(constant,100,key,'opencl-ntt',engine=engine)
            independently_verify(text,constant,100)
            if not report['details'].get('gpu_pure'):raise ArithmeticError('Non-pure GPU route')
            print(f'  PASS: {engine} / {constant} / GPU-pure / 100 decimal places')
    return True
