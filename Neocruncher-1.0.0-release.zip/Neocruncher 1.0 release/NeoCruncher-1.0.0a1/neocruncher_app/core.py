# SPDX-License-Identifier: GPL-3.0-only
"""Resource-conscious orchestration: no UI dependencies in the numerical process."""
from __future__ import annotations
import hashlib
import json
import time
from pathlib import Path
from .catalog import select_algorithm
from .algorithms.classical import compute_cpu
APP_VERSION = '1.0.0a1'

def _compute(constant: str, digits: int, algorithm: str | None=None, backend: str='cpu', *, device: int=0, ram_mib: float=0.0, vram_mib: float=0, workers: int=1, checkpoint_dir=None, checkpoint_terms=512, progress=None, gpu_batch_size=1024, engine='native', hybrid_policy='fixed', calibration_file=None):
    """Return (TXT without newline, manifest); never silently change backend."""
    from .engine_choice import validate_engine
    validate_engine('gpu' if backend == 'opencl-ntt' else 'cpu' if backend == 'cpu' else 'both', engine)
    if hybrid_policy != 'fixed' and backend != 'hybrid-ntt':
        raise ValueError('Calibrated policy is only available for hybrid-ntt')
    if calibration_file and hybrid_policy != 'calibrated':
        raise ValueError('Calibration file requires calibrated policy')
    if backend in ('opencl-ntt', 'hybrid-ntt'):
        try:
            import kolmogorov
        except ImportError as exc:
            raise RuntimeError('Kolmogorov is missing in this Python environment. Run the root install.sh --gpu and root launcher.') from exc
        if kolmogorov.__version__ != APP_VERSION:
            raise RuntimeError(f'Bundle version mismatch: NeoCruncher {APP_VERSION}, Kolmogorov {kolmogorov.__version__}. Reinstall both together.')
    spec = select_algorithm(constant, algorithm)
    if backend not in spec.backends:
        raise ValueError(f'{spec.key} does not support {backend}. Supported: {", ".join(spec.backends)}. This backend is not implemented for the selected algorithm.')
    if type(digits) is not int or digits < 1:
        raise ValueError('Precision must be a positive integer.')
    start = time.perf_counter()
    if backend in ('opencl-ntt', 'hybrid-ntt'):
        if progress:
            progress(dict(stage='OpenCL subprocess compile/execute preflight', percent=None))
        from kolmogorov.doctor import probe
        probe(device)
    if backend in ('opencl-ntt', 'hybrid-ntt') and workers != 1:
        raise ValueError('GPU NTT currently requires --workers 1.')
    if backend not in ('cpu', 'opencl-ntt', 'hybrid-ntt') and workers != 1:
        raise ValueError('CPU --workers applies only to --backend cpu.')
    if backend == 'cpu':
        if checkpoint_dir and spec.key == 'pi_chudnovsky':
            from .checkpoints import chudnovsky_resume
            result = chudnovsky_resume(digits, checkpoint_dir, chunk_size=checkpoint_terms, progress=progress, workers=workers)
        elif spec.status == 'reference':
            if workers != 1:
                raise ValueError('Numerical reference algorithms use CPU mono only.')
            from .algorithms.reference import compute_reference
            result = compute_reference(spec.key, digits)
        else:
            result = compute_cpu(spec.key, digits, workers=workers, progress=progress)
        text = result.digits
        detail = result.detail.copy()
        engine_description = 'Python arbitrary-precision integers / CPU'
    elif backend == 'opencl-ntt':
        if checkpoint_dir:
            raise ValueError('GPU-pure checkpoints are not implemented; use RAM/VRAM storage or explicit hybrid')
        from .arithmetic.resident import calculate
        text, detail = calculate(spec.key, digits, engine, device, ram_mib, vram_mib, progress)
        engine_description = f'{engine} GPU-pure arithmetic; CPU control/storage only'
    elif backend == 'hybrid-ntt':
        from .arithmetic import use_arithmetic, operation_stats
        with use_arithmetic(backend, device=device, vram_mib=vram_mib, threshold=0 if backend == 'opencl-ntt' else 16384, batch_size=gpu_batch_size, engine_choice=engine, hybrid_policy=hybrid_policy, calibration_file=calibration_file) as arithmetic:
            arithmetic.engine.progress = progress
            from .checkpoint_store import use_checkpoint_store
            node_limit = min(4 * 1024 ** 3, int(ram_mib * 1024 ** 2 * 0.4)) if ram_mib else 1024 ** 3
            with use_checkpoint_store(checkpoint_dir, chunk_terms=checkpoint_terms, max_node_bytes=node_limit) as store:
                result = compute_cpu(spec.key, digits, workers=1, progress=progress)
                checkpoint_stats = dict(store.stats) if store else None
        text = result.digits
        detail = result.detail.copy()
        detail['arithmetic'] = operation_stats(arithmetic)
        detail['binary_checkpoints'] = checkpoint_stats
        if arithmetic.gpu_count == 0:
            detail['acceleration_warning'] = 'No GPU product executed: CPU routing, zero identities, or checkpoint reuse. Inspect routing/checkpoint metrics.'
        engine_description = f'{engine} exact OpenCL arithmetic ({arithmetic.engine.device.name}); CPU algorithm orchestration'
    else:
        raise ValueError(f'Unknown backend: {backend}')
    elapsed = time.perf_counter() - start
    if progress and (not checkpoint_dir or backend in ('opencl-ntt', 'hybrid-ntt')):
        certified = digits if spec.status == 'ready' else 0
        progress({'stage': 'calculation finished', 'percent': 100.0, 'work_done': 1, 'work_total': 1, 'certified_decimal_digits': certified})
    return (text, {'program': 'NeoCruncher', 'version': APP_VERSION, 'constant': constant, 'algorithm': spec.key, 'algorithm_label': spec.title, 'backend': backend, 'engine': engine_description, 'engine_id': engine, 'cpu_workers': workers if backend == 'cpu' else 1 if backend in ('opencl-ntt', 'hybrid-ntt') else None, 'cpu_parallel_policy': 'adaptive: requested workers; fewer than 1,024 binary-splitting terms run serially' if backend == 'cpu' else ('GPU-pure arithmetic; CPU control/storage only' if backend == 'opencl-ntt' else 'CPU subtrees + GPU upper products; bounded CPU/GPU overlap') if backend in ('opencl-ntt', 'hybrid-ntt') else None, 'decimal_places': digits, 'rounding': 'truncation toward zero', 'seconds': elapsed, 'verification_scope': 'NOT CERTIFIED: mpmath numerical reference with guard precision only' if spec.status == 'reference' else 'numerical interval from the running implementation; no Lean proof and no authenticated CPU/GPU/timing claims', 'details': detail, 'sha256': _text_digest(text)})

def independently_verify(text: str, constant: str, digits: int) -> str:
    """Independent CPU mpmath validation; separate timing from calculation."""
    from .verification import verify_text
    return verify_text(text, constant, digits)

def save_result(output: str | Path, text: str, report: dict) -> tuple[Path, Path]:
    """Exclusive creation: will not overwrite TXT or JSON. Hash includes LF terminator."""
    io_begin = time.perf_counter()
    path = Path(output)
    report_path = Path(str(path) + '.json')
    if path.suffix.lower() != '.txt':
        raise ValueError('The result filename must have a .txt extension')
    if path.exists() or report_path.exists():
        raise FileExistsError('TXT or JSON file already exists. Choose another --output path.')
    path.parent.mkdir(parents=True, exist_ok=True)
    import shutil
    encoded_report = json.dumps(report, ensure_ascii=False).encode('utf8')
    required = len(text) + 1 + len(encoded_report) + 65536
    if required > shutil.disk_usage(path.parent).free:
        raise OSError('Insufficient free disk space for result and report')
    created_txt = False
    try:
        with path.open('x', encoding='ascii', newline='\n') as f:
            created_txt = True
            for start in range(0, len(text), 1024 * 1024):
                chunk = text[start:start + 1024 * 1024]
                if len(chunk) + 65536 > shutil.disk_usage(path.parent).free:
                    raise OSError('Disk space exhausted while saving result')
                f.write(chunk)
            f.write('\n')
        if _file_digest(path) != report['sha256']:
            raise IOError('TXT SHA-256 readback mismatch')
        report['output_txt_write_and_readback_seconds'] = time.perf_counter() - io_begin
        with report_path.open('x', encoding='utf-8') as f:
            json.dump(report, f, ensure_ascii=False, indent=2)
            f.write('\n')
    except Exception:
        if created_txt and path.exists() and (not report_path.exists()):
            path.unlink()
        raise
    return (path, report_path)

def _text_digest(text):
    digest = hashlib.sha256()
    for start in range(0, len(text), 1024 * 1024):
        digest.update(text[start:start + 1024 * 1024].encode('ascii'))
    digest.update(b'\n')
    return digest.hexdigest()

def _file_digest(path):
    digest = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()

def compute(*args, cpu_library='legacy', pykolm_reduce=True, hybrid_chunk_terms=0, **kwargs):
    """Explicit experimental policy around the unchanged certified finalization."""
    from .cpu_library import use_library, HYBRID_CHUNK_TERMS
    constant = args[0] if args else kwargs.get('constant', 'pi')
    algorithm = args[2] if len(args) > 2 else kwargs.get('algorithm')
    backend = args[3] if len(args) > 3 else kwargs.get('backend', 'cpu')
    if cpu_library != 'legacy':
        spec = select_algorithm(constant, algorithm)
        if backend not in ('cpu', 'hybrid-ntt'):
            raise ValueError('PyKolm supports CPU or explicit hybrid CPU subtrees; GPU-pure is unchanged')
        if spec.key not in ('pi_chudnovsky', 'e_taylor', 'e_inverse'):
            raise ValueError('PyKolm prototype supports pi_chudnovsky, e_taylor and e_inverse only')
        if kwargs.get('checkpoint_dir') or kwargs.get('peer'):
            raise ValueError('PyKolm does not yet support checkpoint reuse')
    if type(hybrid_chunk_terms) is not int or hybrid_chunk_terms < 0:
        raise ValueError('hybrid_chunk_terms must be nonnegative')
    chunk_token = HYBRID_CHUNK_TERMS.set(hybrid_chunk_terms)
    try:
        with use_library(cpu_library, reduce=pykolm_reduce, progress=kwargs.get('progress')) as session:
            text, report = _compute(*args, **kwargs)
    finally:
        HYBRID_CHUNK_TERMS.reset(chunk_token)
    report['cpu_library'] = cpu_library
    if session is not None:
        report['details']['pykolm'] = dict(session.metrics, version='0.1.0', factor_reduction=pykolm_reduce, reduction_max_node_bits=8192, metric_scope='Integer payloads exclude allocator, temporaries, process copies and decimal text; not peak RAM')
        report['cpu_parallel_policy'] = 'PyKolm bounded ordered subtree executor; n<4096 terms serial; at most requested workers pending'
    try:
        import resource, sys
        report['process_high_water_rss_bytes'] = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * (1 if sys.platform == 'darwin' else 1024)
    except (ImportError, AttributeError, OSError):
        report['process_high_water_rss_bytes'] = None
    report['process_high_water_rss_scope'] = 'OS process lifetime high-water; excludes descendants and VRAM; may include imports/prior computations'
    return (text, report)
