# SPDX-License-Identifier: GPL-3.0-only
"""Reusable, terminal-friendly decimal precision reference table."""
from __future__ import annotations
from .prefs import paint

# Short forms and the numeric parser both use decimal SI powers of ten.
DECIMAL_EXAMPLES = (
    (10_000, '10k'),
    (100_000, '100k'),
    (1_000_000, '1M'),
    (10_000_000, '10M'),
    (1_000_000_000, '1B'),
    (1_000_000_000_000, '1T'),
)


def precision_reference(*, colors=None):
    label_width = max(len(f'{value:,}') for value, _ in DECIMAL_EXAMPLES)
    short_width = 12
    head_left = 'DECIMAL DIGITS'
    head_right = 'ABBREVIATION'
    # Only color cell contents, not padding: escape codes must not shift columns.
    def row(left, right, *, accent=False):
        left_cell = f'{left:>{label_width}}'
        right_cell = f'{right:<{short_width}}'
        if accent:
            left_cell = paint(left_cell, '37', enabled=colors)
            right_cell = paint(right_cell, '1;36', enabled=colors)
        return f'  {left_cell}  │  {right_cell}'
    divider = f'  {"─" * label_width}──┼──{"─" * short_width}'
    result = [
        '  DECIMAL PRECISION',
        '  Enter the required number of digits after the decimal point.',
        '',
        row(head_left, head_right),
        divider,
    ]
    result.extend(row(f'{value:,}', short, accent=True) for value, short in DECIMAL_EXAMPLES)
    result.extend([
        '',
        '  Suffixes: k = 10^3, M = 10^6, B = 10^9, T = 10^12.',
        '  Also accepted: scientific notation (5.4e20), powers (2^19).',
        '  Execution feasibility is assessed before computation.',
        '',
    ])
    return '\n'.join(result)
