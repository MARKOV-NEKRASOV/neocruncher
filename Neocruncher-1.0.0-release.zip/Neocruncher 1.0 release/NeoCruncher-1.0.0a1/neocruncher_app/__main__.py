# SPDX-License-Identifier: GPL-3.0-only
from .cli import main
import sys
if __name__ == '__main__':
    try:sys.exit(main())
    except (OSError,ArithmeticError,ValueError,NotImplementedError,RuntimeError,MemoryError,ImportError) as exc:
        print(f'ERROR: {exc}',file=sys.stderr);sys.exit(1)
    except KeyboardInterrupt:
        print('\nCancelled.',file=sys.stderr);sys.exit(130)
