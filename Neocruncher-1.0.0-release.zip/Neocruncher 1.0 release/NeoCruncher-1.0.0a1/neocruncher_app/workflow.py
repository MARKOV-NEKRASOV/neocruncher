# SPDX-License-Identifier: GPL-3.0-only
"""Tiny interactive state machine with real Back navigation.

GPU discovery runs after a user explicitly selects GPU/hybrid, BEFORE
choosing an algorithm or starting a numerical calculation.
"""
from __future__ import annotations
from .catalog import ALGORITHMS
from .compute_modes import compatible_backend, find_gpus
from .precision import parse_count, parse_target_count

class Back(Exception):
    """Return one screen up without aborting the whole program."""


def ask(prompt, default=None, *, low=None, high=None):
    from .prefs import paint
    while True:
        suffix='  '+paint(f'[{default}]','36') if default not in (None,'') else ''
        print(paint('  [B] Back','2;36'))
        response=input(f'  {prompt}{suffix}  > ').strip()
        if response.lower() in ('b','back','..'):raise Back()
        if not response and default is not None:response=str(default)
        if low is None:return response
        try:return parse_count(response,minimum=low,maximum=high) if high is not None or low==0 else parse_target_count(response)
        except ValueError as exc:print('  '+str(exc))

def configure(a, *, parallel=False):
    from .preflight import print_preflight
    from .budgets import check_budget
    from .cpu_options import topology, select_workers
    from pathlib import Path
    while True:
        try:
            from .prefs import paint
            print(paint('\n  PRE-COMPUTATION | JOB REVIEW','1;36'))
            label=a.expression or a.algorithm or a.constant
            print(f'  {label} | {a.digits:,} decimals | {a.backend} | {a.engine}')
            if a.cpu_library!='legacy':print(f'  Experimental CPU provider: {a.cpu_library}')
            if a.bellard_offset is not None:print(f'  HEX block: {a.hex_digits} digits at binary offset {a.bellard_offset}')
            capacity_ok=True
            try:
                print_preflight(digits=a.digits,algorithm='custom_expression' if a.expression else a.algorithm,
                    backend=a.backend,workers=a.workers,ram_budget=a.ram_mib,vram_budget=a.vram_mib,
                    output=a.output or 'benchmark.json',device=a.device,disk_budget_gib=a.disk_budget_gib)
            except (ValueError,RuntimeError) as exc:
                capacity_ok=False;print('  Capacity: '+str(exc))
            if a.backend=='cpu':
                t=topology()
                print(f"  CPU: {t['physical_cores'] or 'unknown'} available physical cores | {t['logical_threads']} available logical threads")
                print(f'  Requested worker processes: {a.workers}. Small jobs may use fewer.')
            print(f'  Limits MiB: RAM {a.ram_mib or "auto"} | VRAM {a.vram_mib or "auto"} | disk {a.disk_budget_gib*1024 or "auto"}')
            print(f'  Output: {a.benchmark_output or "no file" if a.benchmark else a.output}')
            prefix=getattr(a,'verify_prefix',0)
            print(f'  Verification: {"full" if a.verify else (f"first {prefix:,} decimals ONLY" if prefix else "off")}')
            if a.digits>100000:print('  Independent full verification limit: 100,000 decimals. Prefix verification is available with [5].')
            print('  [1] Start  [2] RAM / VRAM / disk  [3] CPU workers')
            print('  [4] Output  [5] Verification  [6] Precision'+('  [7] Repetitions / warmup' if a.benchmark else '')+('  [8] CPU library (experimental)' if a.algorithm in ('pi_chudnovsky','e_taylor','e_inverse') and a.backend in ('cpu','hybrid-ntt') else ''))
            choice=ask('Action','1')
            if choice=='1':
                from .result_verification import request_scope
                request_scope(a)
                if not capacity_ok:
                    print('  Adjust precision, storage or resource limits before starting.');continue
                check_budget(a.digits,'custom_expression' if a.expression else a.algorithm,a.backend,
                             a.ram_mib,a.vram_mib,a.workers,a.device)
                if not a.benchmark and (Path(a.output).exists() or Path(a.output+'.json').exists()):
                    print('  Output exists. Choose [4] and a new filename.');continue
                a.preflight_accepted=True
                return True
            if choice=='2':
                fields=ask('RAM VRAM DISK in MiB (0 = automatic)','0 0 0').replace(',',' ').split()
                if len(fields)!=3:raise ValueError('Enter three nonnegative values.')
                ram,vram,disk=(parse_count(v,minimum=0) for v in fields)
                if a.backend=='cpu' and vram:raise ValueError('VRAM must be zero for CPU mode.')
                a.ram_mib=ram;a.vram_mib=vram;a.disk_budget_gib=disk/1024
            elif choice=='3':
                if parallel:a.workers=select_workers(ask)
                else:print('  This algorithm/backend uses one coordinator process.')
            elif choice=='4':
                if a.benchmark:a.benchmark_output=ask('JSON report filename (blank = none)','') or None
                else:
                    filename=ask('TXT filename',a.output)
                    a.output=filename if filename.endswith('.txt') else filename+'.txt'
            elif choice=='5':
                spec=next((s for s in ALGORITHMS if s.key==a.algorithm),None)
                if a.expression or not spec or spec.status!='ready' or (spec.key=='pi_bellard' and a.backend=='cpu'):
                    print('  Independent verification is unavailable for this method.')
                else:
                    from .verification import MAX_VERIFY_DIGITS
                    limit=min(a.digits,MAX_VERIFY_DIGITS)
                    print(f'  [0] Off  [1] Full (max {MAX_VERIFY_DIGITS:,})  [2] First N decimals only')
                    mode=ask('Verification mode','0')
                    if mode=='0':a.verify=False;a.verify_prefix=0
                    elif mode=='1':
                        if a.digits>MAX_VERIFY_DIGITS:raise ValueError('Full verification unavailable at this precision; select prefix mode or off')
                        a.verify=True;a.verify_prefix=0
                    elif mode=='2':
                        a.verify_prefix=ask('Decimal prefix to verify',str(limit),low=1,high=limit);a.verify=False
                    else:print('  Choose 0, 1 or 2.')
            elif choice=='6':
                if a.bellard_offset is not None:
                    a.bellard_offset=ask('Binary offset',str(a.bellard_offset),low=0,high=8000000)
                    a.hex_digits=ask('Hex digits',str(a.hex_digits),low=1,high=6)
                else:a.digits=ask('Decimal digits',str(a.digits),low=1)
            elif choice=='8' and a.algorithm in ('pi_chudnovsky','e_taylor','e_inverse') and a.backend in ('cpu','hybrid-ntt'):
                a.cpu_library='pykolm' if a.cpu_library=='legacy' else 'legacy'
            elif choice=='7' and a.benchmark:
                a.repeats=ask('Repetitions','3',low=1,high=20)
                a.warmup=ask('Warmup','0',low=0,high=5)
            elif choice not in ('2','3','4','5','6'):print('  Choose an option from the list.')
        except Back:return False
        except (ValueError,RuntimeError,OSError) as exc:print('  '+str(exc))


def wizard(*, benchmark=False):
    """Choose execution mode -> GPU -> algorithm -> precision -> resources -> output.

    The history stack makes Back return to the actual preceding screen,
    including dynamic screens (Bellard hexadecimal offsets vs decimals).
    """
    from .cli import _args
    values={}
    history=[]
    step='mode'
    while step!='done':
        try:
            if step=='mode':
                print('\n  COMPUTE ENGINE')
                print('  [1] CPU only\n  [2] GPU pure (all arithmetic on GPU)\n  [3] Hybrid CPU + GPU\n')
                print('  GPU options appear only if you select 2 or 3.')
                from .prefs import read
                saved=read().get('compute_mode', 'cpu')
                default={'cpu':'1','gpu':'2','both':'3'}.get(saved,'1')
                choice=ask('Execution mode',default)
                if choice not in ('1','2','3'):
                    print('  Select 1, 2 or 3.');continue
                values={'mode':{'1':'cpu','2':'gpu','3':'both'}[choice]}
                next_step='device' if values['mode']!='cpu' else 'constant'
            elif step=='device':
                info,devices=find_gpus()
                print('\n  GPU DISCOVERY (pre-computation)')
                if not devices:
                    from .gpu_setup import recovery_menu
                    action=recovery_menu(info)
                    if action=='cpu':
                        values['mode']='cpu'
                        next_step='constant'
                    elif action=='back':
                        raise Back()
                    else:
                        continue  # retry after explicit repair or information
                else:
                    for n,(device_id,g) in enumerate(devices,1):
                        print(f'  [{n}] {g["name"]} | {g["vendor"]} | '
                              f'{__import__("neocruncher_app.hardware",fromlist=["_human_bytes"])._human_bytes(g["global_memory_bytes"])} OpenCL memory')
                    idx=ask('GPU number','1',low=1,high=len(devices))
                    values['device']=devices[idx-1][0]
                    values['gpu_name']=devices[idx-1][1]['name']
                    next_step='constant'
            elif step=='constant':
                constants=list(dict.fromkeys(a.constant for a in ALGORITHMS if a.status!='planned'
                                 and compatible_backend(a,values['mode'])))
                print('\n  BUILT-IN CONSTANTS')
                for index,name in enumerate(constants,1):print(f'  [{index}] {name}')
                index=ask('Constant','1',low=1,high=len(constants))
                values['constant']=constants[index-1]
                next_step='algorithm'
            elif step=='algorithm':
                algorithms=[a for a in ALGORITHMS if a.constant==values['constant']
                            and a.status!='planned' and compatible_backend(a,values['mode'])]
                print('\n  ALGORITHM')
                for index,a in enumerate(algorithms,1):
                    print(f'  [{index}] {a.title} [{a.status}]')
                index=ask('Algorithm','1',low=1,high=len(algorithms))
                values['spec']=algorithms[index-1]
                values['backend']=compatible_backend(values['spec'], values['mode'])
                from .cli import PARALLEL_KEYS
                next_step='workers' if values['mode']=='cpu' and values['spec'].key in PARALLEL_KEYS else 'precision'
                if values['backend'] in ('opencl-ntt','hybrid-ntt'):
                    next_step='engine'
                else:
                    values['engine']='native'
            elif step=='engine':
                print('\n  ARITHMETIC ENGINE')
                print('  [1] NeoCruncher OpenCL (default)')
                print('  [2] Kolmogorov Engine 1.2')
                choice=ask('Engine','1',low=1,high=2)
                values['engine']='kolmogorov' if choice==2 else 'native'
                next_step='precision'

            elif step=='workers':
                from .cpu_options import available_processes
                total=available_processes()
                print('\n  CPU | EXECUTION CONFIGURATION')
                print('  ─────────────────────────────')
                print('  [1] Single-core    · 1 process')
                print('  [2] Multicore      · all or custom')
                mode=ask('Selection','2')
                if mode=='1':values['workers']=1;next_step='precision'
                elif mode=='2':next_step='worker_allocation'
                else:print('  Choose 1 or 2.');continue
            elif step=='worker_allocation':
                from .cpu_options import available_processes
                total=available_processes()
                print(f'  [1] All available ({total}) · default')
                print('  [2] Custom process count')
                mode=ask('Allocation','1')
                if mode=='1':values['workers']=total;next_step='precision'
                elif mode=='2':next_step='worker_custom'
                else:print('  Choose 1 or 2.');continue
            elif step=='worker_custom':
                from .cpu_options import available_processes
                total=available_processes()
                print(f'\n  Available logical CPU threads: {total}\n')
                values['workers']=ask('Worker processes',str(min(2,total)),low=1,high=total)
                next_step='precision'
            elif step=='precision':
                if values['spec'].key=='pi_bellard':
                    print('\n  BELLARD — hexadecimal digits at a binary bit offset')
                    values['bellard_offset']=ask('Binary offset','0',low=0,high=8_000_000)
                    next_step='hex_digits'
                else:
                    from .precision_display import precision_reference
                    print('\n' + precision_reference())
                    values['digits']=ask('Decimal digits (e.g. 10M)',low=1)
                    next_step='resources'
            elif step=='hex_digits':
                values['hex_digits']=ask('Hexadecimal digits','4',low=1,high=6)
                next_step='resources'
            elif step=='resources':
                next_step='repeats' if benchmark else 'output'
            elif step=='repeats':
                values['repeats']=ask('Benchmark repetitions','3',low=1,high=20)
                next_step='warmup'
            elif step=='warmup':
                values['warmup']=ask('Warmup iterations','0',low=0,high=5)
                next_step='output'
            elif step=='output':
                if benchmark:
                    values['benchmark_output']=ask('Optional benchmark JSON path [none]','') or None
                    next_step='done'
                else:
                    const=values['constant']
                    name=(f'pi-bellard-{values["bellard_offset"]}.txt' if values['spec'].key=='pi_bellard'
                          else f'{const}-{values["digits"]}-{values["spec"].key}.txt')
                    filename=ask('TXT filename',name)
                    values['output']=filename if filename.endswith('.txt') else filename+'.txt'
                    next_step='verify' if values['spec'].status=='ready' else 'preflight'
            elif step=='verify':
                from .verification import MAX_VERIFY_DIGITS
                prompt=('Independent numerical verification? y/N' if values.get('digits',1000)<=MAX_VERIFY_DIGITS else f'Verify ONLY the first {MAX_VERIFY_DIGITS:,} decimals? y/N')
                answer=ask(prompt,'N').lower()
                if answer not in ('y','yes','n','no'):
                    print('  Select y or N.');continue
                enabled=answer in ('y','yes')
                values['verify']=enabled and values.get('digits',1000)<=MAX_VERIFY_DIGITS
                values['verify_prefix']=MAX_VERIFY_DIGITS if enabled and not values['verify'] else 0
                next_step='preflight'
            elif step=='preflight':
                next_step='done'
            else:
                raise RuntimeError(f'Unexpected wizard step: {step}')
        except Back:
            if history:
                step=history.pop()
            else:
                return None
            continue
        history.append(step)
        step=next_step
    spec=values['spec']
    args=_args(constant=values['constant'], algorithm=spec.key, backend=values['backend'],
               workers=values.get('workers',1),device=values.get('device',0),engine=values.get('engine','native'),
               ram_mib=values.get('ram_mib',0),vram_mib=values.get('vram_mib',0),disk_budget_gib=values.get('disk_budget_gib',0),
               digits=values.get('digits',1000),bellard_offset=values.get('bellard_offset'),
               hex_digits=values.get('hex_digits',4),output=values.get('output'),
               verify=values.get('verify',False),verify_prefix=values.get('verify_prefix',0),benchmark=benchmark,
               repeats=values.get('repeats',3),warmup=values.get('warmup',0),
               benchmark_output=values.get('benchmark_output'),plan=values.get('plan',False),
               preflight_accepted=False)
    return args if configure(args,parallel=args.backend=='cpu' and spec.key in PARALLEL_KEYS) else None


CUSTOM_GROUPS={
    'Trigonometric': ('sin','cos','tan','cot','sec','csc'),
    'Inverse trigonometric': ('asin','acos','atan','acot','asec','acsc'),
    'Hyperbolic': ('sinh','cosh','tanh','coth','sech','csch'),
    'Inverse hyperbolic': ('asinh','acosh','atanh','acoth','asech','acsch'),
    'Logarithms and exponentials': ('ln','log','log2','log10','exp'),
    'Roots and special functions': ('sqrt','root','gamma','zeta','agm'),
}


def custom_wizard():
    """Back-navigable custom expression workflow (numerical only)."""
    from .cli import _args, print_functions
    from .custom import FUNCTION_DOMAINS
    values={}
    history=[]
    step='mode'
    while step!='done':
        try:
            if step=='mode':
                print('\n  CUSTOM CONSTANTS / FUNCTIONS')
                print('  [1] Expression  [2] Function categories  [3] Show all domains')
                choice=ask('Selection','1')
                if choice not in ('1','2','3'):
                    print('  Select 1, 2 or 3.');continue
                if choice=='3':
                    print_functions()
                    return None
                next_step='expression' if choice=='1' else 'category'
            elif step=='category':
                groups=list(CUSTOM_GROUPS)
                for i,name in enumerate(groups,1):print(f'  [{i}] {name}')
                index=ask('Category','1',low=1,high=len(groups))
                values['category']=groups[index-1]
                next_step='function'
            elif step=='function':
                functions=CUSTOM_GROUPS[values['category']]
                for i,fn in enumerate(functions,1):
                    print(f'  [{i}] {fn}: {FUNCTION_DOMAINS[fn]}')
                index=ask('Function','1',low=1,high=len(functions))
                values['function']=functions[index-1]
                next_step='arguments'
            elif step=='arguments':
                fn=values['function']
                if fn in ('root','agm'):
                    default='root(27,3)' if fn=='root' else 'agm(1,2)'
                    expression=ask('Complete expression',default)
                    if not expression.startswith(fn+'('):
                        print('  Expected expression using '+fn+'.');continue
                else:
                    label='arguments (x,base)' if fn=='log' else 'argument (radians for trig)'
                    default='8,2' if fn=='log' else 'pi/6' if fn in ('sin','cos','tan') else '1'
                    expression=f'{fn}({ask(label,default)})'
                values['expression']=expression
                next_step='precision'
            elif step=='expression':
                values['expression']=ask('Expression (e.g. ln(7)+sin(pi/6))')
                if not values['expression']:
                    print('  Expression required.');continue
                next_step='precision'
            elif step=='precision':
                from .precision_display import precision_reference
                print('\n' + precision_reference())
                print('  Custom expressions use numerical evaluation, not formal certification.')
                values['digits']=ask('Decimal digits (e.g. 10M)',low=1)
                next_step='resources'
            elif step=='resources':
                next_step='output'
            elif step=='output':
                filename=ask('TXT filename','custom-result.txt')
                values['output']=filename if filename.endswith('.txt') else filename+'.txt'
                next_step='done'
            else:raise RuntimeError('Unexpected custom workflow step '+step)
        except Back:
            if history:step=history.pop()
            else:return None
            continue
        history.append(step)
        step=next_step
    args=_args(expression=values['expression'],digits=values['digits'],output=values['output'])
    return args if configure(args,parallel=False) else None
