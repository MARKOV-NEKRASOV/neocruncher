# SPDX-License-Identifier: GPL-3.0-only
"""Explicit arithmetic engine selection (computation runs on this computer)."""
from .dispatch import multiplications, multiplications_batch, batch_multiplication_available, use_arithmetic, operation_stats
__all__ = ['multiplications','multiplications_batch','batch_multiplication_available','use_arithmetic','operation_stats']
