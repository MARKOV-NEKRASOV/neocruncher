# SPDX-License-Identifier: GPL-3.0-only
"""Native NTT driver for Kolmogorov's shared device-integer execution API."""
import numpy as np

class NativeDriver:
    name='native-opencl-resident'
    max_points=1<<18
    def __init__(self,device=0,vram_mib=0):
        from .ntt import OpenCLMultiplier
        self.backend=OpenCLMultiplier(device,vram_mib=vram_mib)
        self.cl,self.ctx,self.queue,self.device=self.backend.cl,self.backend.ctx,self.backend.queue,self.backend.device
        self.queue=self.cl.CommandQueue(self.ctx,properties=self.cl.command_queue_properties.PROFILING_ENABLE)

    def convolve(self,rt,a,b,n):
        if not hasattr(self,'_roots'):self._roots={}
        parts=[]
        for p,root in ((2013265921,31),(1811939329,13)):
            x=rt._raw(n*4);y=x if a is b else rt._raw(n*4)
            rt.run('r_pack_ntt',n,rt.buffer(a),rt._u(a.n),rt._u(0),x,rt._u(n))
            if a is not b:rt.run('r_pack_ntt',n,rt.buffer(b),rt._u(b.n),rt._u(0),y,rt._u(n))
            def transform(buf,inverse=False):
                rt.launch(self.backend._kernel('bit_reverse_inplace'),n,buf,np.uint32(n.bit_length()-1))
                for stage in range(1,n.bit_length()):
                    half=1<<(stage-1);key=(p,half,inverse)
                    if key not in self._roots:
                        roots=rt._raw(half*4);params=rt._raw(8)
                        rt.run('r_ntt_setup',1,params,rt._u(p),rt._u(root),rt._u(half*2),rt._u(inverse))
                        rt.run('r_ntt_roots',half,roots,params,rt._u(p))
                        self._roots[key]=roots,params
                    roots,params=self._roots[key]
                    rt.launch(self.backend._kernel('butterfly'),n//2,buf,roots,np.uint32(half),np.uint32(p))
                if inverse:rt.run('r_ntt_normalize',n,buf,params,rt._u(p))
            transform(x)
            if a is not b:transform(y)
            rt.launch(self.backend._kernel('pointwise'),n,x,y,np.uint32(p))
            transform(x,True)
            parts.append(x)
        return parts

    @property
    def cached_bytes(self):
        return sum(buf.size for pair in getattr(self,'_roots',{}).values() for buf in pair)


def calculate(algorithm,digits,engine,device,ram_mib,vram_mib,progress=None):
    from kolmogorov.compute.resident import DeviceArithmetic
    from kolmogorov.compute.resident.constants import calculate as compute
    if progress: progress(dict(stage='GPU driver initialization and kernel compilation', percent=None))
    from kolmogorov.doctor import probe
    probe(device)
    driver=NativeDriver(device,vram_mib) if engine=='native' else None
    rt=DeviceArithmetic(device,vram_mib=vram_mib,ram_mib=ram_mib,driver=driver)
    return compute(rt,algorithm,digits,progress)
