# SPDX-License-Identifier: GPL-3.0-only
"""Exact radix-2 NTT multiplication.

OpenCL path performs NTT, modular reconstruction (CRT) and carries on-device.
Python only packs inputs/unpacks output; the Pi algorithm itself is still CPU.
Not a complete GPU-only Pi engine, nor an out-of-core implementation.
"""
from __future__ import annotations
import math
import os
import time
from collections import OrderedDict
import numpy as np

# Both prime moduli support at least 2**26-th roots of unity.
PRIMES=((2013265921,31,27),(1811939329,13,26))
BASE_BITS=16
BASE=1<<BASE_BITS

def _size_for(n:int,m:int)->int:
    return 1 << ((n+m-2).bit_length())

def _ensure_safe(n:int,m:int)->int:
    size=_size_for(n,m)
    if size>(1<<26):raise ValueError('NTT transform exceeds current in-memory limit 2^26')
    # No coefficient can wrap when reduced modulo the two primes.
    if min(n,m)*(BASE-1)**2>=PRIMES[0][0]*PRIMES[1][0]:
        raise ValueError('CRT coefficient capacity exceeded; more primes required')
    return size

def _limbs(value:int)->np.ndarray:
    if value<0:raise ValueError('NTT limbs require nonnegative integers')
    if value==0:return np.zeros(1,dtype=np.uint16)
    bb=value.to_bytes((value.bit_length()+15)//16*2, 'little')
    return np.frombuffer(bb,dtype='<u2')

def _ntt_cpu(data,prime,root,inverse=False):
    n=len(data)
    # Single-pass bit-reversal permutation.
    j=0
    for i in range(1,n):
        b=n>>1
        while j & b:
            j ^= b;b >>= 1
        j ^= b
        if i<j:data[i],data[j]=data[j],data[i]
    length=2
    while length<=n:
        wlen=pow(root,(prime-1)//length,prime)
        if inverse:wlen=pow(wlen,-1,prime)
        for i in range(0,n,length):
            w=1;half=length>>1
            for k in range(half):
                u=data[i+k];v=data[i+k+half]*w%prime
                data[i+k]=(u+v)%prime
                data[i+k+half]=(u-v)%prime
                w=w*wlen%prime
        length<<=1
    if inverse:
        inv=pow(n,-1,prime)
        for i in range(n):data[i]=data[i]*inv%prime
    return data

def _convolution_cpu(a,b,p,root,size):
    x=[int(z) for z in a]+[0]*(size-len(a));y=[int(z) for z in b]+[0]*(size-len(b))
    _ntt_cpu(x,p,root);_ntt_cpu(y,p,root)
    z=[u*v%p for u,v in zip(x,y)]
    _ntt_cpu(z,p,root,True)
    return z

def _merge_crt(parts,size):
    p=PRIMES[0][0];q=PRIMES[1][0]
    inv=pow(p,-1,q)
    # Python integers prevent overflow in CRT and carry propagation.
    carry=0;out=bytearray(2*size)
    for i,(left,right) in enumerate(zip(*parts)):
        coef=int(left)+p*(((int(right)-int(left))*inv)%q)
        coef+=carry
        digit=coef & 0xffff
        out[i*2]=digit&255;out[i*2+1]=digit>>8
        carry=coef>>16
    while carry:
        out.append(carry&255);carry>>=8
    return int.from_bytes(out,'little')

def verified_ntt_limit():
    """Conservative safety limit, not a physical upper bound of any GPU."""
    import os
    if os.environ.get('NEOCRUNCHER_EXPERIMENTAL_LARGE_NTT')!='1':
        return 1<<18
    raw=os.environ.get('NEOCRUNCHER_MAX_NTT_POINTS','1048576')
    try:cap=int(raw)
    except ValueError as exc:raise ValueError('NEOCRUNCHER_MAX_NTT_POINTS must be an integer') from exc
    if cap<1 or cap>(1<<26) or cap&(cap-1):
        raise ValueError('NEOCRUNCHER_MAX_NTT_POINTS must be a power of two <= 2**26')
    return cap

def multiply_cpu(a:int,b:int)->int:
    if not isinstance(a,int) or not isinstance(b,int):raise TypeError('integer inputs required')
    if not a or not b:return 0
    sign=-1 if (a<0)^(b<0) else 1
    x=_limbs(abs(a));y=_limbs(abs(b))
    size=_ensure_safe(len(x),len(y))
    parts=[_convolution_cpu(x,y,p,r,size) for p,r,_ in PRIMES]
    return sign*_merge_crt(parts,size)

class OpenCLMultiplier:
    """OpenCL GPU arithmetic primitive: NTT, CRT and carry on-device.

    Host handles packing/unpacking Python integers. This does NOT make a full
    constant-calculation pipeline GPU-only; binary splitting, division and sqrt
    in the current Chudnovsky driver remain on CPU. Fail closed on GPU errors.
    """
    def __init__(self,device_index=0,vram_mib=0):
        from kolmogorov.doctor import probe
        probe(device_index)
        try:import pyopencl as cl
        except ImportError as exc:raise RuntimeError('PyOpenCL missing: configure GPU first') from exc
        from ..hardware import opencl_devices
        devs=opencl_devices()
        if not devs or not 0<=device_index<len(devs):
            raise RuntimeError('No compatible GPU OpenCL device is available')
        self.cl=cl
        self.device=devs[device_index]['object']
        self.max_vram_bytes=int(vram_mib*1024*1024) if vram_mib else int(self.device.global_mem_size*0.85)
        self.ctx=cl.Context([self.device]);self.queue=cl.CommandQueue(self.ctx)
        from importlib.resources import files
        src=files('neocruncher_app').joinpath('resources/ntt.cl').read_text(encoding='utf8')
        try:self.program=cl.Program(self.ctx,src).build()
        except Exception as exc:raise RuntimeError(f'GPU NTT kernel build failed on {self.device.name}: {exc}') from exc
        # Store kernel objects once; avoids expensive repeated PyOpenCL retrieval.
        kernel_names = ('make_roots','bit_reverse_inplace','butterfly','pointwise',
                        'normalize','crt_coefficients','schoolbook_coefficients',
                        'batch_schoolbook_coefficients','batch_schoolbook_carries',
                        'nc037_carry_bounds','nc037_carry_boundaries','nc037_carry_digits')
        self.kernels={name:getattr(self.program,name) for name in kernel_names}
        self.calls=0;self.bytes_uploaded=0;self.bytes_downloaded=0
        self.schoolbook_calls=0;self.ntt_calls=0
        self.batch_dispatches=0;self.batched_products=0
        self.multiply_wall_seconds=0.0
        self.schoolbook_max_limbs=128  # Experimental GPU schoolbook threshold
        # Each radix-2 stage needs the same powers of the same root for a given
        # modulus/direction, independent of the multiplication operands.
        # Cache them on-device to avoid recomputing modular exponentiations for
        # every small binary-splitting product. Bound device memory use.
        self.root_cache=OrderedDict()
        self.root_cache_bytes=0
        self.root_cache_limit=min(64*1024*1024, int(self.max_vram_bytes*0.04))
        self.root_cache_hits=0
        self.root_cache_misses=0
        self.root_cache_evictions=0
        self.max_transform_n=0

    def _kernel(self, name):
        # Unit tests construct an object without __init__. The production path
        # uses only cached objects to avoid repeated kernel attribute retrieval.
        cached=getattr(self,'kernels',None)
        if cached is not None:
            return cached[name]
        return getattr(self.program,name)

    def _stage_roots(self,p,root,half,inverse=False):
        key=(int(p),int(half),bool(inverse))
        cached=self.root_cache.get(key)
        if cached is not None:
            self.root_cache.move_to_end(key)
            self.root_cache_hits+=1
            return cached
        self.root_cache_misses+=1
        omega=pow(root,(p-1)//(2*half),p)
        if inverse:omega=pow(omega,-1,p)
        roots=self.cl.Buffer(self.ctx,self.cl.mem_flags.READ_WRITE,half*4)
        self._kernel('make_roots')(self.queue,(half,),None,roots,np.uint32(omega),np.uint32(p))
        bytes_used=half*4
        if bytes_used<=self.root_cache_limit:
            while self.root_cache and self.root_cache_bytes+bytes_used>self.root_cache_limit:
                _,victim=self.root_cache.popitem(last=False)
                self.root_cache_bytes-=int(victim.size)
                self.root_cache_evictions+=1
            self.root_cache[key]=roots
            self.root_cache_bytes+=bytes_used
        return roots

    def _transform(self,buf,n,p,root,inverse=False):
        cl=self.cl;prog=self.program
        # An in-place pair-swap removes a full n*4-byte allocation on every
        # forward/inverse transform; bit-reversal pairs are disjoint.
        bits=n.bit_length()-1
        self._kernel('bit_reverse_inplace')(self.queue,(n,),None,buf,np.uint32(bits))
        current=buf
        for stage in range(1,bits+1):
            half=1<<(stage-1)
            roots=self._stage_roots(p,root,half,inverse)
            self._kernel('butterfly')(self.queue,(n//2,),None,current,roots,np.uint32(half),np.uint32(p))
        if inverse:
            self._kernel('normalize')(self.queue,(n,),None,current,np.uint32(pow(n,-1,p)),np.uint32(p))
        return current
    def _workspace_pair(self,n,prime):
        """Two persistent pairs: prime outputs coexist until CRT/carry finishes."""
        if getattr(self,'_workspace_size',None)!=n:
            self.queue.finish()
            self._workspace_size=n
            self._workspace_pairs={}
        cache=self._workspace_pairs
        if prime not in cache:
            x=np.empty(n,dtype=np.uint32);y=np.empty(n,dtype=np.uint32)
            xa=self.cl.Buffer(self.ctx,self.cl.mem_flags.READ_WRITE,n*4)
            ya=self.cl.Buffer(self.ctx,self.cl.mem_flags.READ_WRITE,n*4)
            cache[prime]=(x,y,xa,ya)
            self.workspace_allocations=getattr(self,'workspace_allocations',0)+2
        else:
            self.workspace_reuses=getattr(self,'workspace_reuses',0)+1
        return cache[prime]

    def _convolution(self,a,b,p,root,n):
        x,y,xa,ya=self._workspace_pair(n,p)
        x.fill(0);y.fill(0)
        x[:len(a)]=a;y[:len(b)]=b
        self.cl.enqueue_copy(self.queue,xa,x)
        self.cl.enqueue_copy(self.queue,ya,y)
        self.bytes_uploaded+=x.nbytes+y.nbytes
        fx=self._transform(xa,n,p,root)
        fy=self._transform(ya,n,p,root)
        self._kernel('pointwise')(self.queue,(n,),None,fx,fy,np.uint32(p))
        return self._transform(fx,n,p,root,True)

    def _schoolbook_on_gpu(self, x, y):
        """Exact GPU direct convolution for tiny inputs: 2 kernels, no NTT.

        128 * (2**16-1)**2 < 2**39, so every unsigned-64-bit
        coefficient is exact. No CPU product or CPU carry occurs here.
        """
        if max(len(x), len(y)) > self.schoolbook_max_limbs:
            raise ValueError('GPU schoolbook length limit exceeded')
        cl=self.cl; mf=cl.mem_flags
        a=np.ascontiguousarray(x,dtype='<u2')
        b=np.ascontiguousarray(y,dtype='<u2')
        na,nb=len(a),len(b)
        n=na+nb-1
        left=cl.Buffer(self.ctx,mf.READ_ONLY|mf.COPY_HOST_PTR,hostbuf=a)
        right=cl.Buffer(self.ctx,mf.READ_ONLY|mf.COPY_HOST_PTR,hostbuf=b)
        coeff=cl.Buffer(self.ctx,mf.READ_WRITE,n*8)
        self.bytes_uploaded+=a.nbytes+b.nbytes
        self._kernel('schoolbook_coefficients')(self.queue,(n,),None,
                                             left,np.uint32(na),right,np.uint32(nb),coeff)
        result=self._carry_from_coefficients(coeff,n)
        self.schoolbook_calls+=1
        return result

    def multiply_many(self, pairs):
        """Exact GPU batch of independent integer products, preserving order.

        Small products share two OpenCL launches per batch rather than two
        launches per product. Larger products still use the established NTT
        path. This method never computes a requested product on the CPU.
        """
        if not pairs:
            return []
        answers = [None] * len(pairs)
        pending = []

        def flush():
            if not pending:
                return
            values = self._schoolbook_batch_on_gpu([(a,b) for _,a,b in pending])
            for (index,_,_), value in zip(pending,values):
                answers[index] = value
            pending.clear()

        for index,(a,b) in enumerate(pairs):
            if not isinstance(a,int) or not isinstance(b,int):
                raise TypeError('GPU batch expects integer pairs')
            if a == 0 or b == 0:
                flush()
                answers[index] = 0
                continue
            na = (abs(a).bit_length()+15)//16
            nb = (abs(b).bit_length()+15)//16
            if max(na,nb) <= self.schoolbook_max_limbs:
                pending.append((index,a,b))
                if len(pending) >= 1024:
                    flush()
            else:
                flush()
                answers[index] = self.multiply(a,b)
        flush()
        return answers

    def _schoolbook_batch_on_gpu(self,pairs):
        """Variable-sized packed schoolbook convolution on GPU.

        Work dimension (coefficient, product) parallelizes coefficient sums;
        the carry kernel uses one GPU work item per independent product.
        Operands, CRT/normalization and all products remain exact.
        """
        if not pairs:
            return []
        if len(pairs)>1024:
            raise ValueError('OpenCL batch exceeds 1024 products')
        started=time.perf_counter()
        cl=self.cl;mf=cl.mem_flags
        lhs=[];rhs=[];length_a=[];length_b=[];offset_a=[];offset_b=[]
        offset_c=[];offset_out=[];signs=[]
        total_a=total_b=total_c=total_out=0
        max_n=0
        for a,b in pairs:
            if not a or not b:
                raise ValueError('Batch kernel expects nonzero integer pairs')
            xa=_limbs(abs(a));yb=_limbs(abs(b))
            na,nb=len(xa),len(yb)
            if max(na,nb)>self.schoolbook_max_limbs:
                raise ValueError('Batch operand above GPU direct limit')
            n=na+nb-1
            lhs.append(xa);rhs.append(yb)
            length_a.append(na);length_b.append(nb)
            offset_a.append(total_a);offset_b.append(total_b)
            offset_c.append(total_c);offset_out.append(total_out)
            signs.append(-1 if (a<0)^(b<0) else 1)
            total_a+=na;total_b+=nb;total_c+=n;total_out+=n+4
            max_n=max(max_n,n)
        a_data=np.concatenate(lhs).astype('<u2',copy=False)
        b_data=np.concatenate(rhs).astype('<u2',copy=False)
        meta=np.array(list(zip(offset_a,offset_b,length_a,length_b,offset_c,offset_out)),dtype=np.uint32)
        # One tightly-packed metadata record per product (6 uint32 fields).
        meta_data=np.ascontiguousarray(meta.ravel())
        total_bytes=(a_data.nbytes+b_data.nbytes+meta_data.nbytes+
                     total_c*8+total_out*2+len(pairs)*4)
        if max(a_data.nbytes,b_data.nbytes,meta_data.nbytes,total_c*8,total_out*2) > int(self.device.max_mem_alloc_size):
            raise MemoryError('OpenCL batch exceeds device max single allocation')
        if total_bytes>self.max_vram_bytes:
            raise MemoryError('OpenCL batch exceeds VRAM budget')
        abuf=cl.Buffer(self.ctx,mf.READ_ONLY|mf.COPY_HOST_PTR,hostbuf=a_data)
        bbuf=cl.Buffer(self.ctx,mf.READ_ONLY|mf.COPY_HOST_PTR,hostbuf=b_data)
        mbuf=cl.Buffer(self.ctx,mf.READ_ONLY|mf.COPY_HOST_PTR,hostbuf=meta_data)
        coeff=cl.Buffer(self.ctx,mf.READ_WRITE,total_c*8)
        digits=cl.Buffer(self.ctx,mf.WRITE_ONLY,total_out*2)
        errors=cl.Buffer(self.ctx,mf.WRITE_ONLY,len(pairs)*4)
        self.bytes_uploaded+=a_data.nbytes+b_data.nbytes+meta_data.nbytes
        self._kernel('batch_schoolbook_coefficients')(
            self.queue,(max_n,len(pairs)),None,abuf,bbuf,mbuf,coeff)
        self._kernel('batch_schoolbook_carries')(
            self.queue,(len(pairs),),None,coeff,mbuf,digits,errors)
        result_data=np.empty(total_out,dtype='<u2')
        result_err=np.empty(len(pairs),dtype=np.uint32)
        cl.enqueue_copy(self.queue,result_data,digits)
        cl.enqueue_copy(self.queue,result_err,errors).wait()
        self.bytes_downloaded+=result_data.nbytes+result_err.nbytes
        if np.any(result_err):
            raise ArithmeticError('GPU batch carry overflow')
        results=[]
        for i,((a,b),sign) in enumerate(zip(pairs,signs)):
            offset=offset_out[i];n=length_a[i]+length_b[i]+3
            value=sign*int.from_bytes(result_data[offset:offset+n].tobytes(),'little')
            # Checks are performed on host, not used to calculate the product.
            for p in ((1<<61)-1,(1<<31)-1):
                if value%p != ((a%p)*(b%p))%p:
                    raise ArithmeticError('GPU batch product failed modular verification')
            results.append(value)
        self.calls+=len(pairs)
        self.schoolbook_calls+=len(pairs)
        self.batched_products+=len(pairs)
        self.batch_dispatches+=1
        self.multiply_wall_seconds+=time.perf_counter()-started
        return results

    def _carry_from_coefficients(self, combined, n):
        """GPU-only, exact block-parallel base-2**16 carry propagation.

        Stage 1 computes two carry-out bounds per chunk, stage 2 resolves
        boundaries (only sensitive chunks need an internal scan), and stage 3
        generates each chunk's digits in parallel. No CPU carry is performed.
        """
        if n < 1 or n >= (1<<32):
            raise ValueError('Unsupported carry length for OpenCL uint indexing')
        cl=self.cl;mf=cl.mem_flags
        blocks=(n+1023)//1024
        allocs=(n+4)*2, blocks*8, blocks*8, blocks*8
        if max(allocs)>int(self.device.max_mem_alloc_size):
            raise MemoryError('GPU carry buffer exceeds maximum allocation size')
        if sum(allocs)+4>self.max_vram_bytes:
            raise MemoryError('GPU carry buffers exceed selected VRAM budget')
        out=cl.Buffer(self.ctx,mf.WRITE_ONLY,(n+4)*2)
        overflow=cl.Buffer(self.ctx,mf.WRITE_ONLY,4)
        low=cl.Buffer(self.ctx,mf.READ_WRITE,blocks*8)
        high=cl.Buffer(self.ctx,mf.READ_WRITE,blocks*8)
        incoming=cl.Buffer(self.ctx,mf.READ_WRITE,blocks*8)
        self._kernel('nc037_carry_bounds')(self.queue,(blocks,),None,
            combined,low,high,np.uint32(n))
        self._kernel('nc037_carry_boundaries')(self.queue,(1,),None,
            combined,low,high,incoming,out,overflow,np.uint32(n),np.uint32(blocks))
        self._kernel('nc037_carry_digits')(self.queue,(blocks,),None,
            combined,incoming,out,np.uint32(n))
        host_out=np.empty(n+4,dtype='<u2')
        host_error=np.empty(1,dtype=np.uint32)
        cl.enqueue_copy(self.queue,host_out,out)
        cl.enqueue_copy(self.queue,host_error,overflow).wait()
        if int(host_error[0]):
            raise ArithmeticError('GPU convolution carry exceeded four extra limbs')
        self.bytes_downloaded+=host_out.nbytes+host_error.nbytes
        return int.from_bytes(host_out.tobytes(),'little')

    def _crt_and_carry_on_gpu(self, parts, n):
        """Combine two residue vectors and normalize base-2**16 on the GPU.

        0.3.7 normalizes carries exactly using bounded GPU chunks and a
        sequential boundary-resolution stage. This is not a full parallel
        prefix carry scan, nor proof of large-run stability.
        """
        cl=self.cl
        mf=cl.mem_flags
        combined=cl.Buffer(self.ctx,mf.READ_WRITE,n*8)
        p=PRIMES[0][0]
        q=PRIMES[1][0]
        inverse=pow(p,-1,q)
        self._kernel('crt_coefficients')(self.queue,(n,),None,parts[0],parts[1],
                                      combined,np.uint32(p),np.uint32(q),np.uint32(inverse))
        return self._carry_from_coefficients(combined,n)

    def multiply(self,a:int,b:int)->int:
        if not a or not b:return 0
        started=time.perf_counter()
        sign=-1 if (a<0)^(b<0) else 1
        x=_limbs(abs(a));y=_limbs(abs(b))
        if max(len(x),len(y))<=self.schoolbook_max_limbs:
            result=sign*self._schoolbook_on_gpu(x,y)
        else:
            size=_ensure_safe(len(x),len(y))
            # Larger experiments demand explicit acknowledgement in environment.
            cap=verified_ntt_limit()
            if size>cap:
                raise MemoryError(f'NTT length {size:,} exceeds verified default limit {cap:,}. '
                    'This protects the GPU after the 100M crash. For experimental work '
                    'use NEOCRUNCHER_EXPERIMENTAL_LARGE_NTT=1 and a bounded '
                    'NEOCRUNCHER_MAX_NTT_POINTS override; no silent CPU fallback.')
            self.max_transform_n=max(self.max_transform_n,size)
            if size*8>int(self.device.max_mem_alloc_size):
                raise MemoryError('GPU CRT/NTT allocation exceeds max OpenCL single allocation')
            if size*4*12>self.max_vram_bytes:
                raise MemoryError('GPU NTT workspace estimate exceeds selected VRAM budget')
            parts=[self._convolution(x,y,p,r,size) for p,r,_ in PRIMES]
            result=sign*self._crt_and_carry_on_gpu(parts,size)
            self.ntt_calls+=1
        for verifier_prime in ((1<<61)-1,(1<<31)-1):
            if result%verifier_prime != (a%verifier_prime)*(b%verifier_prime)%verifier_prime:
                raise ArithmeticError('GPU product failed independent modular arithmetic check')
        self.calls+=1
        self.multiply_wall_seconds+=time.perf_counter()-started
        return result
