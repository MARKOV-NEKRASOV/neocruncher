# SPDX-License-Identifier: GPL-3.0-only
"""Explicit, device-bound measured hybrid routing. Not automatic failure recovery."""
from __future__ import annotations
import hashlib,json,math,os,platform,sys
from pathlib import Path
try:
    from gmpy2 import mpz
except ImportError:
    mpz=None

def cpu_product(a,b):
    # Keep the external contract Python int, including when GMP runs on CPU.
    if mpz is not None and min(abs(a).bit_length(),abs(b).bit_length())>=8192:
        return mpz(a)*mpz(b)
    return a*b

def fingerprint(device,engine):
    fields={k:str(getattr(device,k,'')) for k in ('name','vendor','version','driver_version','global_mem_size','max_mem_alloc_size')}
    fields['engine']=engine
    fields['transport']=os.environ.get('KOLMOGOROV_INT_TRANSPORT','binary') if engine=='kolmogorov' else 'binary'
    fields['cpu_arithmetic']='GMP' if mpz is not None else 'Python'
    fields['cpu_machine']=platform.machine()
    fields['cpu_processor']=platform.processor()
    fields['python']=sys.version.split()[0]
    fields['arithmetic_revision']='neo100-host-tree-v1'
    return hashlib.sha256(json.dumps(fields,sort_keys=True).encode()).hexdigest()

class RoutingProfile:
    def __init__(self,path,device,engine):
        p=Path(path)
        if p.stat().st_size>1024**2:raise ValueError('Calibration profile exceeds 1 MiB')
        d=json.loads(p.read_text())
        if not isinstance(d,dict):raise ValueError('Calibration must be a JSON object')
        if d.get('status')!='PASS':raise ValueError('Calibration is not complete')
        if d.get('schema')!='neo100-calibration-v1' or d.get('fingerprint')!=fingerprint(device,engine):
            raise ValueError('Calibration profile does not match engine/device/revision')
        records=d.get('samples')
        if not isinstance(records,list) or not 1<=len(records)<=64:raise ValueError('Invalid calibration samples')
        self.samples=[]
        for r in records:
            if not isinstance(r,dict):raise ValueError('Invalid calibration sample')
            bits=r.get('bits');cpu=r.get('cpu_median_seconds');gpu=r.get('gpu_median_seconds')
            if type(bits) is not int or not 128<=bits<=2**28:raise ValueError('Invalid calibrated operand size')
            if not all(type(t) in (int,float) and math.isfinite(t) and t>0 for t in (cpu,gpu)):
                raise ValueError('Calibration timings must be finite positive numbers')
            self.samples.append((bits,gpu<cpu*.9))
        self.samples.sort()
        if len({bits for bits,_ in self.samples})!=len(self.samples):raise ValueError('Duplicate calibration size')
        self.sha256=hashlib.sha256(p.read_bytes()).hexdigest()

    def choose_gpu(self,a,b):
        low,high=sorted((abs(a).bit_length(),abs(b).bit_length()))
        if not low:return False,'zero identity'
        if high>2*low:return False,'unbalanced outside measured shapes'
        if high<self.samples[0][0]:return False,'below measured range'
        for bits,gpu in self.samples:
            if high<=bits:return gpu,'measured GPU win' if gpu else 'measured CPU win'
        return False,'above measured range'
