# SPDX-License-Identifier: GPL-3.0-only
"""Local GPU verification with exact CPU arithmetic; no external network calls."""
import random
from .ntt import multiply_cpu,OpenCLMultiplier

def main(device=0):
    rng=random.Random(20261016)
    vectors=[]
    for bits in (1,16,63,1024,4096,16384,32768):
        a=rng.getrandbits(bits);b=rng.getrandbits(bits+13)
        vectors.append((a,b))
    for a,b in vectors:
        if multiply_cpu(a,b)!=a*b:raise ArithmeticError('CPU NTT failed exact multiplication')
    print(f'  CPU NTT reference: {len(vectors)} exact multiplications PASS')
    try:gpu=OpenCLMultiplier(device)
    except RuntimeError as exc:
        print(f'  GPU NOT TESTED: {exc}')
        return 2
    for i,(a,b) in enumerate(vectors,1):
        actual=gpu.multiply(a,b)
        if actual!=a*b:raise ArithmeticError(f'GPU NTT mismatch in vector {i}')
        print(f'  GPU NTT test {i}/{len(vectors)} PASS ({a.bit_length()} bits)')
    print(f'  GPU verified: {gpu.device.name}; {gpu.calls} convolution calls')
    return 0
