# SPDX-License-Identifier: GPL-3.0-only
"""Optional Kolmogorov Engine 1.2 arithmetic integration.

Requires separately installed kolmogorov-core>=1.2,<1.3. No fallback to Neo
native or CPU when Kolmogorov/OpenCL is unavailable or fails.
"""
from __future__ import annotations

class KolmogorovMultiplier:
    def __init__(self, device=0, *, verify='modular'):
        import os
        if os.environ.get('KOLMOGOROV_OPENCL_ALLOW_CPU')=='1':
            raise RuntimeError('Unset KOLMOGOROV_OPENCL_ALLOW_CPU for NeoCruncher GPU execution')
        try:
            from kolmogorov.compute.integration import ExactIntegerEngine, API_VERSION
        except ImportError as exc:
            raise RuntimeError('Kolmogorov Engine 1.2 is not installed. Install the separate Kolmogorov 1.2 package.') from exc
        if not API_VERSION.startswith(('1.2.',)):
            raise RuntimeError(f'Unsupported Kolmogorov engine API version: {API_VERSION}')
        self.engine = ExactIntegerEngine(backend='opencl',device=device,verify=verify)
        self.device = self.engine._impl._devices[0]
        self.maximum_supported_ntt = self.engine.max_transform_n
        self.schoolbook_calls = None
        self.ntt_calls = None
        self.bytes_uploaded = None
        self.bytes_downloaded = None
        self.root_cache_hits = None
        self.root_cache_misses = None
        self.root_cache_evictions = None
        self.batch_is_fused = False

    @property
    def integer_transport(self):
        return getattr(self.engine,'transport','decimal-legacy')

    @property
    def max_transform_n(self):
        return getattr(self.engine,'max_observed_ntt_length',self.engine.last_ntt_length)

    @property
    def batch_dispatches(self):
        return self.engine.batch_groups

    @property
    def batched_products(self):
        return self.engine.batched_products

    def multiply(self,a,b):
        return self.engine.multiply(a,b)

    def multiply_many(self,pairs):
        return self.engine.multiply_many(pairs)

    def metrics(self):
        return self.engine.metrics()

    def set_vram_budget(self, vram_mib):
        """Apply Neo's explicit budget at every Kolmogorov admission guard."""
        if not vram_mib:
            return
        backend = self.engine._impl
        original = backend._memory_guard
        budget = int(vram_mib*1024**2)
        def bounded(n):
            original(n)
            if 24*n > budget:
                raise MemoryError('Kolmogorov workspace exceeds selected NeoCruncher VRAM budget')
        backend._memory_guard = bounded
