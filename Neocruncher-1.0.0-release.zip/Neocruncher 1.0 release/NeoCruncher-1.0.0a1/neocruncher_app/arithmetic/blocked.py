# SPDX-License-Identifier: GPL-3.0-only
"""Bounded GPU products with exact host overlap-add. Not out-of-core.

Each nonzero tile is multiplied by the explicitly selected GPU engine.
Host splits binary words, adds partial coefficients and propagates carries.
No CPU product fallback. Balanced products use Karatsuba; unbalanced ones
use diagonal overlap-add. Large constant feasibility remains experimental.
"""
from __future__ import annotations
import time

class BlockedMultiplier:
    def __init__(self, engine, *, engine_choice, vram_mib=0):
        self.inner = engine
        self.engine_choice = engine_choice
        from .ntt import verified_ntt_limit
        cap = verified_ntt_limit() if engine_choice == 'native' else 1 << 18
        # Include native root cache headroom and per-allocation guard.
        dev = getattr(engine, 'device', None)
        alloc = int(getattr(dev, 'max_mem_alloc_size', 1 << 62))
        budget = int(vram_mib*1024**2) if vram_mib else getattr(engine, 'max_vram_bytes', 1 << 62)
        while cap > 2 and (cap*48 + min(64*1024**2, int(budget*.04)) > budget or cap*8 > alloc):
            cap //= 2
        if cap < 4:
            raise MemoryError('VRAM budget is too small for bounded GPU multiplication')
        self.tile_ntt_limit = cap
        # Kolmogorov uses base 10^4: 13 bits/limb is a strict lower bound.
        bits_per_limb = 16 if engine_choice == 'native' or getattr(engine,'integer_transport','')=='binary-u16le-v1' else 13
        self.block_bytes = max(1, ((cap//2-1)*bits_per_limb)//8)
        self.blocked_products = 0
        self.tile_products = 0
        self.skipped_zero_tiles = 0
        self.max_tiles_per_product = 0
        self.karatsuba_nodes = 0
        self.progress = None
        self._last_progress = 0.0

    def __getattr__(self, key):
        return getattr(self.inner, key)

    def _large(self, a, b):
        return max(abs(a).bit_length(), abs(b).bit_length()) > self.block_bytes*8

    def multiply(self, a, b):
        if not self._large(a,b):
            return self.inner.multiply(a,b)
        if not a or not b:
            return 0
        sign = -1 if (a < 0) ^ (b < 0) else 1
        a,b=abs(a),abs(b)
        self.blocked_products += 1
        block_bits=self.block_bytes*8
        nx=(a.bit_length()+block_bits-1)//block_bits
        ny=(b.bit_length()+block_bits-1)//block_bits
        self.max_tiles_per_product=max(self.max_tiles_per_product,nx*ny)
        value=sign*self._positive_product(a,b)
        for p in ((1 << 61)-1, (1 << 31)-1):
            if value % p != (sign*(a % p)*(b % p)) % p:
                raise ArithmeticError('Blocked GPU product failed final modular check')
        return value

    def _tile(self,a,b):
        if not a or not b:
            self.skipped_zero_tiles+=1
            return 0
        value=self.inner.multiply(a,b)
        self.tile_products+=1
        now=time.monotonic()
        if self.progress and now-self._last_progress>=1:
            self._last_progress=now
            self.progress(dict(stage='GPU bounded products / CPU assembly',percent=None,
                               phase_percent=None,work_done=self.tile_products,work_total=0,
                               progress_scope='cumulative GPU tiles; total not predicted',
                               certified_decimal_digits=0))
        return value

    def _positive_product(self,a,b):
        if not a or not b:
            self.skipped_zero_tiles+=1
            return 0
        width=self.block_bytes
        bits=width*8
        na,nb=a.bit_length(),b.bit_length()
        if max(na,nb)<=bits:
            return self._tile(a,b)
        # Three GPU subproducts instead of four for large balanced inputs.
        # Split only above four blocks; unbalanced products use overlap-add.
        if min(na,nb)>2*bits and 2*min(na,nb)>=max(na,nb):
            self.karatsuba_nodes+=1
            split=((max(na,nb)+15)//16)*8
            mask=(1<<split)-1
            a0,a1=a&mask,a>>split
            b0,b1=b&mask,b>>split
            z0=self._positive_product(a0,b0)
            z2=self._positive_product(a1,b1)
            cross=self._positive_product(a0+a1,b0+b1)-z0-z2
            if cross<0:raise ArithmeticError('Invalid Karatsuba cross term')
            return (z2<<(2*split))+(cross<<split)+z0
        lhs=a.to_bytes((na+7)//8,'little')
        rhs=b.to_bytes((nb+7)//8,'little')
        x,y=memoryview(lhs),memoryview(rhs)
        nx,ny=(len(x)+width-1)//width,(len(y)+width-1)//width
        out=bytearray((nx+ny)*width)
        mask=(1<<bits)-1
        carry=0
        for k in range(nx+ny-1):
            total=carry
            for i in range(max(0,k-ny+1),min(nx-1,k)+1):
                j=k-i
                av=int.from_bytes(x[i*width:(i+1)*width],'little')
                bv=int.from_bytes(y[j*width:(j+1)*width],'little')
                total+=self._tile(av,bv)
            out[k*width:(k+1)*width]=(total&mask).to_bytes(width,'little')
            carry=total>>bits
        if carry.bit_length()>bits:
            raise ArithmeticError('Blocked multiplication carry exceeded output capacity')
        out[-width:]=carry.to_bytes(width,'little')
        return int.from_bytes(out,'little')

    def multiply_many(self, pairs):
        values = list(pairs)
        if not hasattr(self.inner,'multiply_many') or any(self._large(a,b) for a,b in values):
            return [self.multiply(a,b) for a,b in values]
        return self.inner.multiply_many(values)

    def block_metrics(self):
        return dict(tile_ntt_limit=self.tile_ntt_limit, block_bytes=self.block_bytes,
                    blocked_products=self.blocked_products, gpu_tile_products=self.tile_products,
                    skipped_zero_tiles=self.skipped_zero_tiles,
                    diagonal_tile_count_without_karatsuba=self.max_tiles_per_product,karatsuba_nodes=self.karatsuba_nodes,
                    assembly='CPU Karatsuba / binary overlap-add; bounded GPU products; in-memory')
