# SPDX-License-Identifier: GPL-3.0-only
"""Multiplication policy shared by all binary-splitting algorithms."""
from __future__ import annotations
from contextlib import contextmanager
from contextvars import ContextVar
import time
from collections import Counter
from .calibration import cpu_product,RoutingProfile

_ACTIVE=ContextVar('neo_arithmetic',default=None)
_THRESHOLD=16384  # native Python GMP-like bigint remains faster for small products

class Policy:
    def __init__(self,backend,device,threshold,vram_mib=0,batch_size=1024,engine_choice="native",hybrid_policy="fixed",calibration_file=None):
        if engine_choice not in ('native','kolmogorov'):
            raise ValueError('Unknown compute engine')
        if threshold < 0:
            raise ValueError('GPU offload threshold must be nonnegative')
        import math
        if not math.isfinite(vram_mib) or vram_mib < 0:
            raise ValueError('VRAM budget must be finite and nonnegative')
        if hybrid_policy not in ('fixed','calibrated'):raise ValueError('Unknown hybrid policy')
        if hybrid_policy=='calibrated' and (backend!='hybrid-ntt' or not calibration_file):
            raise ValueError('Calibrated routing requires hybrid-ntt and a calibration file')
        if calibration_file and hybrid_policy!='calibrated':raise ValueError('Calibration file requires calibrated policy')
        self.hybrid_policy=hybrid_policy
        self.routing_profile=None
        self.routing_decisions=Counter()
        self.backend=backend
        self.engine_choice=engine_choice
        self.device=device
        self.threshold=threshold
        self.batch_size=batch_size
        self.batch_groups=0
        self.mul_count=0
        self.gpu_count=0
        self.gpu_wall_seconds=0.0
        self.cpu_wall_seconds=0.0
        self.small_inputs_under_128_bits=0
        self.small_inputs_under_2048_bits=0
        self.engine=None
        if engine_choice == 'kolmogorov':
            if backend not in ('opencl-ntt','hybrid-ntt'):
                raise ValueError('Kolmogorov Engine 1.1 supports only explicit GPU and fixed-threshold hybrid modes.')
            from .kolmogorov_adapter import KolmogorovMultiplier
            self.engine=KolmogorovMultiplier(device=device)
            if hasattr(self.engine,"set_vram_budget"):
                self.engine.set_vram_budget(vram_mib)
        elif backend in ('opencl-ntt','hybrid-ntt'):
            from .ntt import OpenCLMultiplier
            self.engine=OpenCLMultiplier(device,vram_mib=vram_mib)
        elif engine_choice!='native':
            raise ValueError('Unknown compute engine')
        if self.engine is not None:
            from .blocked import BlockedMultiplier
            self.engine=BlockedMultiplier(self.engine,engine_choice=engine_choice,vram_mib=vram_mib)
        if hybrid_policy=='calibrated':
            self.routing_profile=RoutingProfile(calibration_file,self.engine.device,engine_choice)

    def _offload(self,a,b):
        if self.routing_profile is not None:
            gpu,reason=self.routing_profile.choose_gpu(a,b)
            self.routing_decisions[reason]+=1
            return gpu
        return self.engine is not None and min(abs(a).bit_length(),abs(b).bit_length())>=self.threshold

    def multiply(self,a,b):
        self.mul_count+=1
        bits=min(abs(a).bit_length(),abs(b).bit_length())
        if bits<128:self.small_inputs_under_128_bits+=1
        if bits<2048:self.small_inputs_under_2048_bits+=1
        start=time.perf_counter()
        if self.engine_choice == 'kolmogorov' and (a==0 or b==0):
            self.cpu_wall_seconds+=time.perf_counter()-start
            return 0  # exact identity, no GPU operation dispatched
        if self._offload(a,b):
            # Raise all OpenCL errors: no silent CPU fallback.
            value=self.engine.multiply(int(a),int(b))
            self.gpu_count+=1
            self.gpu_wall_seconds+=time.perf_counter()-start
            return value
        value=cpu_product(a,b)
        self.cpu_wall_seconds+=time.perf_counter()-start
        return value

    def multiply_many(self, pairs):
        """Partition independent jobs; overlap GPU work with CPU products."""
        values=list(pairs)
        if not values:return []
        if self.engine is None or self.batch_size<2 or not hasattr(self.engine,'multiply_many'):
            return [self.multiply(a,b) for a,b in values]
        output=[None]*len(values)
        gpu=[];cpu=[]
        for i,(a,b) in enumerate(values):
            self.mul_count+=1
            bits=min(abs(a).bit_length(),abs(b).bit_length())
            if bits<128:self.small_inputs_under_128_bits+=1
            if bits<2048:self.small_inputs_under_2048_bits+=1
            if self.engine_choice=='kolmogorov' and (not a or not b):output[i]=0
            elif self._offload(a,b):gpu.append((i,a,b))
            else:cpu.append((i,a,b))
        def gpu_work():
            begin=time.perf_counter();results=[];groups=0
            for start in range(0,len(gpu),self.batch_size):
                group=gpu[start:start+self.batch_size]
                answers=self.engine.multiply_many([(int(a),int(b)) for _,a,b in group])
                if len(answers)!=len(group):raise ArithmeticError('Wrong GPU batch result count')
                results.extend((entry[0],answer) for entry,answer in zip(group,answers));groups+=1
            return results,time.perf_counter()-begin,groups
        def cpu_work():
            begin=time.perf_counter()
            for i,a,b in cpu:output[i]=cpu_product(a,b)
            self.cpu_wall_seconds+=time.perf_counter()-begin
        if gpu and cpu:
            from concurrent.futures import ThreadPoolExecutor
            with ThreadPoolExecutor(max_workers=1) as executor:
                future=executor.submit(gpu_work)
                cpu_work()
                answers,elapsed,groups=future.result()
        elif gpu:answers,elapsed,groups=gpu_work()
        else:cpu_work();return output
        for i,result in answers:output[i]=result
        self.gpu_count+=len(gpu);self.gpu_wall_seconds+=elapsed;self.batch_groups+=groups
        return output

@contextmanager
def use_arithmetic(backend='cpu',device=0,threshold=_THRESHOLD,vram_mib=0,batch_size=1024,engine_choice='native',hybrid_policy='fixed',calibration_file=None):
    if backend not in ('cpu','opencl-ntt','hybrid-ntt'):
        raise ValueError('Invalid arithmetic backend')
    if not 1<=batch_size<=1024:raise ValueError('GPU batch size must be between 1 and 1024')
    p=Policy(backend,device,threshold,vram_mib=vram_mib,batch_size=batch_size,engine_choice=engine_choice,hybrid_policy=hybrid_policy,calibration_file=calibration_file)
    token=_ACTIVE.set(p)
    try:yield p
    finally:_ACTIVE.reset(token)

def multiplications(a,b):
    p=_ACTIVE.get()
    return p.multiply(a,b) if p else cpu_product(a,b)

def batch_multiplication_available():
    p=_ACTIVE.get()
    return bool(p is not None and p.engine is not None and
                p.batch_size>1 and hasattr(p.engine,'multiply_many'))

def multiplications_batch(pairs):
    p=_ACTIVE.get()
    return p.multiply_many(pairs) if p else [cpu_product(a,b) for a,b in pairs]

def operation_stats(p):
    return {'hybrid_policy':p.hybrid_policy,'routing_decisions':dict(p.routing_decisions),
            'calibration_sha256':p.routing_profile.sha256 if p.routing_profile else None,
            'workspace_allocations':getattr(p.engine,'workspace_allocations',None) if p.engine else None,
            'workspace_reuses':getattr(p.engine,'workspace_reuses',None) if p.engine else None,
            'blocked_gpu':p.engine.block_metrics() if p.engine else None,'policy':p.backend,'engine_choice':p.engine_choice,'multiplication_count':p.mul_count,
            'gpu_multiplications':p.gpu_count,'minimum_operand_bits_for_offload':p.threshold,
            'gpu_batch_size':p.batch_size,'gpu_batch_groups':p.batch_groups,
            'gpu_batch_dispatches':getattr(p.engine,'batch_dispatches',None) if p.engine else None,
            'gpu_batched_products':getattr(p.engine,'batched_products',None) if p.engine else None,
            'gpu_multiply_wall_seconds':round(p.gpu_wall_seconds,5),
            'cpu_multiply_wall_seconds':round(p.cpu_wall_seconds,5),
            'multiply_inputs_under_128_bits':p.small_inputs_under_128_bits,
            'multiply_inputs_under_2048_bits':p.small_inputs_under_2048_bits,
            'gpu_schoolbook_calls':getattr(p.engine,'schoolbook_calls',None) if p.engine else None,
            'gpu_ntt_calls':getattr(p.engine,'ntt_calls',None) if p.engine else None,
            'gpu_source':('Kolmogorov 1.1 OpenCL NTT; CPU CRT/carry, assembly and finalization; logical batches NOT fused' if p.engine_choice == 'kolmogorov' else 'NeoCruncher native OpenCL batched direct + NTT + CRT/carry; CPU series orchestration') if p.engine else None,
            'gpu_batch_fused':False if p.engine_choice == 'kolmogorov' or (p.engine and p.engine.blocked_products) else (p.batch_groups>0) if p.engine else None,
            'kolmogorov_metrics':p.engine.metrics() if p.engine_choice=='kolmogorov' and p.engine else None,
            'gpu_ntt_max_transform_n':getattr(p.engine,'max_transform_n',None) if p.engine else None,
            'gpu_root_cache_hits':getattr(p.engine,'root_cache_hits',None) if p.engine else None,
            'gpu_root_cache_misses':getattr(p.engine,'root_cache_misses',None) if p.engine else None,
            'gpu_root_cache_evictions':getattr(p.engine,'root_cache_evictions',None) if p.engine else None,
            'gpu_bytes_uploaded':getattr(p.engine,'bytes_uploaded',None) if p.engine else None,
            'gpu_bytes_downloaded':getattr(p.engine,'bytes_downloaded',None) if p.engine else None}
