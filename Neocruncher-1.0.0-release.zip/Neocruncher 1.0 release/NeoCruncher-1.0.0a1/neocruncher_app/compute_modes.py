# SPDX-License-Identifier: GPL-3.0-only
"""Resolve explicit compute mode without silently selecting an unavailable backend."""
from __future__ import annotations
from .hardware import diagnosis

MODES = ('cpu', 'gpu', 'both')
GPU_BACKENDS = ('opencl-ntt',)


def compatible_backend(spec, mode):
    if mode == 'cpu':
        return 'cpu' if 'cpu' in spec.backends else None
    if mode == 'gpu':
        return next((b for b in GPU_BACKENDS if b in spec.backends), None)
    if mode == 'both':
        return 'hybrid-bellard' if spec.key == 'pi_bellard' else 'hybrid-ntt' if 'hybrid-ntt' in spec.backends else None
    raise ValueError('Compute mode must be cpu, gpu, or both.')


def find_gpus(preference='auto'):
    """Read system and OpenCL metadata before any numerical work."""
    info = diagnosis()
    devices = info['opencl_gpus']
    if preference != 'auto':
        def vendor_matches(d):
            text=(d['vendor']+' '+d['name']).lower()
            aliases={'amd':('amd','advanced micro','radeon'),
                     'nvidia':('nvidia','geforce','quadro'),
                     'intel':('intel','arc graphics')}
            return any(alias in text for alias in aliases[preference.lower()])
        devices = [(idx, d) for idx, d in enumerate(devices) if vendor_matches(d)]
    else:
        devices = list(enumerate(devices))
    return info, devices


def resolve_mode(spec, mode, *, vendor='auto', device=None):
    """Return actual backend and OpenCL ordinal; never pretend to run a hybrid algorithm."""
    backend = compatible_backend(spec, mode)
    if backend is None:
        raise ValueError(f'{spec.title} does not support {mode.upper()} execution yet. '
                         'Select a compatible algorithm or use CPU.')
    if mode == 'cpu':
        return backend, 0, None
    info, devices = find_gpus(vendor)
    if not devices:
        raise RuntimeError('No compatible OpenCL GPU found before computation. '
                           + info['advice'] + ' CPU calculations remain available.')
    if device is None:
        device = devices[0][0]
    matches = {idx: d for idx, d in devices}
    if device not in matches:
        raise ValueError('GPU device index not available for selected vendor. Run --diagnose.')
    return backend, device, matches[device]
