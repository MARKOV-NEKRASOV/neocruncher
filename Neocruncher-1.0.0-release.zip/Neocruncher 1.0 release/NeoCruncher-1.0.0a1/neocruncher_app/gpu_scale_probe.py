# SPDX-License-Identifier: GPL-3.0-only
"""Measure exact OpenCL large-integer multiplication; never claim 1B Pi readiness.

This benchmark exercises ONE arithmetic primitive. It does not execute Chudnovsky
nor remove the CPU operations from the existing Pi calculation.
"""
from __future__ import annotations
import json
import math
import random
import time
from datetime import datetime, timezone
from pathlib import Path

from .arithmetic.ntt import OpenCLMultiplier, _ensure_safe, BASE_BITS

DEFAULT_BITS=(16384,131072,1048576)
MAX_TEST_BITS=8_388_608  # 1 MiB of input bits; 2^23 bits


def one_billion_capacity_model():
    # A conceptual multiplication of two integers of 1B decimal digits each.
    # Pi binary splitting can have larger intermediates: NOT an overall budget.
    digits=1_000_000_000
    bits=math.ceil(digits*math.log2(10))
    limbs=math.ceil(bits/BASE_BITS)
    n=_next_power_of_two(2*limbs-1)
    return {
        'hypothetical_operand_decimal_digits': digits,
        'operand_bits_approximately': bits,
        'base_65536_limbs_per_operand':limbs,
        'ntt_length_for_two_such_operands':n,
        'max_single_ntt_length_in_current_engine': 1<<26,
        'ntt_length_exceeds_engine_limit':n>(1<<26),
        'estimated_ntt_workspace_gib_at_current_12x4n_rule': round((12*4*n)/2**30,2),
        'warning':'Only a model of a single 1B-digit multiplication. Pi intermediate sizes can be larger; GPU-only Pi remains unimplemented.'
    }


def _next_power_of_two(n):
    return 1 << (n-1).bit_length()


def run_scale_probe(device=0,bits=DEFAULT_BITS,report_file=None):
    bits=tuple(bits)
    if not bits or len(bits)>8 or any(type(x) is not int or x<64 or x>MAX_TEST_BITS for x in bits):
        raise ValueError(f'Use 1..8 probe sizes from 64 to {MAX_TEST_BITS:,} bits')
    gpu=OpenCLMultiplier(device)
    records=[]
    print('  GPU LARGE-MULTIPLICATION PROBE (NOT a billion-digit Pi calculation)',flush=True)
    print('  Device:',gpu.device.name,flush=True)
    print('  Calculation: integer A * B, exact GPU product vs independent Python integer product',flush=True)
    for size in bits:
        rng=random.Random(20261016+size)
        a=rng.getrandbits(size) | (1 << (size-1))
        b=rng.getrandbits(size) | (1 << (size-1))
        estimate_n=_ensure_safe((size+BASE_BITS-1)//BASE_BITS,(size+BASE_BITS-1)//BASE_BITS)
        runs=[]
        for repetition in range(2):
            begin=time.perf_counter()
            result=gpu.multiply(a,b)
            seconds=time.perf_counter()-begin
            if result!=a*b:
                raise ArithmeticError(f'GPU product WRONG for {size} bits at repetition {repetition+1}')
            runs.append(round(seconds,6))
        records.append({'operand_bits':size,'ntt_length':estimate_n,
                        'first_run_seconds':runs[0],'warm_run_seconds':runs[1],
                        'passes':2,'root_cache_hits_cumulative':gpu.root_cache_hits,
                        'root_cache_misses_cumulative':gpu.root_cache_misses})
        print(f'  {size:,} bits | NTT {estimate_n:,} | cold {runs[0]:.4f}s | warm {runs[1]:.4f}s | PASS',flush=True)
    report={
        'version':'1.0.0a1','purpose':'GPU multiplication scaling, NOT full GPU Pi',
        'device':gpu.device.name,'timestamp_utc':datetime.now(timezone.utc).isoformat(),
        'records':records,'gpu_calls':gpu.calls,'root_cache_hits':gpu.root_cache_hits,
        'root_cache_misses':gpu.root_cache_misses,'root_cache_evictions':gpu.root_cache_evictions,
        'root_cache_bytes':gpu.root_cache_bytes,'bytes_uploaded':gpu.bytes_uploaded,
        'bytes_downloaded':gpu.bytes_downloaded,'capacity_model':one_billion_capacity_model(),
        'full_gpu_pi_1b_ready':False}
    model=report['capacity_model']
    print('  1B model: single NTT length',f'{model["ntt_length_for_two_such_operands"]:,}',
          '| engine limit',f'{model["max_single_ntt_length_in_current_engine"]:,}',flush=True)
    print('  Full GPU Pi 1B: NOT QUALIFIED; use the resident qualification suite on real hardware.',flush=True)
    if report_file:
        dest=Path(report_file)
        dest.parent.mkdir(parents=True,exist_ok=True)
        with dest.open('x',encoding='utf8') as f:
            json.dump(report,f,indent=2)
            f.write('\n')
        print('  JSON saved:',dest,flush=True)
    return report


def parse_probe_bits(text):
    try:return tuple(int(part.strip()) for part in text.split(','))
    except ValueError as exc:raise ValueError('Expected comma-separated integer bit sizes') from exc
