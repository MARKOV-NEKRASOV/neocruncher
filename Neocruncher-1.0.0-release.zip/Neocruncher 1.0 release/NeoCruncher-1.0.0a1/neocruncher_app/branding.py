# SPDX-License-Identifier: GPL-3.0-only
"""Original intro layout with current colored NC mark."""
import shutil
from .prefs import paint

def render_header(version,*,terminal_width=None,colors=None):
    width=terminal_width or shutil.get_terminal_size((80,24)).columns
    rows=[('NN   NN','       '),('NNN  NN','       '),('NN N NN',' CCCCC '),('NN  NNN','CC     '),('NN   NN','CC     '),('       ','CC     '),('       ',' CCCCC ')]
    lines=[]
    for n,c in rows:
        mark=paint(n,'38;5;118',enabled=colors)+paint(c,'38;5;141',enabled=colors)
        lines.append(' '*max(0,(width-14)//2)+mark)
    for line in ('','N E O C R U N C H E R','Version 1.0 release (beta)','Arbitrary-precision scientific computing',
                 'Copyright (c) 2026 Markov–Nekrasov Research Team | GPLv3',
                 'Free and open-source software','',
                 'Precision depends on resources and the selected backend.',
                 '"Wir müssen wissen, wir werden wissen!" — David Hilbert'):
        centered=line.center(width) if len(line)<=width else line
        if line=='N E O C R U N C H E R':
            centered=paint(centered,'38;5;117',enabled=colors)
        lines.append(centered)
    return '\n'+'\n'.join(lines)+'\n'
