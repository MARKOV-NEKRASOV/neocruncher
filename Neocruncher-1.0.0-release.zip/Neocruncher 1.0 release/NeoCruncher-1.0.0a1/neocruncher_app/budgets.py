# SPDX-License-Identifier: GPL-3.0-only
"""Per-job capacity advice. AUTO budgets use available hardware with safety margins.

Admission estimate is NOT a hard memory cap and not a claim of feasibility.
Never alter OS swap, mount volumes, or install drivers on user behalf.
"""
from __future__ import annotations
from .hardware import diagnosis

MIB=1024**2

def memory_plan(digits,algorithm,workers=1):
    """Storage model, not a calibrated upper bound or an allocation.

    Chudnovsky root sizes use the *unreduced* products. Pool partitions share
    that total; multiplying it by sqrt(worker count) has no mathematical basis.
    The interval covers live merge operands, GMP scratch, output copies and
    interpreter overhead. Only the unavoidable final ASCII size gates admission.
    """
    import math
    d=max(1,int(digits));w=max(1,int(workers));binary=d*math.log2(10)/8
    overhead=(96+48*w)*MIB
    if 'chudnovsky' in algorithm:
        n=d//14+4
        factorial_bits=math.lgamma(n+1)/math.log(2)
        p=3*factorial_bits+n*math.log2(72)
        q=3*factorial_bits+n*math.log2(10939058860032000)
        root=(p+2*q+32)/8
        lower=overhead+max(2*root,4*binary+2*d)
        # Working-set allowance includes queued worker payloads, merge operands,
        # interval finalization and GMP scratch. Four root payloads underestimated
        # the measured single-process 100M trial; keep a wider planning range.
        upper=overhead+max(8*root,8*binary+3*d)
        model='unreduced Chudnovsky P/Q/T sizes and phase lifetimes; uncalibrated'
    else:
        lower=overhead+8*binary+2*d
        upper=overhead+24*binary+3*d
        model='generic integer working-set range; uncalibrated'
    if algorithm=='pi_bellard':lower=upper=32*MIB
    return dict(planning_low_mib=round(lower/MIB,2),planning_high_mib=round(upper/MIB,2),
                minimum_output_mib=round((d+3)/MIB,6),model=model,
                includes='planning allowance for all CPU workers; excludes GPU VRAM',
                guarantee=False)

def estimate_ram_mib(digits,algorithm,workers=1):
    return memory_plan(digits,algorithm,workers)['planning_high_mib']

def _auto_ram(available_bytes):
    if available_bytes is None:
        raise RuntimeError('Available RAM could not be measured. Provide --ram-mib explicitly.')
    # Preserve room for the OS, file cache, drivers, graphical desktop, etc.
    reserve=min(available_bytes//2,max(256*MIB,available_bytes//10))
    usable=(available_bytes-reserve)//MIB
    if usable < 64:raise RuntimeError('Insufficient free RAM after OS safety margin')
    return float(usable)

def _auto_vram(gpu_mib):
    return float(max(0,int(gpu_mib*0.90)-128))

def check_budget(digits,algorithm,backend,ram_mib=0,vram_mib=0,workers=1,device=0):
    if not isinstance(ram_mib,(int,float)) or not 0<=ram_mib<=2**52:
        raise ValueError('RAM admission limit MiB must be nonnegative; 0=auto')
    if not isinstance(vram_mib,(int,float)) or not 0<=vram_mib<=2**52:
        raise ValueError('VRAM admission limit MiB must be nonnegative; 0=auto')
    hw=diagnosis(include_gpu=backend!='cpu')
    available=hw['ram'].get('available_bytes')
    if ram_mib and available is not None and ram_mib*MIB>available:
        raise ValueError('Selected RAM limit exceeds currently available RAM')
    resolved_ram=float(ram_mib) if ram_mib else _auto_ram(available)
    if resolved_ram<64:raise ValueError('RAM admission limit must be at least 64 MiB')
    estimated=estimate_ram_mib(digits,algorithm,workers)
    plan=memory_plan(digits,algorithm,workers)
    # An uncertain estimate must not impose a hidden decimal-count ceiling.
    if plan['minimum_output_mib']>resolved_ram:
        raise ValueError('The final in-memory ASCII result alone exceeds the RAM budget')
    usable_gpu=None;resolved_vram=0.0
    if backend in ('opencl-ntt','hybrid-ntt','opencl-bellard','hybrid-bellard'):
        devs=hw['opencl_gpus']
        if not 0<=device<len(devs):raise RuntimeError('Requested OpenCL device unavailable. Run --diagnose.')
        usable_gpu=devs[device]
        gpu_total_mib=usable_gpu['global_memory_bytes']/MIB
        resolved_vram=float(vram_mib) if vram_mib else _auto_vram(gpu_total_mib)
        if resolved_vram>gpu_total_mib:
            raise ValueError('Requested VRAM admission limit exceeds GPU total memory')
    elif vram_mib:
        raise ValueError('VRAM admission limit applies only to GPU backends')
    return {'ram_mib':resolved_ram,'vram_mib':resolved_vram,
            'ram_mode':'auto' if not ram_mib else 'custom',
            'vram_mode':'auto' if not vram_mib else 'custom',
            'estimated_ram_mib':estimated,'memory_plan':plan,
            'planning_warning':estimated>resolved_ram,
            'policy':'safety-margin admission ESTIMATE, not a hard allocation or peak-memory guarantee',
            'gpu_name':usable_gpu['name'] if usable_gpu else None}
