# SPDX-License-Identifier: GPL-3.0-only
"""Checkpointable Chudnovsky binary splitting.
Checkpoints store exact (P,Q,T) for completed disjoint term intervals.
They are local recovery data, NOT trusted mathematical certificates.
No pickle, no executable deserialization, no overwriting of user data.
"""
from __future__ import annotations
import hashlib,json,os,zlib,math,tempfile
from pathlib import Path
from .algorithms.classical import _bs_chud,_merge_chunks,_chud_leaf,_certified,CertifiedDigits
from math import isqrt

MAX_COMPRESSED_CHUNK=200*1024*1024

def checkpoint_path(folder,places,chunk_size,index):
    folder=Path(folder)
    return folder / f'chud-v1-{places}-{chunk_size}-{index:07d}.json.z'

def _write(path,doc):
    path.parent.mkdir(parents=True,exist_ok=True)
    data=json.dumps(doc,separators=(',',':'),sort_keys=True).encode('ascii')
    digest=hashlib.sha256(data).hexdigest()
    payload=zlib.compress(json.dumps({'sha256':digest,'doc':doc},separators=(',',':')).encode('ascii'),level=3)
    import shutil
    if len(payload)+65536>shutil.disk_usage(path.parent).free:
        raise OSError('Insufficient checkpoint disk space')
    fd,name=tempfile.mkstemp(prefix='.partial-',dir=path.parent)
    try:
        with os.fdopen(fd,'wb') as f:
            f.write(payload);f.flush();os.fsync(f.fileno())
        os.replace(name,path)
    finally:
        if os.path.exists(name):os.unlink(name)

def _load(path,places,chunk_size,a,b):
    if path.stat().st_size>MAX_COMPRESSED_CHUNK:raise ValueError('Checkpoint too large.')
    decompressor=zlib.decompressobj()
    raw=decompressor.decompress(path.read_bytes(),MAX_COMPRESSED_CHUNK)
    if not decompressor.eof or decompressor.unconsumed_tail or decompressor.unused_data:raise ValueError('Corrupt checkpoint.')
    outer=json.loads(raw)
    d=outer['doc']; data=json.dumps(d,separators=(',',':'),sort_keys=True).encode('ascii')
    if hashlib.sha256(data).hexdigest()!=outer['sha256']:raise ValueError('Checkpoint hash mismatch.')
    if (d['version'],d['algorithm'],d['places'],d['chunk'],d['start'],d['end'])!=(1,'chud',places,chunk_size,a,b):
        raise ValueError('Checkpoint metadata mismatch.')
    # Data only, no Python object unpickling.
    return tuple(int(d[k],16) for k in ('p','q','t'))

def chudnovsky_resume(places,folder,chunk_size=512,progress=None,workers=1):
    if type(places) is not int or places<1:raise ValueError('Precision must be a positive integer.')
    if not 32<=chunk_size<=100_000:raise ValueError('Checkpoint interval must be 32..100000 terms.')
    if workers!=1:raise ValueError('Checkpoint execution is currently CPU single-process only.')
    terms=max(2,places//14+4)
    # Reuse independent chunks, combine with balanced tree (not left-deep merging).
    values=[]
    def tell(stage,done,total):
        if progress:progress({'stage':stage,'work_done':done,'work_total':total,'percent':round(85*done/total if stage=='binary splitting' else 85+14*done/total,2),
                              'certified_decimal_digits':0})
    tell('binary splitting',0,terms)
    for a in range(0,terms,chunk_size):
        b=min(terms,a+chunk_size);path=checkpoint_path(folder,places,chunk_size,a//chunk_size)
        if path.is_symlink():raise ValueError('Checkpoint symlinks are not accepted')
        if path.is_file():
            try:v=_load(path,places,chunk_size,a,b)
            except (ValueError,KeyError,OSError,TypeError,OverflowError,zlib.error):
                v=_bs_chud(a,b);_write(path,{'version':1,'algorithm':'chud','places':places,'chunk':chunk_size,'start':a,'end':b,
                                             'p':format(v[0],'x'),'q':format(v[1],'x'),'t':format(v[2],'x')})
        else:
            v=_bs_chud(a,b);_write(path,{'version':1,'algorithm':'chud','places':places,'chunk':chunk_size,'start':a,'end':b,
                                         'p':format(v[0],'x'),'q':format(v[1],'x'),'t':format(v[2],'x')})
        values.append(v);tell('binary splitting',b,terms)
    tell('merging/checking',0,1)
    while len(values)>1:
        values=[_merge_chunks('chud',values[i],values[i+1]) if i+1<len(values) else values[i] for i in range(0,len(values),2)]
    p,q,t=values[0];n=terms
    root_scale=10**(places+24);root=isqrt(10005*root_scale*root_scale);scale=10**places
    pn,qn,tn=_chud_leaf(n)
    t2=t*qn+p*tn;q2=q*qn
    low=min((426880*root*scale*q)//(root_scale*t), (426880*root*scale*q2)//(root_scale*t2))
    high=max((426880*(root+1)*scale*q)//(root_scale*t), (426880*(root+1)*scale*q2)//(root_scale*t2))
    if low!=high:raise ArithmeticError('Checkpointed Chudnovsky interval was not tight; retry without checkpoints.')
    tell('merging/checking',1,1)
    result=_certified(low,high,places,{'algorithm':'pi_chudnovsky','terms':n,'checkpoint':'reusable validated-by-hash chunks, not remote certification'})
    if progress:progress({'stage':'certified','work_done':1,'work_total':1,'percent':100.0,'certified_decimal_digits':places})
    return result
