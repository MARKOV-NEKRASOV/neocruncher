# SPDX-License-Identifier: GPL-3.0-only
"""Opt-in, private preferences. No driver installation or background scans."""
from __future__ import annotations
import json,os
from pathlib import Path

SUPPORTED=('auto','cpu','amd','nvidia','intel')


def config_path():
    home=Path(os.environ.get('XDG_CONFIG_HOME',str(Path.home()/'.config')))
    return home/'neocruncher'/'preferences.json'


def read():
    try:
        p=config_path()
        if p.stat().st_size>1024**2:return {}
        data=json.loads(p.read_text())
        if isinstance(data,dict) and data.get('gpu_preference') in SUPPORTED:
            return data
    except (OSError,ValueError,TypeError):pass
    return {}


def write(data):
    p=config_path();p.parent.mkdir(parents=True,exist_ok=True,mode=0o700)
    import tempfile
    fd,name=tempfile.mkstemp(prefix='.prefs-',dir=p.parent)
    try:
        with os.fdopen(fd,'w') as f:
            json.dump(data,f,indent=2);f.write('\n')
        os.chmod(name,0o600)
        os.replace(name,p)
    finally:
        if os.path.exists(name):os.unlink(name)


def first_run_wizard(hw=None,ask=input,output=print):
    prefs=read()
    if prefs:
        return prefs
    output('\n  First run — preferred execution mode (editable for every job):')
    output('  [1] CPU only (default)   [2] GPU only   [3] CPU + GPU')
    output('  [b] Back / skip — CPU default')
    options={'':'cpu','1':'cpu','2':'gpu','3':'both','b':'cpu'}
    selection=ask('  Mode: ').strip().lower()
    if selection not in options:
        output('  Invalid selection; defaulting to CPU.');selection='1'
    mode=options[selection]
    vendor='cpu'
    if mode in ('gpu','both'):
        output('  Preferred GPU vendor: [0] auto (default) [1] AMD [2] NVIDIA [3] Intel')
        vendor_options={'':'auto','0':'auto','1':'amd','2':'nvidia','3':'intel'}
        choice=ask('  GPU vendor: ').strip().lower()
        vendor=vendor_options.get(choice,'auto')
    prefs={'compute_mode':mode,'gpu_preference':vendor,'color':True,'configuration_version':2}
    try:write(prefs)
    except OSError as exc:output(f'  Cannot save preferences ({exc}); continuing.')
    output('  You can change compute mode per project. Drivers are never installed automatically.')
    return prefs


def paint(message, code, enabled=None):
    if enabled is None:
        enabled=os.environ.get('NO_COLOR') is None and hasattr(__import__('sys').stdout,'isatty') and __import__('sys').stdout.isatty()
    return f'\033[{code}m{message}\033[0m' if enabled else message
