# SPDX-License-Identifier: GPL-3.0-only
# Sourced only by the root bundle launchers after changing to the bundle root.
unset LD_LIBRARY_PATH LD_PRELOAD PYTHONHOME PYTHONPATH
if [ ! -x .venv-system/bin/python ]; then
  printf '%s\n' 'Missing .venv-system. Run: sh install.sh --gpu' >&2
  exit 1
fi
PYTHONNOUSERSITE=1
export PYTHONNOUSERSITE
