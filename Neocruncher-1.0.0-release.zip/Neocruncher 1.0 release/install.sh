#!/bin/sh
# SPDX-License-Identifier: GPL-3.0-only
set -eu
cd "$(dirname "$0")"
unset LD_LIBRARY_PATH LD_PRELOAD PYTHONHOME PYTHONPATH
if [ -n "${NEOCRUNCHER_PYTHON:-}" ]; then py="$NEOCRUNCHER_PYTHON"
elif [ -x /usr/bin/python3 ]; then py=/usr/bin/python3
else py=$(command -v python3); fi
"$py" -c 'import sys,pathlib; assert not (pathlib.Path(sys.base_prefix)/"conda-meta").exists(), "Choose a system Python, not Conda"'
"$py" -c 'import math,hashlib,venv,ensurepip; hashlib.blake2b(); hashlib.blake2s(); assert math.isqrt(81)==9' || { printf '%s\n' 'System Python is incomplete. Repair its standard library and matching venv package; then select it with NEOCRUNCHER_PYTHON.' >&2; exit 1; }
if [ ! -x .venv-system/bin/python ]; then
  "$py" -m venv .venv-system || { printf '%s\n' 'Install the venv package matching your system Python, then retry.'; exit 1; }
fi
.venv-system/bin/python -c 'import sys,pathlib; assert not (pathlib.Path(sys.base_prefix)/"conda-meta").exists(), "Existing .venv-system belongs to Conda; rename it and retry"'
case "${1:-}" in
  --gpu) .venv-system/bin/python -m pip install ./Kolmogorov-Engine-1.0.0a1 './NeoCruncher-1.0.0a1[gpu]' ;;
  '') .venv-system/bin/python -m pip install ./Kolmogorov-Engine-1.0.0a1 ./NeoCruncher-1.0.0a1 ;;
  *) printf '%s\n' 'Usage: sh install.sh [--gpu]'; exit 2 ;;
esac
.venv-system/bin/python -m pip check
.venv-system/bin/python -m pip list --format=freeze > installed-dependencies.txt
printf '%s\n' 'Installed in .venv-system. Start: sh run_neocruncher.sh' 'GPU validation: sh doctor.sh --full'
