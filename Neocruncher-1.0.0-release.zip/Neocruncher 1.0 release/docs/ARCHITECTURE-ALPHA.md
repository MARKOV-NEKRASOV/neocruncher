# Architecture revision: computation, memory and evidence

This revision keeps exact arithmetic and the existing menu-oriented CLI. It
changes execution policy and measurement rather than claiming a new formula.
“Kolmogorov” is the engine name: algorithmic information theory does not provide
a proven shortcut for computing decimal digits here.

## CPU

Chudnovsky sums approximately one term per 14 decimal places. Binary splitting
represents each interval by exact integers P, Q, T; two neighboring intervals
merge using P=P1 P2, Q=Q1 Q2, T=T1 Q2+P1 T2. This avoids repeated division and lets
GMP multiply large balanced operands efficiently. CPU subprocesses compute
independent intervals. Their returned results now merge through a balanced
frontier, and consumed futures release their references. Final interval checks,
square root and conversion to decimal remain CPU operations.

Benefit sought: less unbalanced parent multiplication and less retention of
completed intermediate results. Worker count does not imply proportional speedup:
IPC, process startup, memory bandwidth and serial finalization remain costs.

## Hybrid

CPU produces exact subtrees while OpenCL handles eligible upper products.
Previously 1024-term subtrees caused many crossings between host and device.
The new default chooses a power-of-two subtree size targeting roughly eight
subtrees; an explicit override reproduces the previous policy. One producer
thread overlaps the next CPU subtree with GPU upper products. Decimal conversion
remains on CPU in this mode. No claim is made that the GPU must beat GMP.

Benefit sought: fewer transfers, kernel launches and coordinator operations.
Potential cost: larger CPU subtrees and less GPU arithmetic. Actual 100M/500M
measurements, with transfer/kernel/CPU phase times, determine the useful balance.

## GPU pure

Large integers stay in GPU storage (with optional storage spills), using exact
limb arithmetic and NTT multiplication. CPU schedules work and handles output.
Decimal conversion recursively divides by powers of ten. Nodes of equal output
width now reuse a reciprocal rather than recomputing Newton iterations at every
node. Each division still corrects its quotient and checks its exact remainder.
Leaf conversion batches are larger. Progress measures produced ASCII digits,
not a newly proved number of correct pi digits.

Benefit sought: reduce repeated reciprocal work during the decimal phase, where
previous 10M runs timed out. The scalar C harness validates numerical behavior;
it cannot establish OpenCL driver correctness, GPU residency or performance.

```mermaid
flowchart TD
  R[Requested precision] --> B[Resource and verification preflight]
  B --> C[CPU exact subtrees]
  B --> G[GPU resident tree]
  C --> M{Execution policy}
  M --> H[Balanced CPU merge]
  M --> O[GPU upper products]
  H --> F[CPU interval and decimals]
  O --> F
  G --> D[Cached reciprocal decimal conversion]
  F --> S[Save TXT and JSON]
  D --> S
  S --> V[Requested independent check]
```

## Decimal limits and result preservation

There is no new 100k ceiling on calculation. The independent mpmath verifier
retains its 100k limit; its scope must be selected before starting. Large prefix
verification is explicit. TXT and sidecar are saved before this optional check,
so a verification failure no longer discards an otherwise completed calculation.
Component version 1.0.0a1 and integration API 1.2.0 are independent identifiers,
which removes the previous adapter rejection caused by checking a release label.
The GPU's uint32 output indexing still imposes a limit below 2^32 ASCII digits.
These are in-memory engines; disk output/checkpoints are not out-of-core arithmetic.

## Memory model

The old estimate multiplied a digit-based coefficient by sqrt(workers), imposing
an unsupported admission ceiling. The replacement models unreduced Chudnovsky
root products using log-factorial sizes and a range of live operands/scratch;
per-process overhead is added separately. A 100M CPU trial exposed an overly
narrow scratch allowance, which was widened before packaging. It is uncalibrated planning advice,
not a proven upper bound. A range exceeding budget warns; the unavoidable final
ASCII size exceeding budget rejects. A separate sampled tree-memory guard stops
work crossing budget where OS measurements are available. Sampling can miss a
short peak and cannot guarantee protection from the OS OOM killer.

RAM total remains physical RAM; cgroup limits are reported separately. Available
RAM, automatic reserve, selected budget, RSS and PSS have distinct meanings.
No swap/driver/system settings are changed automatically.

## Delivery scope and known limits

The agreed initial delivery scope is CPU at 100M decimal places and hybrid at
10M. Larger CPU/hybrid targets and GPU-pure stress failures do not block this
initial delivery. This is a scope decision, not a declaration that every target
has passed on every machine. The Alpha CPU 100M calculation matched the supplied
complete reference TXT in the development environment. A supplied Alpha CPU summary reports completion through 1B with a 100k-place
independent prefix check. The newer hybrid/native console reports completion
at 10M and 100M; its full metadata remains pending review. Do not label historical
results or prefix checks as complete current-build numerical qualification.

Large calculations use explicit prefix verification or complete-byte reference
comparison with clearly different scopes. The independent mpmath verifier has
not been expanded past 100k decimal places. In-memory arithmetic and sampled
resource limits retain their documented limitations. No unconditional speed,
peak-memory, correctness, or safety guarantee is made.

This public release contains no distributed computation implementation, Lab
auditor/database or automated development-test payloads. The tests directory is
intentionally empty. The security/privacy review adds defensive input checks and updates dependency
recording and documentation. Numerical formulas and scheduling did not change.
