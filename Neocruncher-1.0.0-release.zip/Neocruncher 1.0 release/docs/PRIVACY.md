# Privacy and sharing diagnostic results

NeoCruncher performs local numerical computation. This source review found no
automatic uploader for calculations, diagnostic data or test reports. Installation
uses pip to obtain dependencies, and explicitly authorized GPU setup can invoke
package managers. Those tools and third-party GPU drivers have their own network
and privacy behavior.

## Files that can reveal local information

Diagnostic commands, progress logs, tracebacks and research-auditor reports can
contain filesystem paths, output names, command arguments, hardware/driver details,
source and hardware fingerprints, and timestamps. Custom-expression reports store
the expression itself. A verifier's ordinary successful report uses only the
input basename, but error messages and filenames can still contain personal text.
Treat raw reports as private until reviewed. Hardware hashes are identifiers,
not proof of anonymity.

The installer records package names and versions using `pip list --format=freeze`.
It does not intentionally record direct-source installation URLs in that list.
This is an environment inventory, not a complete reproducible lockfile.

## Publication policy

- Publish selected numerical measurements with a clearly stated verification scope.
- Keep raw audit archives, history databases, terminal logs, virtual environments,
  local configuration, calibration data and checkpoints out of the public repository.
- Use neutral filenames for published outputs. Inspect human-readable text and
  document/image metadata before uploading.
- The separate review tool `export_public_metrics.py` exports an allowlist of
  metrics from supported summary JSON. It drops paths, host/device identities,
  raw commands, errors, expressions and arbitrary diagnostic text. It is not a
  general anonymizer; read its output before publishing it.
- Project copyright notices use the collective team name. Bibliographic credits
  and third-party license notices retain their respective authors.

The two PNG assets in the reviewed bundle have no detected EXIF or ancillary
metadata. Replacement artwork must be checked again. The reviewed paper figures
have generator/date metadata removed; compiling or editing documents can add new
metadata. This policy applies to the reviewed files, not future uploads by default.
