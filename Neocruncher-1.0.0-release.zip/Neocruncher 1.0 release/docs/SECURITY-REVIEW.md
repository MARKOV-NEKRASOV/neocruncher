# Security review scope

This beta release received a bounded source and publication-privacy review.
It is not an independently certified or vulnerability-free build.

The review examined the packaged Python, shell, C and OpenCL sources; local
subprocess execution; expression parsing; checkpoint formats; output creation;
optional native-library loading; package metadata; and publication assets.
Regression checks cover the changed input boundaries, exclusive output creation,
selected numerical paths and the publication-metrics exporter.

Changes include rejecting non-vector residue arrays before passing their storage
to the optional C CRT/carry helper, checking custom power/root limits before
potentially expensive integer conversions, omitting absolute input directories
from normal verification reports, avoiding direct-source URLs in the generated
dependency inventory, and correcting release documentation.

## Remaining trust boundaries

- Custom expressions use a restricted AST interpreter, not Python eval/exec.
  This is not a resource-exhaustion-proof sandbox. Large precision and expensive
  permitted mathematical functions can still consume substantial time or memory.
- Checkpoints use data-only formats and checksums, not authenticated computation.
  Use recovery data from trusted local jobs and directories. Do not treat a
  supplied checksum as proof of mathematical correctness.
- Optional shared libraries and OpenCL drivers execute native code. Load only
  trusted libraries and use a trusted runtime environment. This package ships
  source for the optional helper, not a precompiled helper binary.
- Native plugin path environment variables are explicit local code-loading
  mechanisms, not isolation boundaries. Do not use attacker-controlled plugin paths.
- Atomic/exclusive file operations reduce accidental overwrites; shared writable
  directories and concurrent adversarial file replacement are not fully isolated.
  Use directories controlled by your account and do not run the application as root.
- Dependency ranges are not a hash-locked supply chain. The review does not
  certify every possible future dependency resolution or audit third-party code.
- GPU kernel memory behavior was inspected at source level but was not dynamically
  fuzzed on physical OpenCL hardware during this review. Numerical smoke checks
  cannot certify driver safety or large-device behavior.
- Sampled memory limits may miss peaks. They do not replace OS resource limits.

No complete automated dependency-advisory scan or third-party penetration test
was performed. Review the separate release report for the exact checks and their
results. A code change produces a new source fingerprint; earlier performance
records remain associated with their original measured snapshot.
