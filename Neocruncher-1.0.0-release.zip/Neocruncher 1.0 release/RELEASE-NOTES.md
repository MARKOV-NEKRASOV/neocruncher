# Neocruncher 1.0 release

Status: **beta**. Public distribution by **Markov–Nekrasov Research Team**.

The package contains the application, Kolmogorov/PyKolm sources, build metadata,
launchers, GPLv3 text and collective project attribution. It does not include
the research auditor, raw personal test reports, history database or private
configuration. GPU and hybrid performance remain experimental.

This packaging updates the public artifact name and welcome-screen label.
Internal package identifiers remain `1.0.0a1`, and the integration API remains
`1.2.0`, to preserve the existing dependency and compatibility contracts.
Numerical formulas, kernels and scheduling are unchanged from the reviewed copy.

The source security/privacy checks are documented in `docs/SECURITY-REVIEW.md`
and `docs/PRIVACY.md`. They do not certify third-party drivers or all possible
dependency resolutions. Benchmarks refer to their original measured snapshots,
not a newly measured byte-identical final archive.

Paper and benchmark PDFs are separate publication assets. The author's edited
paper must receive its final document review before publication.
