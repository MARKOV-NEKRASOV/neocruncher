# Neocruncher 1.0 release — Beta

Published by **Markov–Nekrasov Research Team**. License: **GNU GPLv3 only** (`GPL-3.0-only`).
This ZIP contains the public application and its source code. No Lab, auditor, database, personal test results,
distributed computation implementation or graphical interface is included.
The tests directory is intentionally empty.

## Install and start (Linux)

```sh
sh install.sh --gpu
sh doctor.sh --full
sh run_neocruncher.sh
```

CPU-only installation: `sh install.sh`. Use a complete non-Conda Python with
working math/hashlib, venv and ensurepip. Select an interpreter if needed:
`NEOCRUNCHER_PYTHON=/absolute/path/to/python3 sh install.sh --gpu`.
OpenCL requires a compatible installed driver and ICD. System drivers are not
installed automatically. Always use the root launchers.

Small verified CPU calculation:

```sh
sh run_neocruncher.sh --constant pi --digits 1000 --verify --output pi-small.txt
```

For larger calculations, `--verify-prefix 100000` independently checks only the
first 100k decimal places. The remainder is not independently verified by that
option. TXT and JSON are saved before the requested independent check. Select
a fresh output name; existing result files are not deliberately overwritten.

## Initial delivery scope

CPU: 100M decimal places. Hybrid: 10M decimal places. These are the agreed scope,
not a guarantee across machines. CPU 100M matched a complete supplied reference
in development. A supplied Alpha CPU audit reports completion through 1B with
an independent 100k-place prefix check. A newer hybrid/native console report
records 10M in 37.420 seconds and 100M in 1929.621 seconds of wall time; its
complete metadata remains pending review. Neither report independently certifies
all large-output digits. GPU-pure large-size performance remains experimental.

RAM total, available memory and job budget differ. The memory estimate is a
planning heuristic, not a guaranteed peak. Sampled enforcement is not an OS
reservation and may miss peaks or be unavailable. This is not an out-of-core
engine. See docs/ARCHITECTURE-ALPHA.md for architecture and limitations.

The numerical formulas and scheduling policies remain unchanged. This reviewed
package adds defensive input checks, avoids direct-source URLs in the generated
dependency list, and updates privacy and release documentation. The title remains
light blue and licensing metadata retains the agreed GPLv3-only designation.
The public artifact is named `Neocruncher 1.0 release.zip` and is a beta.
The internal component version remains 1.0.0a1; the hybrid integration API remains 1.2.0.

## License and credits

See COPYING for GPL version 3 and NOTICE for copyright/attribution details.
The current project's own code is GPL-3.0-only. Legacy permission texts in LICENSES
record earlier grants, with collective project attribution; dependencies retain their own licenses.
Project attribution uses the collective team name; third-party notices are retained.
Developed in explicit collaboration with GPT / ChatGPT / Codex.

See `docs/PRIVACY.md` and `docs/SECURITY-REVIEW.md` before sharing diagnostic
reports, logs or local result metadata. Installation downloads dependencies;
the numerical runtime contains no identified automatic test-data uploader.

A GitHub repository URL has not been provided. Once assigned, use
`git clone REPOSITORY_URL` and run the installation commands in the bundle root.
REPOSITORY_URL is a placeholder, not a published repository.
