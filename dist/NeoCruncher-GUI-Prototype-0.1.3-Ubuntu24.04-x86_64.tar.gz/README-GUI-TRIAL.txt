NeoCruncher GUI 0.1.3 — Ubuntu 24.04 x86_64 trial

This trial bundles the released NeoCruncher 1.0 CPU CLI. It keeps the Rust GUI
binary from version 0.1.1. The launcher selects native Wayland on GNOME
Wayland sessions even when DISPLAY is also set for XWayland.

AppImage: mark it executable, open it with AppImageLauncher, and choose
Integrate and run. The desktop menu should show NeoCruncher GUI (trial 0.1.3).

Direct tar archive: extract into a stable folder, run ./AppRun --self-test,
then ./AppRun. Run ./install-desktop.sh once to create a per-user menu entry
and icon. Do not move the extracted folder after installing that entry.

For diagnostics run ./AppRun --diagnose; a Wayland session should show
Selected display route: wayland. ./AppRun --wayland forces that path.
The bundled CPU calculation can be checked without a window with
./AppRun --self-test. GPU and hybrid modes are not qualified in this trial.
